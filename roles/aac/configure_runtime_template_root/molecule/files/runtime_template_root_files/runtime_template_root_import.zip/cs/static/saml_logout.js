function displayMessage(){
    var messageDiv = document.getElementById("messageDiv");
    var username   = "@TOKEN:UserName@";

    if (username == "null") {
        messageDiv.innerHTML = "Žádný uživatel k odhlášení.";
    } else {
        messageDiv.innerHTML = "Jednotlivé odhlášení uživatele bylo úspěšně dokončeno " + username + ".";                
    }
}

window.onload = function() {
    displayMessage();
};