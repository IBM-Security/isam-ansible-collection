
var form = document.createElement("form");
form.setAttribute("method","POST")

var url = window.location.href;

var action = window.location.pathname;
form.setAttribute("action", action);

var paramsExist = false;
var hash = url.indexOf('#');
if( hash > 0 && !url.endsWith('#')) {
    var fragment = url.substring(hash+1);

    // tokenize the fragment.
    var parameters = fragment.split("&");

    parameters.forEach(function(parameter) {


        var equal = parameter.indexOf('=');
        var hasValue = false;
        if( equal > 0 && !parameter.endsWith('=')) {
            hasValue = true;
        }
        var name = parameter.split('=')[0];
        var value = parameter.split('=')[1];
        var input = document.createElement("input");

        input.setAttribute("name",name);
        input.setAttribute("type","hidden");

        if(hasValue) {
            input.setAttribute("value",value);
            paramsExist = true;
        }
        
        form.append(input);
    });
}

//if parameters were found in the URL fragment, then POST them.
//Otherwise, hide the "Redirecting...." div and un-hide the error_div to display an error message
if(paramsExist)
{
    var inputFlag = document.createElement("input");
    inputFlag.setAttribute("name","fetched");
    inputFlag.setAttribute("type","hidden");
    inputFlag.setAttribute("value","true");
    form.append(inputFlag);

    document.body.appendChild(form);
    form.submit();
}
else
{
  //later we want to change this to redirect to the LRR to display an error instead of displaying on this HTML page
  document.getElementById("redir_div").style.display = 'none';
  document.getElementById("error_div").style.display = 'block';
}