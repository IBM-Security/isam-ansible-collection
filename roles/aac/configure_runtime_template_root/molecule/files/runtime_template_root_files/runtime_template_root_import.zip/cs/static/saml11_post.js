var signOnText = 'Čekejte, prosím, probíhá přihlašování...';
document.write(signOnText);
document.forms[0].submit();