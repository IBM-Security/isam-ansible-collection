var mgmtMsg = {

    "definition":"Definice",
    "clientId":"ID klienta",
    "owner":"Vlastník",
    "serverError":"Chyba serveru. ",
    "removeString":"Odebrat",
    "mothersMdnName":"Rodné jméno matky?",
    "birthTown":"Název města, kde jste se narodili?",
    "firstPet":"Jméno prvního domácího mazlíčka?",
    "provideAnswer":"Musíte uvést hodnotu k této otázce: ",
    "invalidChars":"Následující znaky nejsou povoleny: ",
    "illegalChars":"Odpověď na následující otázku obsahuje neplatné znaky: ",
    "notEnoughQuestions":"Musíte uvést alespoň jednu znalostní otázku a odpověď.",
    "colonSpace":": "
};
