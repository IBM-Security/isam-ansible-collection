var signOnText = 'Čekejte, prosím...';
document.write(signOnText);
document.forms[0].submit();