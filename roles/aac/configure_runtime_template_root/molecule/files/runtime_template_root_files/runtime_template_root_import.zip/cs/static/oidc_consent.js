function escapeHTML(data) {
    var div = document.createElement("div");
    div.appendChild(document.createTextNode(data));
    return div.innerHTML;
}


var consentData = oauthFormData;
var container = document.getElementById("scopes");
for(var i = 0; i < consentData.scope.length; i++){
var checkbox = document.createElement('input');
checkbox.type = "checkbox";
checkbox.name = consentData.scope[i] + "_checkbox";
checkbox.id = consentData.scope[i] + "_checkbox";

var label = document.createElement('label')
label.htmlFor = checkbox.id;
label.appendChild(document.createTextNode(consentData.scope[i]));

container.appendChild(checkbox);
container.appendChild(label);
        container.appendChild(document.createElement('br'));

}

var btnYesRemember = document.getElementById("btnYesRemember");
var btnYesDoNotRemember = document.getElementById("btnYesDoNotRemember");
var btnNo = document.getElementById("btnNo");

btnYesRemember.onclick = function() {
    consentData.prompt = 'none';
    submitForm(consentData);
};

btnYesDoNotRemember.onclick = function() {
    consentData.prompt = 'consent';
    submitForm(consentData);
};

btnNo.onclick = function() {
    cancel(consentData);
};


var spanClientName = document.getElementById("clientName");
spanClientName.innerHTML = escapeHTML(consentData.clientDisplayName);