var i18nMsg = {
"titleRego":"Registrace FIDO U2F",
"titleAuth":"Ověření FIDO U2F",
"error":"Chyba: Došlo k chybě při zahájení registrace. Kontaktujte administrátora systému.",
"errorAlreadyRego":"Chyba: Došlo k chybě při zahájení registrace. Zkontrolujte, že tento token již není registrovaný.",
"errorTimedOut":"Požadavek vypršel.",
"errorAuth":"Chyba: Došlo k chybě při provádění ověření.",
"errorAuthSysadmin":"Chyba: Došlo k chybě při provádění ověření. Kontaktujte administrátora systému.",
"remove":"Odebrat",
"regoPageTitle":"Registrace tokenu zabezpečení",
"authPageTitle":"Ověření tokenu zabezpečení",
"register":"Registrovat nový token",
"id":"ID",
"name":"Název",
"appId":"AppId",
"enabled":"Povoleno",
"prompt":"Vložte prosím token zabezpečení a stiskněte tlačítko.",
"namePrompt":"Poskytněte popisný název pro tento token zabezpečení:",
"tokenPrompt":"Vložte prosím token zabezpečení a stiskněte tlačítko.",
"noTokensPrompt":"Nebyly nalezeny žádné registrované tokeny zabezpečení.",
"sumbit":"Odeslat",
"cancel":"Storno"
}

