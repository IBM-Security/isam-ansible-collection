var authsvcMsg = {

"twoStepVerification":"Dvojí ověřování",
"twoStepVerificationSettings":"Nastavení dvojího ověřování",
"twoStepVerificationSetup":"Nastavit dvojí ověřování",

// Titles
"authenticate":"Ověřit",
"verification":"Ověřování",
"validation":"Ověření",
"login":"Přihlášení",
"register":"Registrace",

"howToFIDOTitle": "Demo FIDO2 PAIR",

"identifierFirstTitle": "Ověření IFA",
"signInOptions":"Volby přihlášení",
"mmfa": "Mobilní vícenásobné ověřování",
"mmfaPending": "Mobilní vícenásobné nevyřízené ověření",

"enable":"Povolit",
"enabled":"Povoleno",
"disable":"Zakázat",
"disabled":"Zakázáno",

//Buttons
"back":"Zpět",
"submit":"Odeslat",
"verify":"Ověřit",
"add":"Přidat",
"remove":"Odebrat",
"save":"Uložit",
"validate":"Ověřit",
"finish":"Dokončit",
"signIn":"Přihlásit",
"choose":"Zvolit",
"enterCode":"Zadat kód",
"sendCode":"Odeslat kód",
"letsGo":"Začněme",
"signInFaster": "Rychlejší přihlášení",
"continue": "Pokračovat",
"rememberMe": "Zapamatovat",
"showPassword": "Zobrazit heslo",
"actions": "Akce",
"checkStatus": "Kontrola stavu",

"usernameInstructions":"Zadejte prosím jméno uživatele pro přihlášení:",
"username":"Jméno uživatele",
"password":"Heslo",

"welcome":"Vítejte!",
"errorLabel":"Chyba",
"errorColonLabel":"Chyba: ",
"okGotIt":"Dobře, rozumím.",
"enrollNow":"Zaregistrovat nyní",
"setUp":"Nastavit",
"done":"Hotovo",
"success": "Úspěch!",
"hello": "Dobrý den, USERNAME_MACRO!",
"detail": "Podrobnosti",

"redirect": "Přesměrovat",
"redirecting": "Přesměrování...",

"letsMakeSure":"Ujistěme se, že se jedná o vás",
"letsRegisterToken":"Zaregistrujme nového ověřovatele",
"letsRegisterFIDO":"Zaregistrujme vaše zařízení s povoleným ověřením FIDO",
"fido2Authentication":"Ověření FIDO2",
"fido2Registration":"Registrace FIDO2",
"fido2Instructions":"Najděte v prohlížeči pokyny, jak dále pracovat s ověřovatelem.",
"fido2Nickname":"Poskytněte přezdívku pro tuto registraci.",
"fido2ReadyInstructions":"Jste připraven s pomocí FODO2 ověřit, že jste to vy?",
"fido2SignInReady": "Vaše nové přihlášení je připraveno k používání.",
"fido2AuthenticateWith": "Ověřit pomocí FIDO2",
"fido2FirstLine": "Chcete se přihlásit rychleji? Přidejte ověření zařízení, když se přihlašujete, abyste místo toho použili biometrické odemknutí vašeho zařízení.",
"fido2SecondLine": "Poznámka: všichni uživatelé, kteří mohou odemknout toto zařízení pomocí biometrického odemknutí, mohou také přistoupit k vašemu účtu.",
"fido2Yes": "Ano",
"fido2NotNow": "Teď ne",
"fido2Never": "Nikdy na tomto zařízení",
"fido2ChooseAccount": "Chcete-li pokračovat, vyberte účet:",
"howToSignIn":"Jak se chcete přihlásit?",

"fido2Options":"Rozšířené volby registrace:",
"fido2RequireResidentKey":"Vyžadovat rezidentní klíč",

"user_not_found": "Uživatel nebyl nalezen.",
"username_password_mech_not_configured": "Mechanismus hesla uživatele nebyl správně nakonfigurován.",
"login_failed": "Přihlášení selhalo. Použili jste neplatné jméno uživatele nebo heslo.",

"no_second_factor": "Nejsou zaregistrovány žádné metody druhého faktoru.",

"genericBranch": "Obecné větvení",
"chooseBranch": "Vyberte větev",
"genericInstructions": "Vyberte volbu z níže uvedeného seznamu.",

"deviceUnlock":"Bezpečnostní klíč/Odemknutí zařízení",
"deviceUnlockWin":"Bezpečnostní klíč/Windows Hello",
"deviceUnlockMac":"Bezpečnostní klíč/Touch ID",

"fidoDescription": "Použít bezpečnostní klíč nebo metodu odemknutí tohoto zařízení",
"mmfaDescription": "Odeslat oznámení typu push na váš telefon",
"passwordDescription": "Použít jméno uživatele a heslo",
"mmfaSelectDesc": "Vyberte zařízení, které chcete použít pro ověření:",
"mmfaPendingDesc": "Na vaše zařízení bylo odesláno oznámení. Pokud jste je dosud neobdrželi, otevřete aplikaci IBM Verify.",
"mmfaTxnDetails": "Podrobnosti o transakci: ",
"mmfaStatus": "Stav: ",
"mmfaRefreshDesc": "Klepnutím zde aktualizujete stav transakce.",

"knowledgeQuestions": "Zodpovědět bezpečnostní otázky",

"badOptionsRequest": "U požadavku na volby došlo k problému.",

"fileUpdateMessage":"Varování: Aktualizujte soubory šablon přes soubory ke stažení/soubory šablon, abyste viděli obnovené UI",

"mmfaTransactionStatusError":"Během kontroly stavu transakce došlo k chybě",

"qrloginLoginStatusError":"Během kontroly stavu přihlášení došlo k chybě",

"unexpectedResponse":"Byla přijata neočekávaná odezva. Stav odezvy: ",

"somethingWentWrong":"Něco se nezdařilo. Klepnutím zobrazíte chybu, nebo to zkuste znovu."
};
