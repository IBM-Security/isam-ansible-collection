window.addEventListener('load', function() {
    startup();

    document.getElementById("rc_button-1").addEventListener("click", completeFIDOReg);

    var jsLinks = document.querySelectorAll('[href="#"]');

    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }
});

function populateStrings() {
    document.title = authsvcMsg.success;
    document.querySelector('h1').textContent = authsvcMsg.success;
    document.querySelector('#fido-success-div p').textContent = authsvcMsg.fido2SignInReady;
    document.querySelector('#fido-success-div button').textContent = authsvcMsg.done;
}

function completeFIDOReg() {
    var regCompleteForm = document.getElementById('reg-complete-form');
    regCompleteForm.submit();
}

function startup() {
    populateStrings();
}
