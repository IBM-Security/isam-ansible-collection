//var scim_poll = setInterval(ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, finalFunction),20000);
//var timeout = easingTimeout(1000, function(){ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, finalFunction)});
var scim_authenticator_schema = "urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Authenticator";
var scim_transaction_schema = "urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Transaction";
var user_info_schema = "urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Transaction";
var authenticators = null;
var authMethods = null;
var transactions = null;
var transactionsPending = null;
var attributes = null;
var attributesPending = null;
var popup_global = false;
var color_fail = "#dc0000";
var color_pending = "#fd8c00";
var color_success = "#00ac46";
var transaction_device_name = null;
var transactions_data = [];
var attributes_data = [];
var retry = false;
var ws;
var socket_interval = null;

function waitFunctionSCIM(scimRequest) {
	//SCIM Background Poll Wait Function
	trace("Background poll - waiting for SCIM response", "fine");
}

function completeFunctionSCIM(scimRequest, finalFunction) {
	if (scimRequest != null){
		var scimRequest = JSON.parse(scimRequest.responseText);
		//SCIM Background Poll On Complete
		trace("Background poll - completing SCIM actions", "fine");
		//Fill out global JavaScript objects		
		//- No. of Authenticators	
		//- No. of Authentication Methods	
		//- Authentication Method types registered		
		//- No. Transactions Total	
		//- No. Pending transactions
		if (scimRequest[scim_authenticator_schema] != null) {
			authenticators = scimRequest[scim_authenticator_schema].authenticators;
			var fingerprintMethods = scimRequest[scim_authenticator_schema].fingerprintMethods;
			var userPresenceMethods = scimRequest[scim_authenticator_schema].userPresenceMethods;
			authMethods = fingerprintMethods.concat(userPresenceMethods);
			authMethods.fingerprint = fingerprintMethods;
			authMethods.userpresence = userPresenceMethods
		} else {
			trace("No Authenticators Found", "fine");
			authenticators = null;
			authMethods = null;
		}
		if (scimRequest[scim_transaction_schema] != null) {
			transactionsPending = scimRequest[scim_transaction_schema].transactionsPending;
			var transactionsResolved = scimRequest[scim_transaction_schema].transactionsResolved;
			attributesPending = scimRequest[scim_transaction_schema].attributesPending;
			var attributesResolved = scimRequest[scim_transaction_schema].attributesResolved;
			transactions = transactionsPending.concat(transactionsResolved);
			attributes = attributesPending.concat(attributesResolved);
		} else {
			trace("No Transactions Found", "fine");
			transactions = null;
			attributes = null;
			transactionsPending = null;
			attributesPending = null;
		}
	}else {
		trace("SCIM Request is blank - Local server?", "warning");
	}
	if (finalFunction != null && finalFunction != "undefined") {
		trace("Background poll - heading into finalFunction", "fine");
		finalFunction(scimRequest);
	}
}

//START Username field change-------------------------------
//$('#username_mmfa').on('input propertychange paste', function() {
$('#username_mmfa').focusout(function() {
	checkUsernameField();
});

function usernameSubmit() {
	if (checkUsernameField()){
		var response = grecaptcha.getResponse();
		if (response != null && response != "") {
			$("#html_element").css("border", "2px solid green");
			var username = $("#username_mmfa").val();
			var recaptcha = "&operation=verify&g-recaptcha-response=" + response;
			isam_login(username, response);
		} else {
			$("#html_element").css("border", "2px solid red");
			return;
		}
	}
}

function checkUsernameField(){
	var username = $("#username_mmfa").val();
	if (isValidEmailAddress(username)) {
		$("#username_mmfa").css("border", "2px solid green");
		return true;
	} else {
		$("#username_mmfa").css("border", "2px solid red");
		return false;
	}
}
//END Username field change-------------------------------

//START Transfer Amount field change----------------------------
$('#transfer_mmfa').on('input propertychange paste', function() {
	checkTransferField();
});

function checkTransferField(){
	var transferamount = $("#transfer_mmfa").val();
	if (isValidNumber(transferamount)) {
		var check_transfer = checkAuthenticatorsForTransfer(transferamount);
		
		if (transferamount < 500) {
			
			$(".transaction-amount-message-field").html("Low value transaction");
			$(".transaction-policy-message-field").html("No 2FA required");
			$("#transfer_mmfa").css("border", "2px solid green");
			
		} else if (transferamount >= 500 && transferamount < 1000) {
			
			$(".transaction-amount-message-field").html("Medium value transaction");
			$(".transaction-policy-message-field").html("This will require <b>user presence</b> 2FA");
			
			if (check_transfer.allowed == true) {
				$("#transfer_mmfa").css("border", "2px solid green");
			} else {
				$("#transfer_mmfa").css("border", "2px solid orange");
				if (check_transfer.reason == "none"){
					$(".transaction-policy-message-field").html("Please add a device for this transaction.");					
				}else if(check_transfer.reason == "no-touch"){
					$(".transaction-policy-message-field").html("Please add Fingerprint Authentication.");					
				}else{
					$(".transaction-policy-message-field").html("Please check your device.");					
				}
				
			}
		} else if (transferamount >= 1000) {
			
			$(".transaction-amount-message-field").html("High value transaction.");
			$(".transaction-policy-message-field").html("This will require <b>fingerprint</b> 2FA");
			
			if (check_transfer.allowed == true) {
				$("#transfer_mmfa").css("border", "2px solid green");
			} else {
				$("#transfer_mmfa").css("border", "2px solid orange");
				if (check_transfer.reason == "none"){
					$(".transaction-policy-message-field").html("Please add a device for this transaction.");					
				}else if(check_transfer.reason == "no-touch"){
					$(".transaction-policy-message-field").html("Please add Fingerprint Authentication.");					
				}else{
					$(".transaction-policy-message-field").html("Please check your device.");					
				}
			}
		} else {
			$(".transaction-amount-message-field").html("");
			$(".transaction-policy-message-field").html("");
		}
	} else {
		$(".transaction-amount-message-field").html("");
		$(".transaction-policy-message-field").html("");
		$("#transfer_mmfa").css("border", "2px solid red");
	}
}

//END Transfer Amount field change----------------------------


//START Login Method Switch-----------------------------------
function enableForm() {
	//Change text
	$(".ibmsy-h1.light").text("Sign-in to your Big Blue Account");
	
	$(".ibm-login-text-blue-id").addClass("hidden");
	$(".ibm-login-text-verify ").removeClass("hidden");
	
	$("#ibm_already_registered").toggleClass("hidden");
	
	//Change buttons & text field
	$("#blueid_login_button").toggleClass("hidden");
	
	$("#field_column").toggleClass("hidden-xs-up");
	$("#field_column").toggleClass("col-xs-11");

	$("#username_mmfa").css("height", "55px");
	$("#username_mmfa").toggleClass("hidden");
	
	$("#submit_mmfa").toggleClass("hidden");
	
	//Change Image
	$("#ibm-login-image").attr("src", "/content/static/img/design-team/Bank-Login.svg");
	$("#ibm-login-image").css("top", "20px");

	//Add Re-Captcha
	$("#html_element").css("display", "block");	
	// $("#html_element").addClass("scale-recaptcha");	
	if ($("#html_element").html() == "") {
		if (typeof grecaptcha == "undefined") {
			setTimeout(function() {
				grecaptcha.render('html_element', {
					'sitekey': '6LchOAgUAAAAAAqUuuyy8XLDkO8LJOq-bCLynVoj',
					'callback': usernameSubmit,
					'theme': 'dark',
					'expired-callback': resubmitRecaptcha
				});
			}, 1000);
		} else {
			grecaptcha.render('html_element', {
				'sitekey': '6LchOAgUAAAAAAqUuuyy8XLDkO8LJOq-bCLynVoj',
				'callback': usernameSubmit,
				'theme': 'dark',
				'expired-callback': resubmitRecaptcha
			});
		}
	} else {
		grecaptcha.reset();
	}
}

function disableForm() {
	//Change text
	$(".ibmsy-h1.light").text("Multifactor Verification Demo");
	
	$(".ibm-login-text-blue-id").removeClass("hidden");
	$(".ibm-login-text-verify").addClass("hidden");

	$("#ibm_already_registered").toggleClass("hidden");
	
	//Change buttons & text field
	$("#blueid_login_button").toggleClass("hidden");

	$("#field_column").toggleClass("hidden-xs-up");
	$("#field_column").toggleClass("col-xs-11");
	
	$("#username_mmfa").toggleClass("hidden");
	$("#username_mmfa").css("height", "0px");
	
	$("#submit_mmfa").toggleClass("hidden");
	
	//Change Image
	$("#ibm-login-image").attr("src", "/content/static/img/design-team/IBM-Login.svg");
	$("#ibm-login-image").css("top", "100px");

	//Remove Re-Captcha
	$("#html_element").css("display", "none");	
	// $("#html_element").removeClass("scale-recaptcha");
}

//END Login Method Switch-----------------------------------


// ----- TO BE DEALT WITH


$('#toggle').change(function() {
	if ($(this).is(':checked')) {
		$(".cards-active").css("border-top", "5px Solid rgb(120,0,0)");
		$("#side-nav").toggleClass("hidden");
	} else {
		$(".cards-active").css("border-top", "5px Solid rgb(65,120,190)");
		$("#side-nav").toggleClass("hidden");
	}
});




function processCookie(getRequest) {
	if (getRequest.readyState == 4) {
		if (getRequest.status == 200) {
			if (getRequest.responseText == "Not found") {} else {
				location.reload();
			}
		} else {
			location.reload();
		}
	}
}