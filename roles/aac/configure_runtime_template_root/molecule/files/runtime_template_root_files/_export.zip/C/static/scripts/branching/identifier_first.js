window.addEventListener('load', function() {
    startup();

    var jsLinks = document.querySelectorAll('[href="#"]');

    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }
});

var ifa_tags = document.currentScript.dataset;
var ifa_tagJson = JSON.parse(document.getElementById('ifa-tags').textContent);

var ifa_action = ifa_tags.action;
var ifa_rpId = ifa_tags.fidoRpId;
var ifa_timeout = ifa_tags.fidoTimeout;
var ifa_challenge = ifa_tags.fidoChallenge;
var ifa_userVerification = ifa_tags.fidoUserVerification;
var ifa_extensionsStr = ifa_tagJson["fidoExtensions"];

var ifa_optionsGetUrl = getJunctionName() + ifa_action;


function startup() {
    populateStrings();
    createEventListeners();

    var storage = window.localStorage;
    var ifaUsersObject = JSON.parse(storage.getItem('ifaUsersObject'));
    if(ifaUsersObject != null && ifaUsersObject["mostRecent"] != null) {
        document.getElementById("username").value = ifaUsersObject["mostRecent"];
        document.getElementById("remember-me").checked = true;
    }

    var usernameForm = document.getElementById('username-form');
    var fidoUsersObjectStr = storage.getItem('fidoUsersObject');
    if (fidoUsersObjectStr != null) {
        usernameForm["pairLocalStorage"].value = fidoUsersObjectStr;
    }

    document.getElementById("error-twistie").style.display = "none";

    // Continue button starts disabled, and will be enabled after evaluation of isUVPAA
    PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
        .then((isuvpaa) => {
            usernameForm["uvpaCapable"].value = isuvpaa;
            document.getElementById('username-submit').removeAttribute("disabled");
        }
    );
}

function populateStrings() {
    document.title = authsvcMsg.identifierFirstTitle;
    document.querySelector('#traditional-login-div h1').textContent = authsvcMsg.welcome;
    document.getElementById('username-label').textContent = authsvcMsg.username;
    document.getElementById('remember-me-label').textContent = authsvcMsg.rememberMe;
    document.getElementById('username-submit').value = authsvcMsg.continue;
    document.getElementById('error-title').textContent = authsvcMsg.somethingWentWrong;
    document.getElementById('error-detail').textContent = authsvcMsg.detail;
}

function createEventListeners() {
    let username = document.getElementById('username');
    var usernameSubmit = document.getElementById('username-submit');

    username.addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13
        if (event.keyCode === 13) {
            usernameSubmit.click();
        }
    });

    usernameSubmit.addEventListener("click", function(event) {
        event.preventDefault();

        hideError();

        usernameSubmit.disabled = true;

        if (abortController) {
            console.log("Abort autofill FIDO.")
            abortController.abort();
            
            // Add temporary workaround for known Safari issue with aborting autofill UI. 
            // This will be ignored when the issue is fixed, and by browsers that work 
            // correctly, as the abortController will be set to null in the catch block of the 
            // the webauthn call and the code in the catch block will call submitUsername()
            abortTimer = window.setTimeout(() => {
                    if (abortController) {
                        console.log("Performing workaround for Safari autofill abort issue");
                        submitUsername();
                    }
                }, 500);
        } else {
            submitUsername();
        }
    });

    document.getElementById("error-button").addEventListener("click", function() {
        showErrorDetail("error-twistie", "error-arrow");
    });
    document.getElementById("error-button").addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13, space is 32
        if (event.keyCode === 13 || event.keyCode == 32) {
            this.click();
        }
    });
}

function showError(errMsg) {
    document.getElementById("error-msg").style.visibility = "visible";
    document.getElementById("error-content").textContent = errMsg;
}

function hideError() {
    document.getElementById("error-msg").style.visibility = "hidden";
    document.getElementById("error-content").textContent = "";
}

function showErrorDetail(divId, svgId) {
    var currentDisplay = document.getElementById(divId).style.display;
    document.getElementById(svgId).classList.toggle("active");
    if(currentDisplay == "none") {
        document.getElementById(divId).style.display = "block";
    } else {
        document.getElementById(divId).style.display = "none";
    }
}

function submitUsername() {
    document.getElementById("error-msg").style.visible = "hidden";

    var usernameForm = document.getElementById('username-form');
    let username = document.getElementById('username').value;
    var usernameSubmit = document.getElementById('username-submit');

    var rememberMe = document.getElementById('remember-me').checked;
    var storage = window.localStorage;
    var ifaUsersObject = JSON.parse(storage.getItem('ifaUsersObject'));
    if(ifaUsersObject == null) {
        ifaUsersObject = {};
    }
    ifaUsersObject["rememberMe"] = rememberMe;
    storage.setItem('ifaUsersObject', JSON.stringify(ifaUsersObject));

    var valid = true;
    usernameForm.username.value = encodeURI(username);

    if (username == "") {
        document.getElementById('username').required = 'true';
        valid = false;
        usernameSubmit.disabled = false;
    }
    if (valid) {
        usernameSubmit.disabled = true;
        usernameForm.submit();
    }
}

// Only initiate autofill FIDO if we have FIDO parameters. This will
// usually only occur if FIDO is not enabled.
if(ifa_challenge != null && ifa_challenge != "") {
    if (navigator.credentials.conditionalMediationSupported) {
        kickoffAutofill();

    } else if (PublicKeyCredential.isConditionalMediationAvailable != null) {
        PublicKeyCredential.isConditionalMediationAvailable()
        .then((result) => {
            if (result) {
                kickoffAutofill();
            }
        })
    }
}

let abortController;
let abortSignal;
let abortTimer;

function kickoffAutofill() {
    console.log("Autofill UI is supported by this browser, invoke credentials.get")

    publicKey = {
        "rpId": ifa_rpId,
        "timeout": ifa_timeout,
        "challenge": base64URLDecode(ifa_challenge)
    };

    if(ifa_userVerification != null && ifa_userVerification != "") {
        publicKey["userVerification"] = ifa_userVerification;
    }

    if(ifa_extensionsStr != null && ifa_extensionsStr != "") {
        publicKey["extensions"] = JSON.parse(ifa_extensionsStr);
    }

    abortController = new AbortController();
    abortSignal = abortController.signal;

    let payload = {
        publicKey: publicKey,
        signal: abortSignal,
        mediation: "conditional"
    };

    console.log("Autofill FIDO options: " + JSON.stringify(payload));
    navigator.credentials.get(payload).then(function (assertion) {
        abortController = null;

        var url = ifa_optionsGetUrl;
        if(!url.includes("apiauthsvc")) {
            url = url.replace("authsvc", "apiauthsvc");
        }

        var assertionJson = {};
        assertionJson.id = assertion.id;
        assertionJson.rawId = base64URLEncode(assertion.rawId);
        assertionJson.clientDataJSON = base64URLEncode(assertion.response.clientDataJSON);
        assertionJson.authenticatorData = base64URLEncode(assertion.response.authenticatorData);
        assertionJson.signature = base64URLEncode(assertion.response.signature);
        assertionJson.userHandle = base64URLEncode(assertion.response.userHandle);
        assertionJson.type = assertion.type;
        assertionJson.getClientExtensionResults = JSON.stringify(assertion.getClientExtensionResults());
        assertionJson.authenticatorAttachment = assertion.authenticatorAttachment;

        // these needed at the server as well
        var usernameForm = document.getElementById('username-form');
        assertionJson.pairLocalStorage = usernameForm["pairLocalStorage"].value;
        assertionJson.uvpaCapable = usernameForm["uvpaCapable"].value;

        var request = new XMLHttpRequest();
        request.onreadystatechange = function() {

            if (request.readyState == 4) {
                if (request.responseText) {

                    var json = null;
                    try {
                        json = JSON.parse(request.responseText);
                    } catch (e) {
                        // we got a 200, but not valid JSON - that's an error
                        showError(authsvcMsg.errorAuth);
                    }

                    if(json.stateId != null || json.state != null) {
                        stateId = json.stateId != null ? json.stateId : json.state;
                        if (ifa_optionsGetUrl.indexOf('?StateId=') > 0) {
                            ifa_optionsGetUrl= ifa_optionsGetUrl.substring(0, ifa_optionsGetUrl.indexOf('=') + 1);
                            ifa_optionsGetUrl = ifa_optionsGetUrl + stateId;
                        }
                    }

                    if(json.location != null) {
                        document.getElementById("username-form").action = json.location.replace("apiauthsvc","authsvc");
                        document.getElementById("ping-pong-form").action = json.location.replace("apiauthsvc","authsvc");
                    }

                    if(json != null && json.status == "ok") {
                        sendFIDOSuccess(json["location"]);
                    } else {
                        document.getElementById("username-submit").disabled = false;
                        document.getElementById("username").disabled = false;
                        document.getElementById("remember-me").disabled = false;

                        // Bad response, show an error.
                        errorMsg = authsvcMsg.errorAuth;
                        if(json.error != null) {
                            errorMsg = json.error;
                        } else if(json.errorMessage != null) {
                            errorMsg = json.errorMessage;
                        } else if(json.exceptionMsg != null) {
                            errorMsg = json.exceptionMsg;
                        }
                        showError(errorMsg);
                    }
                } else {
                    // No response text. Very weird. Show error.
                    showError(authsvcMsg.errorAuth);
                    document.getElementById("username-submit").disabled = false;
                    document.getElementById("username").disabled = false;
                    document.getElementById("remember-me").disabled = false;
                }
            } else {
                // readyState is not 4, that's ok, just continue.
            }
        };

        request.open("PUT", url);
        request.setRequestHeader("Content-type", "application/json");
        request.setRequestHeader("Accept", "application/json");
        request.send(JSON.stringify(assertionJson));

        document.getElementById("username-submit").disabled = true;
        document.getElementById("username").disabled = true;
        document.getElementById("remember-me").disabled = true;

    }).catch(function (err) {
        if (err.name == "AbortError") {
            if (abortTimer) {
                window.clearTimeout(abortTimer);
                abortTimer = null;
            }
            abortController = null;
            console.log("Autofill request aborted, submit username request.");
            submitUsername();
            return;
        }
    });
}
