window.addEventListener('load', startup);

var f2p_rd__localDataset = document.currentScript.dataset;

var f2p_rd_fidoStorage = window.localStorage;

function populateStrings() {
    document.title = authsvcMsg.howToFIDOTitle;
    document.querySelector('h1').textContent = authsvcMsg.signInFaster;
    document.getElementById('firstLine').textContent = authsvcMsg.fido2FirstLine;
    document.getElementById('secondLine').textContent = authsvcMsg.fido2SecondLine;
    document.getElementById('registerButton').textContent = authsvcMsg.fido2Yes;
    document.getElementById('skipOnceButton').textContent = authsvcMsg.fido2NotNow;
    document.getElementById('skipForeverButton').textContent = authsvcMsg.fido2Never;
    document.getElementById('warning').textContent = authsvcMsg.fileUpdateMessage;
}

function createEventListeners() {
    var fidoForm = document.getElementById('solicit_fido_registration');

    var registerButton = document.getElementById('registerButton');
    registerButton.addEventListener("click", function(event) {
        fidoForm.type.value = "fido2";
        fidoForm.submit();
    });

    var skipOnceButton = document.getElementById('skipOnceButton');
    skipOnceButton.addEventListener("click", function(event) {
        fidoForm.skip.value = "skip";
        fidoForm.submit();
    });

    var skipForeverButton = document.getElementById('skipForeverButton');
    skipForeverButton.addEventListener("click", function(event) {
        fidoForm.type.value = "skip";
        // Also add to browser storage to never ask again
        var fidoUser = {};
        fidoUser.username = f2p_rd__localDataset.username;
        fidoUser.rawId = "nil";
        fidoUser.skip = true;

        var fidoUsersObject = JSON.parse(f2p_rd_fidoStorage.getItem('fidoUsersObject'));
        var fidoUsers = new Array();

        if (fidoUsersObject == null) {
            fidoUsersObject = {};
        } else if (fidoUsersObject.fidoUsers) {
            fidoUsers = fidoUsersObject.fidoUsers;
        }
        
        fidoUsers.push(fidoUser);
        fidoUsersObject.fidoUsers = fidoUsers;

        f2p_rd_fidoStorage.setItem('fidoUsersObject', JSON.stringify(fidoUsersObject));

        fidoForm.skip.value = "skip";
        fidoForm.submit();
    });
}

function detectSkip() {
    // Get entries from browser local storage and detect whether current user has
    // previously selected to skip FIDO2 registration.
    // If so, skip registration decision.

    var skip = false;
    var fidoUsersObject = JSON.parse(f2p_rd_fidoStorage.getItem('fidoUsersObject'));
    if (fidoUsersObject != null) {
        var fidoUsers = fidoUsersObject.fidoUsers;
        if (fidoUsers.find(user =>
            (user.username != null && user.username != "" && user.username.toLowerCase() === f2p_rd__localDataset.username.toLowerCase()))) {
            // FIDO found. Skipping...
            skip = true;
        }
    }

    if (skip) {
        var content = document.getElementById('bx--layout-right');
        content.visible = 'false';
        var fidoForm = document.getElementById('solicit_fido_registration');
        fidoForm.skip.value = "skip";
        fidoForm.submit();
    }
}

function startup() {
    populateStrings();
    createEventListeners();
    detectSkip();
}
