window.addEventListener("load", startup);

var getRequest = null;
var authMechanismInstanceId = "";
var resourceURL = knowledgeQuestionBaseUrl;
var maxNumberOfStoredQuestion = getMaxStoredQuestions();

authMechanismInstanceId = getMechIdFromPath();

if (authMechanismInstanceId) {
  resourceURL = getResourceURL(authMechanismInstanceId);
}

if (resourceURL) {
  getUserQuestions();
}

function getUserQuestions() {
  makeAjaxRequest("GET", resourceURL, processGetQuestionsRequest, null);
}

function processGetQuestionsRequest(getRequest) {
  if (getRequest.readyState == 4) {
    if (getRequest.status == 200) {
      if (getRequest.responseText == "Not found") {} else {
        var userQuestions = JSON.parse(getRequest.responseText);
        createQuestionsTable(userQuestions['questions']);
      }
    } else {
      if (getRequest.responseText == "Not found") {} else {
        if (getRequest.responseText) {
          var result = JSON.parse(getRequest.responseText);
          printWarning(result['result']);
        }
      }
    }
  }
}

function createQuestionsTable(questions) {
  var table = document.getElementById("questionsTable");

  var questionsArray = getDefaultQuestions();
  var questionsArrayUniqueIds = getDefaultQuestionsUniqueId();

  for (var i = 0; i < maxNumberOfStoredQuestion; i++) {

    var question = null;

    if (questions != null && questions.length > i) {
      question = questions[i];
    }

    var tr = table.insertRow(-1);
    var questionTd = tr.insertCell(-1);
    var questionValueTd = tr.insertCell(-1);
    var questionSelectDiv = document.createElement('div');
    questionSelectDiv.className = 'select-editable';

    var questionSelect = document.createElement('select');
    questionSelect.name = 'knowledge.question.' + i;
    questionSelect.id = 'knowledge.question.' + i;
    questionSelect.onchange = function() {
      var displayElementId = this.name + ".text.value";
      var textElement = document.getElementById(displayElementId);
      textElement.value = this.options[this.selectedIndex].text;

      if (this.selectedIndex == 0) {
        textElement.readOnly = false;
      } else {
        textElement.readOnly = true;
      }

      var answerElementId = this.name + ".answer";
      document.getElementById(answerElementId).value = "";
    };

    var defaultOption = document.createElement("option");
    questionSelect.appendChild(defaultOption);

    for (var j = 0; j < questionsArray.length; j++) {
      var option = document.createElement("option");
      option.setAttribute("value", questionsArrayUniqueIds[j]);
      option.innerHTML = questionsArray[j];

      if (question != null && questionsArrayUniqueIds[j] == question['id']) {
        option.setAttribute("selected", "selected");
      }
      questionSelect.appendChild(option);
    }

    questionSelectDiv.appendChild(questionSelect);

    var questionTextValue = document.createElement('input');
    questionTextValue.id = 'knowledge.question.' + i + '.text.value';
    questionTextValue.type = 'text';
    questionTextValue.onfocus = function() {
      this.select();
    };
    questionTextValue.name = 'knowledge.question.' + i + '.text.value';

    if (question != null && question['question'] != null && question['question'] != "") {
      questionTextValue.value = question['question'];
      defaultOption.setAttribute("selected", "selected");

      if (question['id'] != null && question['id'] != "") {
        defaultOption.setAttribute("value", question['id']);
      }
    } else {
      questionTextValue.value = questionSelect.options[questionSelect.selectedIndex].text;
    }

    questionSelectDiv.appendChild(questionTextValue);
    questionTd.appendChild(questionSelectDiv);

    var questionAnswerValue = document.createElement('input');
    questionAnswerValue.type = 'text';
    questionAnswerValue.name = 'knowledge.question.' + i + '.answer';
    questionAnswerValue.id = 'knowledge.question.' + i + '.answer';
    questionAnswerValue.size = '60';
    questionAnswerValue.maxlength = '60';

    if (question != null && question['answer'] != null) {
      questionAnswerValue.value = question['answer'];
    }

    questionValueTd.appendChild(questionAnswerValue);
  }
}

storeQuestionsRequest = null;

function storeUserQuestions() {

  var json = {};
  var questionsJson = [];

  for (var i = 0; i < maxNumberOfStoredQuestion; i++) {
    var select = document.getElementById("knowledge.question." + i);
    var uniqueId = select.value;

    var answerText = document.getElementById("knowledge.question." + i + ".answer");
    var answer = answerText.value;

    var questionText = document.getElementById("knowledge.question." + i + ".text.value");
    var question = questionText.value;

    questionsJson.push({
      "id": uniqueId,
      "answer": answer,
      "question": question
    });

  }

  if (questionsJson != null && questionsJson != "") {
    json['questions'] = questionsJson;
  }

  storeQuestionsRequest = new XMLHttpRequest();
  storeQuestionsRequest.onreadystatechange = processStoreUserQuestionsRequest;
  storeQuestionsRequest.open("PUT", resourceURL, true);
  storeQuestionsRequest.setRequestHeader("Content-type", "application/json");
  storeQuestionsRequest.send(JSON.stringify(json));
}

function processStoreUserQuestionsRequest() {
  if (storeQuestionsRequest.readyState == 4) {
    if (storeQuestionsRequest.status == 204) {
      if (storeQuestionsRequest.responseText == "Not found") {} else {
        location.reload();
      }
    } else {
      if (storeQuestionsRequest.responseText == "Not found") {} else {
        if (storeQuestionsRequest.responseText) {
          var result = JSON.parse(storeQuestionsRequest.responseText);
          printWarning(result['result']);
        }
      }
    }
  }
}

deleteRequest = null;

function deleteAllQuestions() {
  makeAjaxRequest("DELETE", resourceURL, processDeleteRequest, null);
}

function processDeleteRequest(deleteRequest) {

  if (deleteRequest.readyState == 4) {
    if (deleteRequest.status == 204) {
      if (deleteRequest.responseText == "Not found") {} else {
        location.reload();
      }
    } else {
      if (deleteRequest.responseText == "Not found") {} else {
        if (deleteRequest.responseText) {
          var result = JSON.parse(deleteRequest.responseText);
          printWarning(result['result']);
        }
      }
    }
  }
}

function getResourceURL(authMechanismInstanceId) {
  return resourceURL + "/" + authMechanismInstanceId;
}

function getMechIdFromPath() {
  var queryString = window.location.search.substring(1);
  var params = queryString.split("&");
  for (var i = 0; i < params.length; i++) {
    var keyValue = params[i].split("=");
    if (keyValue[0] == "id") {
      return keyValue[1];
    }
  }
  return null;
}

function getDefaultQuestions() {
  var questionsArray = [mgmtMsg.mothersMdnName,
    mgmtMsg.birthTown,
    mgmtMsg.firstPet
  ];
  return questionsArray;
}

function getDefaultQuestionsUniqueId() {
  var questionsArrayUniqueIds = ["1",
    "2",
    "3"
  ];
  return questionsArrayUniqueIds;
}

function getMaxStoredQuestions() {
  var maxStoredQuestions = "@MAX_STORED_QUESTIONS@";
  return maxStoredQuestions;
}

function printWarning(message) {
  var messageDiv = document.getElementById('errorDiv');
  messageDiv.className = "hidden";
  var messageElem = document.getElementById('errorMessage');
  messageElem.textContent = message;
  messageDiv.className = "errorMessage";
}

function testInput(required, questionText, fieldVal) {
  var illegalChars = /[\[\(\)\<\>\,\;\:\\\/\"\[\]\=]/g;
  if (required && fieldVal == "") {
    var missingInputStr = mgmtMsg.provideAnswer + questionText;
    printWarning(missingInputStr);
    return false;
  }
  if (fieldVal.match(illegalChars)) {
    var illegalCharsStr = mgmtMsg.invalidChars + "[ ] \\ / < > ( ) , ; : \" = ";
    var invalidCharsFieldStr = mgmtMsg.illegalChars + questionText + "<br>" + illegalCharsStr;
    printWarning(invalidCharsFieldStr);
    return false;
  }
  return true;
}

function doStoreQuestionsSubmit() {

  var maxNumberOfStoredQuestion = getMaxStoredQuestions();
  var minimumSpecified = false;

  for (var i = 0; i < maxNumberOfStoredQuestion; i++) {

    var questionText = document.getElementById("knowledge.question." + i + ".text.value");
    var question = questionText.value;

    if (question != null && question != "") {

      var answerText = document.getElementById("knowledge.question." + i + ".answer");
      var answer = answerText.value;

      if (!testInput(true, question, answer.trim())) {
        return true;
      } else {
        minimumSpecified = true;
      }
    }
  }

  if (!minimumSpecified) {
    var missingInputStr = mgmtMsg.notEnoughQuestions;
    printWarning(missingInputStr);
    return true;
  }

  storeUserQuestions();
  return true;
}

function startup() {
  document.getElementById("delete").addEventListener("click", deleteAllQuestions);
  document.getElementById("submit").addEventListener("click", doStoreQuestionsSubmit);
}