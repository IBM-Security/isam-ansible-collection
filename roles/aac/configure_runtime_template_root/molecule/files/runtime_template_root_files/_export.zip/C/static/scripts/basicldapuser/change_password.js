window.addEventListener('load', (event) => {
    onLoadPage();
    var skipNow = document.getElementById("skipNow");
    if(skipNow) {
        skipNow.addEventListener('click', function() {
            this.form.operation.value = 'skip';
        });
    }
    document.getElementById("changePwd").addEventListener('click', function() {
        this.form.operation.value = 'verify';
    });
});

var ldap_cp_dataVals = document.currentScript.dataset;
var ldap_cp_errormsg = ldap_cp_dataVals.errorMessage;

function onLoadPage() {
    hideSkipNow();
    showError();
    setFocus();
}

function showError() {
    var elem = document.getElementById("errId");
    if (ldap_cp_errormsg == "") {
        elem.className = "";
    } else {
        elem.className = "errorMessage";
    }
}

function hideSkipNow() {
    var elem = document.getElementById("skipNow");
    if ("@PASSWORDWARNING@" != "true") {
        elem.parentNode.removeChild(elem);
    }
}

function setFocus() {
    document.getElementById("newpassword").focus();
}
