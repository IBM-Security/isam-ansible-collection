window.addEventListener('load', function() {
    startup();
    document.getElementById("registerButton").addEventListener('click', optionsGet);

    var styleChange = [];

    var bl1 = document.getElementById("rm_back_link_1");
    bl1.addEventListener("click", back);
    styleChange.push(bl1);

    var bl2 = document.getElementById("rm_back_link_2");
    bl2.addEventListener("click", retry);
    styleChange.push(bl2);

    var bl3 = document.getElementById("rm_back_link_3");
    bl3.addEventListener("click", retry);
    styleChange.push(bl3);

    for (var x = 0; x < styleChange.length; x++) {
        styleChange[x].style = "background-image: url('/'" + getJunctionName() + "'/sps/static/design_images/back-light.svg');"
    }

    document.getElementById("nickname").addEventListener('input', function() {
        checkValid(document.getElementById("nickname"))
    });
    document.getElementById("saveButton").addEventListener('click', submitFIDONickname);

    var jsLinks = document.querySelectorAll('[href="#"]');

    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }
});

var f2p_rm_dataTags = document.currentScript.dataset;

var f2p_rm_errorMessage = f2p_rm_dataTags.fidoErrorMessage;
var f2p_rm_stateId = f2p_rm_dataTags.state;
var f2p_rm_action = f2p_rm_dataTags.action;

var f2p_rm_publicKey = null;
var f2p_rm_createResult = null;

var f2p_rm_fidoStorage = window.localStorage;

// Safari 3.0+ "[object HTMLElementConstructor]"
var f2p_rm_isSafari = /constructor/i.test(window.HTMLElement) || (function(p) {
    return p.toString() === "[object SafariRemoteNotification]";
})(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

function cancel() {
    document.getElementById("cancelForm").submit();
}

function back() {
    document.getElementById("backForm").submit();
}

function base64URLEncodeJSON(json) {
    var str = JSON.stringify(json);
    var result = utf8tob64u(str);
    return result;
}

function base64URLEncode(bytes, encoding = 'utf-8') {
    if(bytes == null || bytes.length == 0) {
        return null;
    }
    var str = base64js.fromByteArray(new Uint8Array(bytes));
    str = str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    return str;
}

function base64URLDecode(str, encoding = 'utf-8') {
    if(str == null || str == "") {
        return null;
    }

    var str = str.replace(/-/g, '+').replace(/_/g, '\/');

    var pad = str.length % 4;
    if(pad) {
        str += new Array(5-pad).join('=');
    }

    var bytes = base64js.toByteArray(str);
    return bytes.buffer;
}

function populateStrings() {
    document.title = authsvcMsg.fido2Registration;
    document.querySelector('#attestation-section h1').textContent = authsvcMsg.letsRegisterFIDO;
    document.querySelector('#attestation-section p').textContent = authsvcMsg.fido2Instructions;
    document.getElementById("registerButton").value = authsvcMsg.letsGo;

    document.getElementById("saveButton").value = authsvcMsg.save;

    document.querySelector("#error-section h1").textContent = authsvcMsg.errorLabel;

    document.getElementById("error_img").src=getJunctionName()+"/sps/static/design_images/u2f_error.svg";
    document.getElementById("welcome_img").src=getJunctionName()+"/sps/static/design_images/u2f_device.svg";
    document.getElementById("nickname_img").src=getJunctionName()+"/sps/static/design_images/u2f_device.svg";
}

function startup() {
    populateStrings();
}

function optionsGet() {
    f2p_rm_createResult = null;

    var url = getJunctionName() + f2p_rm_action;
    if(!url.includes("apiauthsvc")) {
        url = url.replace("authsvc", "apiauthsvc");
    }

    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {

        if (request.readyState == 4) {
            if (request.responseText) {

                var json = null;
                try {
                    json = JSON.parse(request.responseText);
                } catch (e) {
                    // we got a 200, but not valid JSON - that's an error
                    showError(authsvcMsg.badOptionsRequest);
                }

                if(json != null) {

                    if(json.stateId != null) {
                        document.getElementById("attestationForm").StateId.value = json.stateId;
                        document.getElementById("backForm").StateId.value = json.stateId;
                        f2p_rm_stateId = json.stateId;
                    }

                    if(json.location != null) {
                        document.getElementById("cancelForm").action = json.location.replace("apiauthsvc","authsvc") + "&operation=cancel";
                    }

                    if(request.status == 200) {
                        credentialsGet(json);

                    } else {
                        // Response wasn't a 200. Show error.
                        var errorMsg = authsvcMsg.badOptionsRequest;
                        if(json.error != null) {
                            errorMsg = json.error;
                        } else if(json.errorMessage != null) {
                            errorMsg = json.errorMessage;
                        } else if(json.exceptionMsg != null) {
                            errorMsg = json.exceptionMsg;
                        }
                        showError(errorMsg);
                    }

                } else {
                    // Response isn't json. Very weird. Show error.
                    showError(authsvcMsg.badOptionsRequest);
                }
            } else {
                // No response text. Very weird. Show error.
                showError(authsvcMsg.badOptionsRequest);
            }
        } else {
            // readyState is not 4, that's ok, just continue.
        }
    };

    request.open("POST", url);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");

    request.send(JSON.stringify({"StateId": f2p_rm_stateId}));
}

function credentialsGet(options) {
    document.getElementById("registerButton").disabled = true;
    f2p_rm_createResult = null;

    let publicKey = JSON.parse(JSON.stringify(options), (key, value) => {
        if (value == null || value == '' || value == [] || value == {}) {
            return undefined;
        }
        return value;
    });

    // remove the status and errorMessage keys

    if(("status" in publicKey) == true) {
        delete publicKey['status'];
    }
    if(("errorMessage" in publicKey) == true) {
        delete publicKey['errorMessage'];
    }
    if(("mechanism" in publicKey) == true) {
        delete publicKey['mechanism'];
    }
    if(("location" in publicKey) == true) {
        delete publicKey['location'];
    }
    if(("stateId" in publicKey) == true) {
        delete publicKey['stateId'];
    }
    if(("excludeCredentials" in publicKey) == true) {
        delete publicKey['excludeCredentials'];
    }

    publicKey.challenge = base64URLDecode(publicKey.challenge);
    publicKey.user.id = base64URLDecode(publicKey.user.id);

    if (navigator.userAgent.toLowerCase().indexOf("android") > -1) {
        publicKey.requireResidentKey = false;
    }

    navigator.credentials.create({ publicKey }).then(function (attestation) {
        f2p_rm_createResult = attestation;

        document.getElementById("attestation-section").classList.remove('notransition');
        document.getElementById("attestation-section").classList.remove('bx--dialog-content--visible');
        document.getElementById("attestation-section").classList.add('bx--dialog-content--hidden');
        setTimeout(function () {
            document.getElementById("attestation-section").style.left = '-100%';
        }, 300);
        submitFIDONickname();

    }).catch(function (err) {
        document.getElementById("registerButton").disabled = false;
        showError(err);
    });
}

function submitFIDONickname() {
    var fidoNickname = navigator.platform + " - " + new Date().toLocaleString();
    var attestationForm = document.getElementById("attestationForm");

    // Store credential and username in local storage
    var fidoUser = {};
    fidoUser.username = f2p_rm_dataTags.fidoUsername;
    if (getOS() == "Windows") {
        fidoUser.rawId = "";
    } else {
        fidoUser.rawId = base64URLEncode(f2p_rm_createResult.rawId);
    }
    fidoUser.skip = false;

    var fidoUsersObject = checkLocalStorage();
    var fidoUsers;

    if (fidoUsersObject == null) {
        fidoUsersObject = {};
        fidoUsers = new Array();
    } else {
        fidoUsersObject = JSON.parse(fidoUsersObject);
        fidoUsers = fidoUsersObject.fidoUsers;
    }

    fidoUsers.push(fidoUser);

    fidoUsersObject.fidoUsers = fidoUsers;
    fidoUsersObject.mostRecent = fidoUser.username;

    updateLocalStorage(fidoUsersObject);

    attestationForm.id.value = f2p_rm_createResult.id;
    attestationForm.rawId.value = base64URLEncode(f2p_rm_createResult.rawId);
    attestationForm.clientDataJSON.value = base64URLEncode(f2p_rm_createResult.response.clientDataJSON);
    attestationForm.attestationObject.value = base64URLEncode(f2p_rm_createResult.response.attestationObject);
    attestationForm.type.value = f2p_rm_createResult.type;
    attestationForm.nickname.value = fidoNickname;
    attestationForm.getClientExtensionResults.value = base64URLEncodeJSON(f2p_rm_createResult.getClientExtensionResults());

    if (f2p_rm_createResult.response.getTransports !== undefined) {
        attestationForm.getTransports.value = base64URLEncodeJSON(f2p_rm_createResult.response.getTransports());
    }
    attestationForm.authenticatorAttachment.value = f2p_rm_createResult.authenticatorAttachment;

    attestationForm.submit();
    document.getElementById("saveButton").disabled = false;
}

function checkLocalStorage() {
    var fidoUsersObject = f2p_rm_fidoStorage.getItem('fidoUsersObject');
    return fidoUsersObject;
}

function updateLocalStorage(fidoUsersObject) {
    f2p_rm_fidoStorage.setItem('fidoUsersObject', JSON.stringify(fidoUsersObject));
}

function retry() {
    var divToHide = "error-section";
    if(document.getElementById("nickname-section").classList.contains('bx--dialog-content--visible')) {
        divToHide = "nickname-section";
    }

    document.getElementById(divToHide).classList.remove('bx--dialog-content--visible');
    document.getElementById(divToHide).classList.add('bx--dialog-content--hidden');
    setTimeout(function () {
        document.getElementById(divToHide).style.left = '100%';
    }, 300);
    document.getElementById("attestation-section").style.left = '';
    document.getElementById("attestation-section").classList.add('bx--dialog-content--visible');
    document.getElementById("attestation-section").classList.remove('bx--dialog-content--hidden');
    document.getElementById("registerButton").disabled = false;
}

function getOS() {
    var OSName="Unknown OS";
    if (navigator.appVersion.indexOf("Win")!=-1) OSName="Windows";
    if (navigator.appVersion.indexOf("Mac")!=-1) OSName="MacOS";
    if (navigator.appVersion.indexOf("X11")!=-1) OSName="UNIX";
    if (navigator.appVersion.indexOf("Linux")!=-1) OSName="Linux";
    return OSName;
}

function checkValid(input) {
    var valid = false;
    var value = input.value;
    if(value != null && value != "" && input.validity.valid) {
        valid = true;
    }
    if(valid) {
        if (input.classList.contains('input-invalid')) {
            input.classList.remove('input-invalid');
        }
    } else {
        input.classList.add('input-invalid');
    }
    document.getElementById("saveButton").disabled = !valid;

    return valid;
}

function showError(errMsg) {
    var divToHide = "attestation-section";
    if(document.getElementById("nickname-section").classList.contains('bx--dialog-content--visible')) {
        divToHide = "nickname-section";
    }

    document.getElementById(divToHide).classList.remove('notransition');
    document.getElementById(divToHide).classList.remove('bx--dialog-content--visible');
    document.getElementById(divToHide).classList.add('bx--dialog-content--hidden');
    setTimeout(function () {
        document.getElementById(divToHide).style.left = '-100%';
    }, 300);
    document.getElementById("error-section").style.left = '';
    document.getElementById("error-section").classList.add('bx--dialog-content--visible');
    document.getElementById("error-section").classList.remove('bx--dialog-content--hidden');
    document.getElementById("errorMessage").textContent = errMsg;
}