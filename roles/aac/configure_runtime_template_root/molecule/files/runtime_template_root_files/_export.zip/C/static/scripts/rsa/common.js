window.addEventListener("load", startup);

var rsa_errorMessage = document.currentScript.dataset.errorMessage;

function displayError() {
    if (rsa_errorMessage != "") {
        var errorMsg = document.getElementById("errorMessage");
        errorMsg.textContent = errorMsg.textContent + rsa_errorMessage;

        var errorDiv = document.getElementById("errorDiv");
        errorDiv.className = "errorMessage visible";
    }
}

function startup() {
    displayError();
}
