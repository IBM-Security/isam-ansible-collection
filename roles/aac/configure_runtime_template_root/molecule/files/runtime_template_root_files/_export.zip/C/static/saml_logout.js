function displayMessage(){
    var messageDiv = document.getElementById("messageDiv");
    var username   = "@TOKEN:UserName@";

    if (username == "null") {
        messageDiv.innerHTML = "No user to logout.";
    } else {
        messageDiv.innerHTML = "Successfully completed single sign out for user " + username + ".";                
    }
}

window.onload = function() {
    displayMessage();
};