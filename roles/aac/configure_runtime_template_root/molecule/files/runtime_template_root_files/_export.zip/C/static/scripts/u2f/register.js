window.addEventListener("load", startup);

var u2fr_data_tags = document.getElementById('u2f_register_tag');
var u2fr_datasetValues = u2fr_data_tags.dataset;
var u2fr_existingTokens = [];
var u2fr_queryString = "initiate=true";
var u2fr_url = window.location.href;
var u2fr_challenge = u2fr_datasetValues.u2fChallenge;
var u2fr_version = u2fr_datasetValues.u2fVersion;
var u2fr_appid = u2fr_datasetValues.u2fAppId;
var u2fr_cancelAction = u2fr_datasetValues.cancelAction;

var u2fr_registerRequest = {
    "challenge": u2fr_challenge,
    "version": u2fr_version,
    "appId": u2fr_appid
};

var u2frJSON = JSON.parse(u2fr_data_tags.textContent);
var u2fr_existingTokenString = u2frJSON["u2fTokens"];

if (u2fr_url.includes(u2fr_queryString)) {
    registerToken(u2fr_registerRequest);
}

function registerToken() {
    var filteredTokens = []
    for (var token in u2fr_existingTokens) {
        if (token['appId'] == u2fr_registerRequest.appId) {
            filteredTokens.push(token);
        }
    }
    if (u2f != null) {
        u2f.register(u2fr_registerRequest.appId,
            [{
                version: u2fr_registerRequest.version,
                challenge: u2fr_registerRequest.challenge
            }],
            filteredTokens,
            function(response) {
                document.getElementById("registrationPopup").style.display = 'none';
                if (response.errorCode) {
                    var errMsg = i18nMsg.error;
                    if (response.errorCode == 2 | response.errorCode == 4) {
                        errMsg = i18nMsg.errorAlreadyRego;
                    } else if (response.errorCode == 5) {
                        errMsg = i18nMsg.errorTimedOut;
                    }
                    showError(errMsg);
                }
                // sanity check of response data before prompting for friendly name
                else if (response["registrationData"] != null) {
                    registerResponse = response;
                    document.getElementById("namePopup").style.display = 'block';
                    document.getElementById("friendlyName").focus();
                }
            },
            300
        );
        document.getElementById("registrationPopup").style.display = 'block';

    } else {
        showError(i18nMsg.error);
    }
}

function submit() {
    var name = document.getElementById("friendlyName").value;

    document.getElementById("registerForm").name.value = name;
    document.getElementById("registerForm").clientData.value = registerResponse.clientData;
    document.getElementById("registerForm").registrationData.value = registerResponse.registrationData;

    document.getElementById("friendlyName").value = "";

    document.getElementById("namePopup").style.display = 'none';
    document.getElementById("registerForm").submit();
}

function cancel() {
    document.getElementById("namePopup").style.display = 'none';
}

function enableToken(id, enabled) {
    document.getElementById("updateForm").id.value = id;
    document.getElementById("updateForm").enabled.value = enabled;
    document.getElementById("updateForm").submit();
}

function remove(id) {
    document.getElementById("removeForm").id.value = id;
    document.getElementById("removeForm").submit();
}

function createU2FTokensTable() {
    var tokens = (u2fr_existingTokenString != undefined)?JSON.parse(JSON.stringify(u2fr_existingTokenString)):[];

    var table = document.getElementById("u2fTokenTable");
    var removeString = document.getElementById("removeString").innerHTML;

    for (var i = 0; i < tokens.length; i++) {
        var token = tokens[i];
        var tr = table.insertRow(-1);

        var idTd = tr.insertCell(-1);
        var nameTd = tr.insertCell(-1);
        var appIdTd = tr.insertCell(-1);
        var enabledTd = tr.insertCell(-1);
        var deleteTd = tr.insertCell(-1);

        var id = token['id'];
        if (id != null && id != "") {
            idTd.innerHTML = id;
        }

        var name = token['name'];
        if (name != null && name != "") {
            nameTd.textContent = name;
        }

        var appId = token['app_id'];
        if (appId != null) {
            appIdTd.textContent = appId;
        }

        var enabledBox = document.createElement('input');
        enabledBox.type = 'checkbox';
        enabledBox.name = 'enabled';
        enabledBox.checked = token['enabled'];
        enabledBox.id = token['id'];
        enabledBox.onclick = function() {
            enableToken(this.id, this.checked);
        };
        enabledTd.appendChild(enabledBox);

        var input = document.createElement('input');
        input.className = "button-1 ease-in-anim-fast";
        input.type = "button";
        input.value = i18nMsg.remove;
        input.style = "margin: 0";
        input.id = token['id'];
        input.onclick = function() {
            remove(this.id);
        };
        deleteTd.appendChild(input);

        var existingToken = {
            keyHandle: token['key_handle'],
            version: u2fr_registerRequest.version,
            appId: token['app_id']
        };
        u2fr_existingTokens.push(existingToken);
    }
}

function processDeleteRequest(deleteRequest) {
    if (deleteRequest.readyState == 4 && (deleteRequest.status == 200 ||
            deleteRequest.status == 204)) {
        if (deleteRequest.responseText == "Not found") {} else {
            location.reload();
        }
    }
}

function validateName() {
    if (document.getElementById("friendlyName").value &&
            document.getElementById("friendlyName").value.trim() != "") {
        document.getElementById("submitButton").disabled = false;
    } else {
        document.getElementById("submitButton").disabled = true;
    }
}

function showError(errMsg) {
    document.getElementById("errId").innerHTML = errMsg;
    document.getElementById("error-box").className = "error-box active";
}

function populateStrings() {
    document.title = i18nMsg.titleRego;
    document.getElementById("pageTitle").textContent = i18nMsg.regoPageTitle;
    document.getElementById("removeString").textContent = i18nMsg.remove;
    document.getElementById("registerButton").value = i18nMsg.register;
    document.getElementById("td_id").textContent = i18nMsg.id;
    document.getElementById("td_name").textContent = i18nMsg.name;
    document.getElementById("td_appId").textContent = i18nMsg.appId;
    document.getElementById("td_enabled").textContent = i18nMsg.enabled;
    document.getElementById("prompt").textContent = i18nMsg.prompt;
    document.getElementById("namePrompt").textContent = i18nMsg.namePrompt;
    document.getElementById("submitButton").textContent = i18nMsg.sumbit;
    document.getElementById("cancelButton").textContent = i18nMsg.cancel;
}

window.onclick = function(event) {
    if (event.target == document.getElementById("namePopup")) {
        document.getElementById("namePopup").style.display = 'none';
    }
};

window.onkeydown = function(event) {
    // keycode 27 is escape
    if (event.keyCode == 27) {
        document.getElementById("namePopup").style.display = 'none';
    }
};

function startup() {
    populateStrings();
    createU2FTokensTable();

    document.getElementById("friendlyName").addEventListener("keyup", validateName);
    document.getElementById("submitButton").addEventListener("click", submit);
    document.getElementById("cancelButton").addEventListener("click", cancel);
    document.getElementById("registerButton").addEventListener("click", registerToken);
}