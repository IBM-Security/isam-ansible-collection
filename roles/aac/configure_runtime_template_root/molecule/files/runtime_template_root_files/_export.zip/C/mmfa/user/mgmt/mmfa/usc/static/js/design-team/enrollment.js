var closeEnrollment,
learnMoreLink,
codeSwapLinks;

function toggleInfoPane () {
  var welcomeSection = document.querySelector('[data-name="section-welcome"]');
  modalBackButton.style.display = 'block';
  welcomeSection.classList.add('ibmsy-modal-content--more-info-visible');
  modalCloseButton.classList.remove('ibmsy-modal-close--dark');
  footerNav.style.display = 'none';
}

function swapConnectMethod() {
  var qrMethod = document.querySelector('.ibmsy-example-animation>.ibmsy-qr-code');
  var qrElements = document.querySelectorAll('.qr-code');

  if (qrMethod.classList.contains('ibmsy-qr-code--hidden')) {
    qrMethod.classList.remove('ibmsy-qr-code--hidden');

    for (var i = 0; i < qrElements.length; i ++) {
      qrElement = qrElements[i];
      qrElement.style.display = 'block';
      qrElement.style.visibility = 'visible';
    }

    document.querySelector('.ibmsy-code-swap-link.qr-code').focus()
  } else {
  }
}

function showCorrectCheck () {
  var outerContainer;

  if (window.innerWidth >= '768') {
    outerContainer = '[data-name="section-connectaccount"]>.ibmsy-layout-right';
    if (!document.querySelector(outerContainer).querySelector('.ibmsy-qr-code').classList.contains('ibmsy-qr-code--hidden')) {
      document.querySelector(outerContainer).querySelector('.ibmsy-qr-code>.success-check').style.display = 'block';
      document.querySelector(outerContainer).querySelector('.ibmsy-qr-code>.scan').innerHTML="<b>Scanned!</b>";
    } else {
    }
  } else {
    outerContainer = document.querySelector('[data-name="section-connectaccount"]').querySelector('.ibmsy-layout-embed');
  }
}

window.addEventListener("load", function () {
  closeEnrollment = document.querySelector('#close-enrollment');
  codeSwapLinks = document.querySelectorAll('.ibmsy-code-swap-link');
  learnMoreLink = document.querySelector('.ibmsy-learn-more-link');

  if (closeEnrollment) {
    closeEnrollment.addEventListener('click', function (event) {
      event.preventDefault();

      closeAndCleanup();
	  	if (modalOverlay != null){
			modalOverlay.classList.add('closeOverlay');
		}
		if (modalWindow != null){
	    modalWindow.classList.add('closeWindow');
		}
		
		if (modalWindow == null && modalOverlay == null){
			location.reload();
		}

      setTimeout(function() {
        ibmsyModal.style.display = 'none';
      }, 1000);
    });
  }

  if (learnMoreLink) {
    learnMoreLink.addEventListener('click', function (event) {
      event.preventDefault();
      toggleInfoPane();
    });
  }

  for (var i = 0; i < codeSwapLinks.length; i ++) {
    codeSwapLinks[i].addEventListener('click', function (event) {
      event.preventDefault();
      swapConnectMethod();
    });
  }
});
