function register_device(mode, is_popup, back_enabled){
	popup_global = is_popup;

	trace("Require NO Authentication for Device Registration", "fine");
	$("#expandAuthenticators").click();
	
	//Show the back button on the popup modal
	if (back_enabled == true) {
		modalBackButton = document.querySelector('.ibmsy-modal-back');
		modalBackButton.style.display = 'block';
	}	
}

function register_device_socket_simulate(mode) {
	var curr_authenticators = authenticators == null ? 0 : authenticators.length;
	socket_interval = setInterval(function() {
		if (typeof updateHTML != "undefined"){
			ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, updateHTML);
		}else{
			ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, null);			
		}
		var new_authenticators = authenticators == null ? 0 : authenticators.length;
		if (new_authenticators > curr_authenticators) {
			$(".success-check").css("display", "block");
			ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, null);
			setTimeout(function() {				
				clearInterval(socket_interval);
				if (mode == "normal") {
					showContentSection('section-complete');
				} else {
					showContentSection('section-complete-modal');
					finishAddDeviceButton.addEventListener('click', function() {
						finishAddDevice("Your new phone");
					});
				}
				$(".success-check").css("display", "none");
			}, 1200);
		}
	}, 1500);
}

function registerAuthenticator(mode) {
	register_device_socket_simulate(mode);
	var codeURL = null;
	if (typeof authorizeUrl != "undefined") {
		codeURL = authorizeUrl + "?client_id=" + clientId + "&response_type=code&scope=mmfaAuthn";
	} else {
		codeURL = "?client_id=" + clientId + "&response_type=code&scope=mmfaAuthn";
	}
	if (checkIfIE()) {
		window.location.href = codeURL;
	} else {
		qrCodeRequest = new XMLHttpRequest();
		qrCodeRequest.onreadystatechange = processRegisterRequest;
		qrCodeRequest.open("GET", codeURL, true);
		qrCodeRequest.send(null);
	}
}

function processRegisterRequest() {
	if (qrCodeRequest.readyState == 4 && qrCodeRequest.status == 200) {
		if (qrCodeRequest.responseText == "Not found") {} else {
			code = getQueryParamString(qrCodeRequest.responseURL, "code");
			createQRCode(code, clientId);
		}
	}
}

function createQRCode(code, clientId) {
	if (typeof junction == "undefined" || junction == null || code == null | clientId == null) {
		var userName = '<c:out value="${displayName}"/>';
		$(".qr_img").attr("src", static_path + "/img/design-team/QR-Code.png");
		displayElements("full", loading_elements_verification, null, content_elements_verification);
	} else {
		$(".qr_img").attr("src", junction + "/sps/mmfa/user/mgmt/qr_code" + buildQueryParam("code", code, true) + buildQueryParam("client_id", clientId, false));
		displayElements("full", loading_elements_verification, null, content_elements_verification);
	}
}