window.addEventListener("load", startup);

var authenticatorId = getAuthenticatorIdFromPath();
if (authenticatorId) {
    getAuthMethods(authenticatorId);
}

function getAuthMethods(authenticatorId) {
    makeAjaxRequest("GET", authenticatorsBaseUrl + "/" + authenticatorId, processGetAuthMethodsRequest, null);
}

function processGetAuthMethodsRequest(getMethodsRequest) {
    if (getMethodsRequest.readyState == 4) {
        if(getMethodsRequest.status == 200) {
            if (getMethodsRequest.responseText == "Not found") {
            } else {
                var authenticatorInfo = JSON.parse(getMethodsRequest.responseText);                
                createAuthMethodTable(authenticatorInfo["auth_methods"]);
            }
        }
    }
}

function createAuthMethodTable(authMethods) {
    var table = document.getElementById("authMethodTable");
    var removeString= document.getElementById("removeString").innerHTML;

    for(var key in authMethods) {
        var authMethod = authMethods[key];

        var tr = table.insertRow(-1);

        var nameTd = tr.insertCell(-1);
        var typeTd = tr.insertCell(-1);
        var keyHandleTd = tr.insertCell(-1);
        var algorithmTd = tr.insertCell(-1);
        var enabledTd = tr.insertCell(-1);
        var deleteTd = tr.insertCell(-1);

        nameTd.innerHTML = authMethod['id'];
        typeTd.innerHTML = authMethod['type'];
        keyHandleTd.innerHTML = authMethod['key_handle'];
        algorithmTd.innerHTML = authMethod['algorithm'];
        enabledTd.innerHTML = authMethod['enabled'];

        var a = document.createElement('a');
        a.id = authMethod['id'];
        a.onclick = function(){ deleteAuthMethod(this.id); return false; };
        a.href = "";
        a.innerHTML = removeString;
        deleteTd.appendChild(a);
    }
}

function deleteAuthMethod(authMethodId) {
    makeAjaxRequest("DELETE", authMethodBaseUrl + "/" + authMethodId, processDeleteRequest, null);
}

function getAuthenticatorIdFromPath() {
    var queryString = window.location.search.substring(1);
    var params = queryString.split("&");
    for ( var i = 0; i < params.length; i++) {
        var keyValue = params[i].split("=");
        if (keyValue[0] == "id") {
            return keyValue[1];
        }
    }

    return null;
}

function processDeleteRequest(deleteRequest) {
    if(deleteRequest.readyState == 4 && deleteRequest.status ==200) {
        if(deleteRequest.responseText == "Not found") {
        } else {
            location.reload();
        }
    }
}

function startup() {
    document.getElementById("removeString").style.display = "none";
}