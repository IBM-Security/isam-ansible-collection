window.addEventListener("load", startup);

var static_path = "/sps/mmfa/user/mgmt/html/mmfa/usc/static";
//
// Change the clientId to a value that matches the OAuth client ID
// to be used for MMFA.
//
var clientId = "AuthenticatorClient";

var scim_authenticator_schema = "urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Authenticator";
var scim_transaction_schema = "urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Transaction";
var scim_u2f_token_schema = "urn:ietf:params:scim:schemas:extension:isam:1.0:U2F";

var authenticators = null;
var authMethods = null;
var u2fTokens = [];
var registerTokens = [];
var transactions = null;
var transactionsPending = null;
var attributes = null;
var attributesPending = null;
var popup_global = false;
var color_fail = "#dc0000";
var color_pending = "#fd8c00";
var color_success = "#00ac46";
var transaction_device_name = null;
var transactions_data = [];
var attributes_data = [];
var retry = false;
var ws;
var socket_interval = null;
var registerRequest = null;

function getJunctionName() {
	var jct = window.getCookie("IV_JCT");
	if (jct != null && jct != "") {
		return jct;
	} else {
    return "@JUNCTION@";
	}
}
function populateStrings() {
	$('title')[0].textContent = i18nMsg.manageDevices;
	$('.ibmsy-h2#demo-name-header')[0].textContent = i18nMsg.manageDevices;
	$('.ibmsy-logged')[0].textContent = i18nMsg.logout;
	$('.ibmsy-self-care-section*[data-name="section-welcome-authenticators"] .ibmsy-h3.ibmsy-u2f-main-header')[0].textContent = i18nMsg.twoStepVerificationSettings;
	$('.ibmsy-self-care-section*[data-name="section-welcome-authenticators"] .ibmsy-h1.ibmsy-u2f-main-header')[0].textContent = i18nMsg.myDevicesAndSettings;
	$('.ibmsy-self-care-section*[data-name="section-welcome-authenticators"] .ibmsy-sc-header .imbsy-add-device')[0].textContent = i18nMsg.addNewDevice;
	$('*[data-name="section-welcome-authenticators"] .security_token_title')[0].textContent = i18nMsg.securityTokens;
	$('*[data-name="section-welcome"] .ibmsy-h1#learn-more-title')[0].textContent = i18nMsg.whatIsTwoStep;
	$('*[data-name="section-welcome"] .ibmsy-h2')[0].textContent = i18nMsg.whyYouNeedThis;
	$('*[data-name="section-welcome"] .ibmsy-h2')[1].textContent = i18nMsg.howItWorks;
	$('*[data-name="section-welcome"] .ibmsy-unordered-list')[0].children[0].textContent = i18nMsg.reason1;
	$('*[data-name="section-welcome"] .ibmsy-unordered-list')[0].children[1].textContent = i18nMsg.reason2;
	$('*[data-name="section-welcome"] .ibmsy-unordered-list')[0].children[2].textContent = i18nMsg.reason3;
	$('*[data-name="section-welcome"] .ibmsy-ordered-list')[0].children[0].textContent = i18nMsg.how1;
	$('*[data-name="section-welcome"] .ibmsy-ordered-list')[0].children[1].textContent = i18nMsg.how2;
	$('*[data-name="section-welcome"] .ibmsy-layout-large-left .ibmsy-h3')[0].innerHTML = i18nMsg.welcome;
	$('*[data-name="section-welcome"] .ibmsy-layout-large-left .ibmsy-h1')[0].textContent = i18nMsg.strengthenYourAccount;
	$('*[data-name="section-welcome"] .ibmsy-layout-large-left .type-body-m')[0].textContent = i18nMsg.accountDesc1;
	$('*[data-name="section-welcome"] .ibmsy-layout-large-left .type-body-m')[1].innerHTML = i18nMsg.accountDesc2;
	$('*[data-name="section-welcome"] .ibmsy-layout-large-left .type-body-m')[2].textContent = i18nMsg.u2fDesc;
	$('*[data-name="section-welcome"] .ibmsy-layout-large-left .ibmsy-button-primary.ibmsy-nav-sectionlink*[data-target="section-download"]')[0].textContent = i18nMsg.getStartedMobile;
	$('*[data-name="section-welcome"] .ibmsy-layout-large-left .ibmsy-button-primary.ibmsy-nav-sectionlink*[data-target="section-u2f-name"]')[0].textContent = i18nMsg.getStartedToken;
	$('*[data-name="section-welcome"] .ibmsy-learn-more-link')[0].textContent = i18nMsg.learnMore;
	$('*[data-name="section-download"] .ibmsy-layout-left .ibmsy-h1')[0].textContent = i18nMsg.downloadApp;
	$('*[data-name="section-download"] .ibmsy-layout-left .ibmsy-ordered-list')[0].children[0].innerHTML = i18nMsg.launchAppStore;
	$('*[data-name="section-download"] .ibmsy-layout-left .ibmsy-ordered-list')[0].children[1].textContent = i18nMsg.searchForVerify;
	$('*[data-name="section-download"] .ibmsy-layout-left .ibmsy-ordered-list')[0].children[2].textContent = i18nMsg.install;
	$('*[data-name="section-download"] .ibmsy-layout-left .ibmsy-button-primary.ibmsy-nav-sectionlink*[data-target="section-connectaccount"]')[0].textContent = i18nMsg.nextStepConnectAccount;
	$('*[data-name="section-download"] .ibmsy-layout-right .download-app')[0].alt = i18nMsg.downloadApp;
	$('*[data-name="section-connectaccount"] .ibmsy-layout-left .ibmsy-h1')[0].textContent = i18nMsg.connectYourAccount;
	$('*[data-name="section-connectaccount"] .ibmsy-layout-left .type-body-m')[0].textContent = i18nMsg.connectYourAccountDesc;
	$('*[data-name="section-connectaccount"] .ibmsy-layout-left .ibmsy-ordered-list.qr-code')[0].children[0].textContent = i18nMsg.launchIBMVerify;
	$('*[data-name="section-connectaccount"] .ibmsy-layout-left .ibmsy-ordered-list.qr-code')[0].children[1].textContent = i18nMsg.tapConnectAccount;
	$('*[data-name="section-connectaccount"] .ibmsy-layout-left .ibmsy-ordered-list.qr-code')[0].children[2].textContent = i18nMsg.scanQRCode;
	$('*[data-name="section-connectaccount"] .ibmsy-qr-code .scan')[0].textContent = i18nMsg.scanMe;
	$('*[data-name="section-connectaccount"] .ibmsy-qr-code .sm')[0].textContent = i18nMsg.qrCodeDesc;
	$('*[data-name="section-u2f-name"] .ibmsy-h1')[0].textContent = i18nMsg.fidoU2FRego;
	$('*[data-name="section-u2f-name"] .search-input#token_name')[0].value = i18nMsg.tokenName;
	$('*[data-name="section-u2f-name"] .search-input#token_name')[0].placeholder = i18nMsg.tokenName;
	$('*[data-name="section-u2f-name"] .ibmsy-button-primary.ibmsy-nav-sectionlink*[data-target="section-u2f"]')[0].textContent = i18nMsg.nextStepConnectToken;
	$('*[data-name="section-u2f"] .ibmsy-h1')[0].textContent = i18nMsg.fidoU2FRego;
	$('*[data-name="section-complete-modal"] .ibmsy-h3')[0].innerHTML = i18nMsg.congrats;
	$('*[data-name="section-complete-modal"] .ibmsy-h1')[0].textContent = i18nMsg.deviceConnected;
	$('*[data-name="section-complete-modal"] .type-body-m')[0].textContent = i18nMsg.nextSignIn;
	$('*[data-name="section-complete-modal"] .ibmsy-button-primary.ibmsy-finish-enrollment')[0].textContent = i18nMsg.finish;
	$('*[data-name="section-complete-modal"] .ibmsy-welcome-illustrations img')[0].alt = i18nMsg.ibmVerify;
	$('*[data-name="section-complete"] .ibmsy-h3')[0].innerHTML = i18nMsg.congrats;
	$('*[data-name="section-complete"] .ibmsy-h1')[0].textContent = i18nMsg.deviceConnected;
	$('*[data-name="section-complete"] .type-body-m')[0].textContent = i18nMsg.completeOnMobile;
	$('*[data-name="section-complete"] .type-body-m')[1].innerHTML = i18nMsg.yourAccountIsSecure;
	$('*[data-name="section-complete"] .ibmsy-button-primary#close-enrollment')[0].textContent = i18nMsg.finish;
	$('*[data-name="section-complete"] .ibmsy-welcome-illustrations img')[0].alt = i18nMsg.ibmVerify;

}

function ISAM_SCIM_INFO(mode, waitFunction, completeFunction, finalFunction) {
	//If user parameter is supplied, do it in the context of that user - otherwise for all users.
	//Different modes allowed:
	//- all
	//- transactions
	//- authenticators
	//- transactions+authenticators
	//- users
	var scim_base = "/scim/Me";
	var scim_query = null;
	switch (mode) {
		case "all":
			scim_query = "";
			break;
		case "allTransactions":
			scim_query = "?attributes=" + scim_transaction_schema + ":transactionsResolved," + scim_transaction_schema + ":attributesResolved," + scim_transaction_schema + ":transactionsPending," + scim_transaction_schema + ":attributesPending";
			break;
		case "resolvedTransactions":
			scim_query = "?attributes=" + scim_transaction_schema + ":transactionsResolved," + scim_transaction_schema + ":attributesResolved";
			break;
		case "pendingTransactions":
			scim_query = "?attributes=" + scim_transaction_schema + ":transactionsPending," + scim_transaction_schema + ":attributesPending";
			break;
		case "transactions":
			scim_query = "?attributes=" + scim_transaction_schema + ":transactionsPending," + scim_transaction_schema + ":transactionsResolved";
			break;
		case "authenticators":
			scim_query = "?attributes=" + scim_authenticator_schema + ":authenticators," + scim_authenticator_schema + ":fingerprintMethods," + scim_authenticator_schema + ":userPresenceMethods";
			break;
		case "authenticators+tokens":
			scim_query = "?attributes=" + scim_authenticator_schema + ":authenticators," + scim_authenticator_schema + ":fingerprintMethods," + scim_authenticator_schema + ":userPresenceMethods," + scim_u2f_token_schema + ":tokens";
			break;
		case "authenticators+transactions":
			scim_query = "?attributes=" + scim_transaction_schema + ":transactionsPending," + scim_transaction_schema + ":transactionsResolved," + scim_authenticator_schema + ":authenticators," + scim_authenticator_schema + ":fingerprintMethods," + scim_authenticator_schema + ":userPresenceMethods";
			break;
		case "users":
			scim_query = "?attributes=userName,phoneNumbers,name";
			break;
	}

	getRequest = makeAjaxRequestJSON("GET", scim_base + scim_query, function(scimRequest) {
		if (scimRequest.readyState == 4) {
			if (scimRequest.status == 200) {
				if (scimRequest.responseText == "Not found") {} else {
					if(IsJsonString(scimRequest.responseText)){
						var response = JSON.parse(scimRequest.responseText);
						if (response != null) {
							//Response looks ~okay~, call the completeFunction
							completeFunction(scimRequest,finalFunction);
						}
					}else{
						return false;
					}
				}
			
			} else {
				//Still waiting on response, call the waitFunction
				if (typeof waitFunction != "undefined" && typeof waitFunction === "function") {
					waitFunction(scimRequest);
				}
			}
		} else {
			//Still waiting on response, call the waitFunction
			if (typeof waitFunction != "undefined" && typeof waitFunction === "function") {
				waitFunction(scimRequest);
			}
			if (scimRequest.readyState == 3) {
				if (scimRequest.responseURL.includes("TAM_OP") && scimRequest.responseText.includes("!DOCTYPE html") && mode != "pendingTransactions") {
					window.location = 'https://' + window.location.hostname + window.location.pathname;
				}else if(scimRequest.status == 404){
					if (finalFunction != "undefined" && typeof finalFunction == "function"){
						finalFunction(null);
					}
				}
			}
		}
	}, null);
	return getRequest;
}


function ISAM_BROWSER_INFO(waitFunction, completeFunction, finalFunction) {

	var device_base = getJunctionName() + "/sps/mga/user/mgmt/device";

	getRequest = makeAjaxRequestJSON("GET", device_base, function(deviceRequest) {
		if (deviceRequest.readyState == 4) {
			if (deviceRequest.status == 200) {
				if (deviceRequest.responseText == "Not found") {} else {
					if(IsJsonString(deviceRequest.responseText)){
						var response = JSON.parse(deviceRequest.responseText);
						if (response != null) {
							//Response looks ~okay~, call the completeFunction
							completeFunction(deviceRequest,finalFunction);
						}
					}else{
						return false;
					}
				}
			
			} else {
				//Still waiting on response, call the waitFunction
				if (typeof waitFunction != "undefined" && typeof waitFunction === "function") {
					waitFunction(deviceRequest);
				}
			}
		} else {
			//Still waiting on response, call the waitFunction
			if (typeof waitFunction != "undefined" && typeof waitFunction === "function") {
				waitFunction(deviceRequest);
			}
			if (deviceRequest.readyState == 3) {
				if (deviceRequest.responseURL.includes("TAM_OP") && deviceRequest.responseText.includes("!DOCTYPE html")) {
					window.location = 'https://' + window.location.hostname + window.location.pathname;
				}else if(deviceRequest.status == 404){
					if (finalFunction != "undefined" && typeof finalFunction == "function"){
						finalFunction(null);
					}
				}
			}
		}
	}, null);
	return getRequest;
}



function waitFunctionSCIM(scimRequest) {
	//SCIM Background Poll Wait Function
	trace("Background poll - waiting for SCIM response", "fine");
}

function completeFunctionSCIM(scimRequest, finalFunction) {
	if (scimRequest != null){
		var scimRequest = JSON.parse(scimRequest.responseText);
		//SCIM Background Poll On Complete
		trace("Background poll - completing SCIM actions", "fine");
		//Fill out global JavaScript objects		
		//- No. of Authenticators	
		//- No. of Authentication Methods	
		//- Authentication Method types registered		
		//- No. Transactions Total	
		//- No. Pending transactions
		if (scimRequest[scim_authenticator_schema] != null) {
			authenticators = scimRequest[scim_authenticator_schema].authenticators;
			var fingerprintMethods = scimRequest[scim_authenticator_schema].fingerprintMethods;
			var userPresenceMethods = scimRequest[scim_authenticator_schema].userPresenceMethods;
			authMethods = fingerprintMethods.concat(userPresenceMethods);
			authMethods.fingerprint = fingerprintMethods;
			authMethods.userpresence = userPresenceMethods;
		} else {
			trace("No Authenticators Found", "fine");
			authenticators = null;
			authMethods = null;
		}

		if (scimRequest[scim_u2f_token_schema] != null) {
			u2fTokens = scimRequest[scim_u2f_token_schema].tokens;
		} else {
			trace("No U2f Tokens Found", "fine");
				$(".security_token_title").addClass("hidden");
		}

		if (scimRequest[scim_transaction_schema] != null) {
			transactionsPending = scimRequest[scim_transaction_schema].transactionsPending;
			var transactionsResolved = scimRequest[scim_transaction_schema].transactionsResolved;
			attributesPending = scimRequest[scim_transaction_schema].attributesPending;
			var attributesResolved = scimRequest[scim_transaction_schema].attributesResolved;
			transactions = transactionsPending.concat(transactionsResolved);
			attributes = attributesPending.concat(attributesResolved);
		} else {
			trace("No Transactions Found", "fine");
			transactions = null;
			attributes = null;
			transactionsPending = null;
			attributesPending = null;
		}
	}else {
		trace("SCIM Request is blank - Local server?", "warning");
	}
	if (finalFunction != null && finalFunction != "undefined") {
		trace("Background poll - heading into finalFunction", "fine");
		finalFunction(scimRequest);
	}
}

function updateHTML(scimRequest) {
	trace("Updating Selfcare HTML");
	if (scimRequest != null && scimRequest != "undefined"){
		// Response looks ~okay~	
		displayAuthenticators(authenticators, authMethods, u2fTokens, [loading_elements_manage, null_elements_manage, content_elements_manage]);
		if(authenticators != null) {
			$("#authenticators-total").text(authenticators.length);
		} else {
			$("#authenticators-total").text(0);
		}
		if(authMethods != null) {
			$("#authenticators-methods").text(authMethods.length);
		} else {
			$("#authenticators-methods").text(0);
		}
	}else{
		displayElements("empty", loading_elements_manage, null_elements_manage, content_elements_manage);
	}

}


function displayAuthenticators(authenticators, authMethods, u2fTokens, elements) {
	var number_disabled = 0;
	
	if ((authenticators != null && authenticators.length > 0) || (u2fTokens != null && u2fTokens.length > 0)) {
		//Remove all the authenticators from the contains, and if it exists - the container
		$(".mobile-device-container").children().remove();
		$(".token-device-container").children().remove();


		if (authenticators != null && authenticators.length > 0){
				$.each(authenticators, function(i, authenticator) {
					
					//Check for enabled
					var enabled_text = i18nMsg.enabled;
					var toggle_text = i18nMsg.disableDevice;
					var class_text = "device-activated";
					if (authenticator.enabled == false) {
						enabled_text = i18nMsg.disabled;
						toggle_text = i18nMsg.enableDevice;
						number_disabled += 1;
						class_text = "device-deactivated"
					}
				
					var imgsrc = "/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/Phone-1_Illustraion.svg";
					if(authenticator.deviceType == "iPad"){
						imgsrc = "/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/tablet.svg"
					}else{
						imgsrc = "/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/Phone-1_Illustraion.svg";
					}
					
					//Add the device
					var authenticator_device = '\
					<div class="ibmsy-sc-device '+class_text+'" id = "' + authenticator.id + '"> \
						<div class="ibmsy-sc-more-dropdown"> \
							<button class="ibmsy-more-menu" id = "' + authenticator.id + '"> \
							</button> \
							<ul class="ibmsy-dropdown-list"> \
								<li class="hidden" data-function="changeDeviceName">' + i18nMsg.editDeviceName + '</li>\
								<li id = "' + authenticator.oauthGrant + '" data-function="toggleDeviceActive">' + toggle_text + '</li>\
								<li id = "' + authenticator.id + '" data-function="deleteDevice">' + i18nMsg.deleteDevice + '</li>\
							</ul> \
						</div> \
						<div class="ibmsy-sc-device-illustration"> \
							<img src="'+imgsrc+'" alt="illustration" /> \
						</div> \
						<div class="ibmsy-sc-device-info"> \
							<div class="ibmsy-device-title">' + decode_utf8(authenticator.deviceName) + '</div> \
							<input type="text" class="ibmsy-device-title hidden" placeholder="' + decode_utf8(authenticator.deviceName) + '">\
							<div class="ibmsy-device-type">' + authenticator.deviceType + ' (' + authenticator.osVersion + ')</div> \
							<div class="ibmsy-device-lastUsed">' + enabled_text + '</div> \
						</div>\
						\
						<div class="ibmsy-sc-alert">\
							<div class="alert-title">\
								<h3 class="ibmsy-h3">' + i18nMsg.areYouSure + '</h3>\
							</div>\
							<p class="type-body-s">\
								' + i18nMsg.deleteDeviceWarnMg + '\
							</p>\
							<div class="alert-actions">\
								<button id = "' + authenticator.id + '" class="ibmsy-device-secondary cancel" alt="' + i18nMsg.cancel + '">' + i18nMsg.cancel + '</button>\
								<button id = "' + authenticator.id + '" class="ibmsy-device-primary delete" alt="' + i18nMsg.deleteConfrmation + '">' + i18nMsg.deleteConfrmation + '</button>\
							</div>\
						</div>\
					</div>';
					
					$(".mobile-device-container").append(authenticator_device);
					
				}); 
					
				
		
		}

		$(".security_token_title").removeClass("hidden");

		if (u2fTokens != null && u2fTokens.length > 0){
			
			$.each(u2fTokens, function(i, token) {

				//Check for enabled
				var enabled_text = i18nMsg.enabled;
				var toggle_text = i18nMsg.disableDevice;
				var class_text = "device-activated";
				if (token.enabled == false) {
					enabled_text = i18nMsg.disabled;
					toggle_text = i18nMsg.enableDevice;
					number_disabled += 1;
					class_text = "device-deactivated"
				}
			
				var imgsrc = "/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/U2F-Device-Listing-Illustration.svg";
				
				//Add the device
				var u2f_token = '\
				<div class="ibmsy-sc-device '+class_text+' token-device" id = "' + token.id + '"> \
					<div class="ibmsy-sc-more-dropdown"> \
						<button class="ibmsy-more-menu"> \
						</button> \
						<ul class="ibmsy-dropdown-list"> \
							<li class="editDeviceName" data-function="changeDeviceName">' + i18nMsg.editDeviceName + '</li>\
							<li id = "' + token.id+ '" data-function="toggleDeviceActive">' + toggle_text + '</li>\
							<li data-function="deleteDevice">' + i18nMsg.deleteDevice + '</li>\
						</ul> \
					</div> \
					<div align="center" class="ibmsy-sc-device-illustration"> \
						<img src="'+imgsrc+'" alt="illustration" /> \
					</div> \
					<div class="ibmsy-sc-device-info"> \
						<div class="ibmsy-device-title"></div> \
						<input type="text" class="ibmsy-device-title hidden" placeholder="">\
						<div class="ibmsy-device-type">' + i18nMsg.securityToken + '</div> \
						<div class="ibmsy-device-lastUsed">' + enabled_text + '</div> \
					</div>\
					\
					<div class="ibmsy-sc-alert">\
						<div class="alert-title">\
							<h3 class="ibmsy-h3">' + i18nMsg.areYouSure + '</h3>\
						</div>\
						<p class="type-body-s">\
							' + i18nMsg.deleteDeviceWarnMg + '\
						</p>\
						<div class="alert-actions">\
							<button class="ibmsy-device-secondary cancel" alt="' + i18nMsg.cancel + '">' + i18nMsg.cancel + '</button>\
							<button operation="u2f" device_number="'+i+'" class="ibmsy-device-primary delete" alt="' + i18nMsg.deleteConfrmation + '">' + i18nMsg.deleteConfrmation + '</button>\
						</div>\
					</div>\
				</div>';
				
				$(".token-device-container").append(u2f_token);
				$(".ibmsy-sc-device#"+token.id+" .ibmsy-sc-device-info .ibmsy-device-title")[0].textContent = token.name;
				if(!token.enabled) {
					$(".ibmsy-sc-device#"+token.id+" .ibmsy-sc-more-dropdown .ibmsy-dropdown-list")[0].children[1].style.display = "none";
				}
			});
			
		} else{
			$(".security_token_title").addClass("hidden");
		}

		if (typeof checkDevicesEmpty != "undefined") {
			checkDevicesEmpty();
		}
		
		if (typeof addDevice != "undefined") {
			addDevice();
		}
		
		
		if (elements != null){
			setTimeout(function(){displayElements("full", elements[0], elements[1], elements[2]);},200);
		}
		
	} else {

		checkDevicesEmpty();
		if (elements != null){
			setTimeout(function(){
				//console.log("selfcare empty");
				displayElements("empty", elements[0], elements[1], elements[2]);},200);
		}
		
	}

}


function register() {
	if (u2f != null) {
		makeJsonAjaxRequest("GET", u2fPolicyUrl, function(getRequest) {

			if (getRequest.readyState == 4 && getRequest.status == 200) {
				if (getRequest.responseText == "Not found") {
				} else {
					processGetU2FTokensRequest(getRequest);

					$(".ibmsy-u2f-device-container").removeClass("u2f-response");
					$(".ibmsy-u2f-device-container").removeClass("u2f-success");
					$(".ibmsy-u2f-device-container").removeClass("u2f-error");
					$(".ibmsy-u2f-device-container").removeClass("u2f-waiting");
					$(".ibmsy-u2f-device-container").removeClass("u2f-unsupported");
					$(".ibmsy-u2f-device-container").removeClass("u2f-error-timeout");
					$(".ibmsy-u2f-device-container").removeClass("u2f-error-already-registered");
					u2f.register(
						registerRequest.appId,
						[{version: registerRequest.version,
						challenge: registerRequest.challenge}],
						registerTokens,
						function(data) {
							if(data.errorCode) {

								$(".ibmsy-u2f-device-container").css("background-image",'url("/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/U2F-Error.svg")');
								$(".ibmsy-u2f-device-container").removeClass("u2f-response");
								$(".ibmsy-u2f-device-container").removeClass("u2f-success");
								$(".ibmsy-u2f-device-container").removeClass("u2f-error");
								$(".ibmsy-u2f-device-container").removeClass("u2f-waiting");
								$(".ibmsy-u2f-device-container").removeClass("u2f-unsupported");
								$(".ibmsy-u2f-device-container").addClass("u2f-error");

								var errMsg = i18nMsg.errGeneric;
								if(data.errorCode == 2 | data.errorCode == 4) {

									$(".ibmsy-u2f-device-container").addClass("u2f-error-already-registered");
									errMsg = i18nMsg.errAlreadyRego;
								} else if(data.errorCode == 5) {

									$(".ibmsy-u2f-device-container").css("background-image",'url("/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/U2F-Failure.svg")');
									$(".ibmsy-u2f-device-container").addClass("u2f-error-timeout");
									errMsg = i18nMsg.errTimedOut;
								}
							}
							else {
								registerResponse = data;

								$(".ibmsy-u2f-device-container").removeClass("u2f-response");
								$(".ibmsy-u2f-device-container").removeClass("u2f-success");
								$(".ibmsy-u2f-device-container").removeClass("u2f-error");
								$(".ibmsy-u2f-device-container").removeClass("u2f-waiting");
								$(".ibmsy-u2f-device-container").removeClass("u2f-unsupported");
								$(".ibmsy-u2f-device-container").addClass("u2f-response");

								if (data["registrationData"] != null) {

									var token_name = $("#token_name").val();

									if (token_name == "" || token_name == null) {
										token_name = i18nMsg.tokenName;
									}

									registerResponse.name = token_name;
						
									$("#token_name").val(i18nMsg.tokenName);
						
									registerResponse.action = "register";

									var url = registerRequest.location;
									var method = "PUT";
									getRequest = makeAjaxRequestJSON(method, url, function(getRequest) {
										if (getRequest.readyState == 4) {
											if (getRequest.status == 204) {

												getU2FTokens(); 

												ISAM_SCIM_INFO("authenticators+tokens", waitFunctionSCIM, completeFunctionSCIM, updateHTML);
												$(".ibmsy-u2f-device-container").css("background-image",'url("/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/U2F-Success.svg")');
												$(".ibmsy-u2f-device-container").removeClass("u2f-response");
												$(".ibmsy-u2f-device-container").removeClass("u2f-success");
												$(".ibmsy-u2f-device-container").removeClass("u2f-error");
												$(".ibmsy-u2f-device-container").removeClass("u2f-waiting");
												$(".ibmsy-u2f-device-container").removeClass("u2f-unsupported");
												$(".ibmsy-u2f-device-container").addClass("u2f-success");

												setTimeout(function(){closeAndCleanup()},1000);

											} else {
												if (getRequest.responseText == "Not found") {
												} else {
													$(".ibmsy-u2f-device-container").css("background-image",'url("/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/U2F-Error.svg")');
													$(".ibmsy-u2f-device-container").removeClass("u2f-response");
													$(".ibmsy-u2f-device-container").removeClass("u2f-success");
													$(".ibmsy-u2f-device-container").removeClass("u2f-error");
													$(".ibmsy-u2f-device-container").removeClass("u2f-waiting");
													$(".ibmsy-u2f-device-container").removeClass("u2f-unsupported");
													$(".ibmsy-u2f-device-container").addClass("u2f-error");
												}
											}
										}	
									}, JSON.stringify(registerResponse));
					
					
								} else {
									$(".ibmsy-u2f-device-container").css("background-image",'url("/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/U2F-Error.svg")');
									$(".ibmsy-u2f-device-container").removeClass("u2f-response");
									$(".ibmsy-u2f-device-container").removeClass("u2f-success");
									$(".ibmsy-u2f-device-container").removeClass("u2f-error");
									$(".ibmsy-u2f-device-container").removeClass("u2f-waiting");
									$(".ibmsy-u2f-device-container").removeClass("u2f-unsupported");
									$(".ibmsy-u2f-device-container").addClass("u2f-error");
								}
							}
						},
						300);
					$(".ibmsy-u2f-device-container").css("background-image",'url("/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/U2F-Instructions-Illustration.svg")');
					$(".ibmsy-u2f-device-container").removeClass("u2f-response");
					$(".ibmsy-u2f-device-container").removeClass("u2f-success");
					$(".ibmsy-u2f-device-container").removeClass("u2f-error");
					$(".ibmsy-u2f-device-container").removeClass("u2f-waiting");
					$(".ibmsy-u2f-device-container").removeClass("u2f-unsupported");
					$(".ibmsy-u2f-device-container").addClass("u2f-waiting");
				}
			}
		}, null);
	} else {
		$(".ibmsy-u2f-device-container").css("background-image",'url("/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/U2F-Device-Listing-Illustration.svg")');
		$(".ibmsy-u2f-device-container").removeClass("u2f-response");
		$(".ibmsy-u2f-device-container").removeClass("u2f-success");
		$(".ibmsy-u2f-device-container").removeClass("u2f-error");
		$(".ibmsy-u2f-device-container").removeClass("u2f-waiting");
		$(".ibmsy-u2f-device-container").removeClass("u2f-unsupported");
		$(".ibmsy-u2f-device-container").addClass("u2f-unsupported");
	}
}

function getU2FTokens() {
	var request;
	makeJsonAjaxRequest("GET", u2fPolicyUrl, processGetU2FTokensRequest, null);
}

function processGetU2FTokensRequest(getU2FRequest) {
	if (getU2FRequest.readyState == 4 && getU2FRequest.status == 200) {
		if (getU2FRequest.responseText == "Not found") {
		} else {
			parseGetU2FTokensRequest(getU2FRequest);
		}
	}
}

function parseGetU2FTokensRequest(getTokensRequest) {
	registerRequest = JSON.parse(getTokensRequest.responseText);
	u2fTokens = registerRequest.tokens;
	
	registerTokens = [];

	if (u2fTokens != null && u2fTokens.length > 0){
		$.each(u2fTokens, function(i, token) {
			var tokenObj = {
				keyHandle: token.key_handle,
				version:   registerRequest.version,
				appId:	   token.app_id
			};
			registerTokens.push(tokenObj);
		});
	}
}

function startup() {
	populateStrings();
	document.getElementById("logoutLink").addEventListener("click", function(){window.location.href = '/pkmslogout'});
	document.getElementById("registerAuthenticatorButton").addEventListener("click", function(){registerAuthenticator('normal')});
	document.getElementById("addDevice").addEventListener("click", function(){register_device('add', false, true)});
	document.getElementById("normalDevice").addEventListener("click", function(){register_device('normal', true, false)});
	document.getElementById("register").addEventListener("click", register);

	document.styleSheets[0].insertRule('.ibmsy-devices h3:only-child:after {content: "' + i18nMsg.noDevices + '";}', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule(".ibmsy-all-device-containers-empty:after {content: '" + i18nMsg.noDevices + " \\A " + i18nMsg.addADevice + "';}", document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.ibmsy-support-tables #transaction-history-table.transaction-pending-table--empty:after, .ibmsy-support-tables #transaction-pending-table.transaction-pending-table--empty:after { content: "'+i18nMsg.noPendingTransactions+'"; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.ibmsy-u2f-device-container:after { content: "'+i18nMsg.findTokenData+'" !important; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.dg-gallery__count--current:after { content: "'+i18nMsg.counter+'"; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.ibmsy-u2f-name-container:after { content: "'+i18nMsg.provideName+'" !important; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.u2f-waiting:after { content: "'+i18nMsg.insertToken+'" !important; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.u2f-error:after { content: "'+i18nMsg.tokenError+'" !important; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.u2f-error-timeout:after { content: "'+i18nMsg.tokenTimeout+'" !important; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.u2f-error-already-registered:after { content: "'+i18nMsg.tokenAlreadyRegistered+'" !important; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.u2f-success:after { content: "'+i18nMsg.tokenSuccess+'" !important; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.u2f-unsupported:after { content: "'+i18nMsg.u2fUnsupported+'" !important; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('.u2f-response:after { content: "'+i18nMsg.tokenResponse+'" !important; }', document.styleSheets[0].cssRules.length);
	document.styleSheets[0].insertRule('#ibmsy-modal .ibmsy-modal-window .ibmsy-modal-content .ibmsy-all-device-containers-empty:after { content: "'+i18nMsg.noDevicesLong+'" !important; }', document.styleSheets[0].cssRules.length);

	displayElements("loading", loading_elements_manage, null_elements_manage, content_elements_manage);

	getU2FTokens(); 

	ISAM_SCIM_INFO("authenticators+tokens", waitFunctionSCIM, completeFunctionSCIM, updateHTML);


}

