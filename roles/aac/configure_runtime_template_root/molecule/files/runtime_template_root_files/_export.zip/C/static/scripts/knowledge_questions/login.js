window.addEventListener("load", startup);

var ukql_errorMessage = document.currentScript.dataset.errorMessage;

var ukql_questionDisplayText = "No question text found";
var ukql_questionsArray = ["Mother's maiden name.",
    "Name of town where you were born.",
    "Name of first pet."
];

function displayError() {
    if (ukql_errorMessage != "") {
        var errorMsg = document.getElementById("errorMessage");
        errorMsg.textContent = errorMsg.textContent + ukql_errorMessage;

        var errorDiv = document.getElementById("errorDiv");
        errorDiv.className = "errorMessage visible";
    }
}

function startup() {
    displayError();

    var ukqArray = document.getElementsByClassName("knowledgequestion");
    var ukqsize = 0;
    if(ukqArray) {
        ukqsize = ukqArray.length;
    }
    // Need to loop through and populate the list of questions
    for(var index = 0; index < ukqsize; index++) {
        var currentLabelData = document.getElementById("knowledge.question.label." + index);

        if(currentLabelData != null && currentLabelData != undefined) {
            let questionText = currentLabelData.dataset.questionText;
            let questionUniqueId = currentLabelData.dataset.questionUniqueId;

            if (questionText == null || questionText == "") {
                //Try to get the default text from the array.
                if (questionUniqueId == 1 || questionUniqueId == 2 || questionUniqueId == 3) {
                    questionText = ukql_questionsArray[questionUniqueId - 1];
                }

            } else {
                ukql_questionDisplayText = questionText;
            }
            document.getElementById('knowledge.question.label.' + index).textContent = ukql_questionDisplayText;
        } else {
            break;
        }
    }
}
