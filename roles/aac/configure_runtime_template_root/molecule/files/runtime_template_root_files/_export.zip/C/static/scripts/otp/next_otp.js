window.addEventListener('load', startup);

var otpn_errorMsg = document.currentScript.dataset.errorTag;
var otpn_mapRuleData = document.currentScript.dataset.mappingRuleData;
var otpn_dispReselButton = document.currentScript.dataset.displayReselectButton

function displayError() {
    if (otpn_errorMsg != "") {
        var errorMsg = document.getElementById("errorMessage");
        errorMsg.textContent = errorMsg.textContent + otpn_errorMsg;

        var errorDiv = document.getElementById("errorDiv");
        errorDiv.className = "errorMessage visible";
    }
}

function displayMappingRuleData() {
    if (otpn_mapRuleData != "") {
        var mrdText = document.getElementById("mappingRuleDataText");
        mrdText.textContent = mrdText.textContent + otpn_mapRuleData;

        var mappingRuleDataDiv = document.getElementById('mappingRuleDataDiv');
        mappingRuleDataDiv.className = "visible";
    }
}

function displaySelectButton() {
    var reselectButtonDiv = document.getElementById('reselectButtonDiv');

    if (otpn_dispReselButton != "") {
        reselectButtonDiv.className = "";
    }
}

function startup() {
    displayError();
    displayMappingRuleData();
    displaySelectButton();
}
