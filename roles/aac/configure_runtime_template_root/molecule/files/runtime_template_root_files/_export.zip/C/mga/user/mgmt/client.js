window.addEventListener("load", startup);

var client_uri = null;
var client_data = null;

function back() {
  window.location.href = baseUrl + "/html/device/device_selection.html";
}

function showSecret() {
  var hidden = document.getElementById("secretdiv");
  var tr = document.getElementById("secrettr");
  if (tr != null) {
    tr.textContent = hidden.textContent;
  }

}

function populateClientUpdate(request) {
  return populateClient(request, false);
}

function populateClientInit(request) {
  return populateClient(request, true);
}

function populateClient(request, create) {
  if (request.readyState == 4 && request.status == 200) {
    if (request.responseText == "Not found") {} else {
      var json = JSON.parse(request.responseText);
      var field = document.getElementById("clientIdField");
      var table = document.getElementById("clientTable");

      client_data = json;

      if (create) {
        var tr = table.insertRow(-1);
        var nameTr = tr.insertCell(-1);
        var valueTr = tr.insertCell(-1);
        nameTr.textContent = mgmtMsg.definition;
        valueTr.textContent = json.registration_client_uri.match(/register\/([^]*)(?=\?)/)[1];

        tr = table.insertRow(-1);
        nameTr = tr.insertCell(-1);
        valueTr = tr.insertCell(-1);
        nameTr.textContent = mgmtMsg.clientId;
        valueTr.textContent = json['client_id'];
        field.textContent = json['client_id'];

        tr = table.insertRow(-1);
        nameTr = tr.insertCell(-1);
        valueTr = tr.insertCell(-1);
        nameTr.textContent = mgmtMsg.owner;
        valueTr.textContent = json['owner_username'];
      }


      table = document.getElementById("attributesTable");
      if (!create) {
        for (var i = table.rows.length - 1; i > 0; i = table.rows.length - 1) {
          table.deleteRow(i);
        }
      }
      for (var v in json) {
        tr = table.insertRow(-1);
        nameTr = tr.insertCell(-1);
        valueTr = tr.insertCell(-1);
        nameTr.textContent = v
        valueTr.textContent = v == "client_secret" ? "******" : json[v];
        if (v == "client_secret") {
          valueTr.id = "secrettr";
          var hidden = document.getElementById("secretdiv");
          hidden.textContent = json[v];
        }
      }
    }
  }
}

function onLoad() {

  var loc = window.location.href;
  var params = {};
  if (loc.split("?").length > 1) {
    var qs = loc.split("?")[1];
    for (var param of qs.split("&")) {
      var parts = param.split('=');
      if (parts.length > 1) {
        params[decodeURIComponent(parts[0])] = decodeURIComponent(parts[1]);
      }
    }
  }

  client_uri = loc.match(/https:\/\/.*?(?=\/)/) + params.uri;
  if (client_uri != null) {
    makeJsonAjaxRequest("GET", client_uri, populateClientInit, null);
  }
}

function processDeleteRequest(req) {
  if (req.readyState == 4 && (req.status == 200 || req.status == 204)) {
    if (req.responseText == "Not found") {} else {
      window.location.href = junction + "/sps/mga/user/mgmt/html/device/device_selection.html";
    }
  }
}

function resetSecret() {
  makeJsonAjaxRequest("PUT", client_uri, populateClientUpdate, JSON.stringify(client_data));
}

function deleteClient() {
  makeJsonAjaxRequest("DELETE", client_uri, processDeleteRequest, null);
}

function startup() {
  onLoad();
  document.getElementById("showSecret").addEventListener("click", showSecret);
  document.getElementById("resetSecret").addEventListener("click", resetSecret);
  document.getElementById("deleteClient").addEventListener("click", deleteClient);
  document.getElementById("back").addEventListener("click", back);
}