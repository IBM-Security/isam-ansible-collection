function base64URLEncodeJSON(json) {
    var str = JSON.stringify(json);
    var result = utf8tob64u(str);
    return result;
}

function base64URLEncode(bytes, encoding = 'utf-8') {
    if(bytes == null || bytes.length == 0) {
        return null;
    }
    var str = base64js.fromByteArray(new Uint8Array(bytes));
    str = str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    return str;
}

function base64URLDecode(str, encoding = 'utf-8') {
    if(str == null || str == "") {
        return null;
    }

    var str = str.replace(/-/g, '+').replace(/_/g, '\/');

    var pad = str.length % 4;
    if(pad) {
      str += new Array(5-pad).join('=');
    }

    var bytes = base64js.toByteArray(str);
    return bytes.buffer;
}

function optionsGet() {
    document.getElementById("errormsg").style.display = "none";

    let selected = document.querySelector(".bx--line-method.selected");
    let selectedUsername = selected != null ? selected.username : "";

    var url = f2p_ad_optionsGetUrl;
    if(!url.includes("apiauthsvc")) {
        url = url.replace("authsvc", "apiauthsvc");
    }

    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {

        if (request.readyState == 4) {
            if (request.responseText) {

                var json = null;
                try {
                    json = JSON.parse(request.responseText);
                } catch (e) {
                    // we got a 200, but not valid JSON - that's an error
                    showError(authsvcMsg.badOptionsRequest);
                }

                if(json != null) {

                    if(json.stateId != null) {
                        stateId = json.stateId;
                        if (f2p_ad_optionsGetUrl.indexOf('?StateId=') > 0) {
                            f2p_ad_optionsGetUrl= f2p_ad_optionsGetUrl.substring(0, f2p_ad_optionsGetUrl.indexOf('=') + 1);
                            f2p_ad_optionsGetUrl = f2p_ad_optionsGetUrl + stateId;
                        }
                    }

                    if(json.location != null) {
                        document.getElementById("username_password_form").action = json.location.replace("apiauthsvc","authsvc");
                        document.getElementById("fido2_form").action = json.location.replace("apiauthsvc","authsvc");
                        document.getElementById("ping-pong-form").action = json.location.replace("apiauthsvc","authsvc");
                    }

                    if(request.status == 200) {
                        f2p_ad_inFIDOBranch = true;

                        let publicKey = JSON.parse(JSON.stringify(json), (key, value) => {
                            if (value == null || value == '' || value == [] || value == {}) {
                                return undefined;
                            }
                            return value;
                        });

                        if(("status" in publicKey) == true) {
                        delete publicKey['status'];
                        }
                        if(("errorMessage" in publicKey) == true) {
                            delete publicKey['errorMessage'];
                        }
                        if(("mechanism" in publicKey) == true) {
                            delete publicKey['mechanism'];
                        }
                        credentialsGet(publicKey);

                    } else {
                        // Response wasn't a 200. Show error.
                        var errorMsg = authsvcMsg.badOptionsRequest;
                        if(json.error != null) {
                            errorMsg = json.error;
                        } else if(json.errorMessage != null) {
                            errorMsg = json.errorMessage;
                        } else if(json.exceptionMsg != null) {
                            errorMsg = json.exceptionMsg;
                        }
                        showError(errorMsg);
                    }

                } else {
                    // Response isn't json. Very weird. Show error.
                    showError(authsvcMsg.badOptionsRequest);
                }
            } else {
                // No response text. Very weird. Show error.
                showError(authsvcMsg.badOptionsRequest);
            }
        } else {
            // readyState is not 4, that's ok, just continue.
        }
    };

    var payload = {"type": "fido2", "existingRego": "true"};
    var method = "PUT";
    if(f2p_ad_inFIDOBranch) {
        payload = {};
        method = "POST";
    }

    request.open(method, url);

    // If not in a branch, this is the initial decision POST, so add some extra info to
    // the request.
    let persistentToken = getPersistentToken(selectedUsername);

    if(!f2p_ad_inFIDOBranch && persistentToken != null) {
        request.setRequestHeader("fido2pair-persistent", persistentToken);
    }

    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");
    request.send(JSON.stringify(payload));

}

function credentialsGet(param) {

    let selected = document.querySelector(".bx--line-method.selected");
    let selectedUsername = selected != null ? selected.username : "";

    let otherUsers = document.querySelectorAll(".bx--line-method:not(.selected)")
    if(otherUsers.length > 0) {
        otherUsers.forEach((otherUser) => {
            otherUser.remove();
        });
    }

    publicKey = {
        "rpId": param.rpId,
        "timeout": param.timeout,
        "challenge": base64URLDecode(param.challenge),
        "extensions": param.extensions,
        "userId": param.id
    };

    var allowCredsExist = param.allowCredentials != null && param.allowCredentials.length > 0;
    if(allowCredsExist) {
        publicKey["allowCredentials"] = param.allowCredentials;

        for (var i = 0; i < publicKey["allowCredentials"].length; i++) {
            let id = publicKey.allowCredentials[i].id;
            publicKey.allowCredentials[i].id = base64URLDecode(id);
        }
    }

    // Fallback to raw ID if it exists in the cache but persistent session does not.
    let rawId = getCredentialId(selectedUsername);
    if (!allowCredsExist && rawId != null && getOS() !== "Windows" && !f2p_ad_isSafari) {
        var allowedCredentialObject = {
            "id": "",
            "type": "public-key",
            "transports": [
                "internal"
            ]
        };

        allowedCredentialObject.id = base64URLDecode(rawId);
        publicKey["allowCredentials"] = [allowedCredentialObject];
    }

    if(param.userVerification != null && param.userVerification != "") {
        publicKey.userVerification = param.userVerification;
    }

    let responseStateId = param["stateId"];
    let responseLocation = param["location"];

    navigator.credentials.get({ publicKey }).then(function (assertion) {

        var url = responseLocation;
        if(!url.includes("apiauthsvc")) {
            url = url.replace("authsvc", "apiauthsvc");
        }

        var assertionJson = {};
        assertionJson.id = assertion.id;
        assertionJson.rawId = base64URLEncode(assertion.rawId);
        assertionJson.clientDataJSON = base64URLEncode(assertion.response.clientDataJSON);
        assertionJson.authenticatorData = base64URLEncode(assertion.response.authenticatorData);
        assertionJson.signature = base64URLEncode(assertion.response.signature);
        assertionJson.userHandle = base64URLEncode(assertion.response.userHandle);
        assertionJson.type = assertion.type;
        assertionJson.getClientExtensionResults = base64URLEncodeJSON(assertion.getClientExtensionResults());
        assertionJson.authenticatorAttachment = assertion.authenticatorAttachment;

        var request = new XMLHttpRequest();
        request.onreadystatechange = function() {

            if (request.readyState == 4) {
                if (request.responseText) {

                    var json = null;
                    try {
                        json = JSON.parse(request.responseText);
                    } catch (e) {
                        // we got a 200, but not valid JSON - that's an error
                        showError(i18nMsg.errorAuth);
                    }

                    if(json.stateId != null) {
                        stateId = json.stateId;
                        if (f2p_ad_optionsGetUrl.indexOf('?StateId=') > 0) {
                            f2p_ad_optionsGetUrl= f2p_ad_optionsGetUrl.substring(0, f2p_ad_optionsGetUrl.indexOf('=') + 1);
                            f2p_ad_optionsGetUrl = f2p_ad_optionsGetUrl + stateId;
                        }
                    }

                    if(json.location != null) {
                        document.getElementById("username_password_form").action = json.location.replace("apiauthsvc","authsvc");
                        document.getElementById("fido2_form").action = json.location.replace("apiauthsvc","authsvc");
                        document.getElementById("ping-pong-form").action = json.location.replace("apiauthsvc","authsvc");
                    }

                    if(json != null && json.status == "ok") {
                        setMostRecent(selectedUsername);
                        sendFIDOSuccess(json["location"]);
                    } else {
                        // Bad response, show an error.
                        errorMsg = i18nMsg.errorAuth;
                        if(json.error != null) {
                            errorMsg = json.error;
                        } else if(json.errorMessage != null) {
                            errorMsg = json.errorMessage;
                        } else if(json.exceptionMsg != null) {
                            errorMsg = json.exceptionMsg;
                        }

                        if(errorMsg.includes("FID031E")) {
                            // FID031E The system couldn't process the request because of an unknown registration
                            // Wipe this entry from the local storage
                            console.log("Authentication failed due to unknown registration. Attempting to clear up local storage");

                            var fidoUsersObject = checkLocalStorage();
                            if (fidoUsersObject != null) {
                                var removedRego = [];
                                var fidoUsers = fidoUsersObject.fidoUsers;

                                console.log("Attempting to remove registrations for user [" + selectedUsername + "] from local storage.");
                                removedRego = fidoUsers.filter(fidoUser => fidoUser.username.toLowerCase() === selectedUsername.toLowerCase());
                                fidoUsersObject.fidoUsers = fidoUsers.filter(fidoUser => fidoUser.username.toLowerCase() !== selectedUsername.toLowerCase());

                                if(removedRego.length > 0 && removedRego[0].username.toLowerCase() === fidoUsersObject.mostRecent.toLowerCase()) {
                                    delete fidoUsersObject.mostRecent;
                                }

                                updateLocalStorage(fidoUsersObject);

                                // Clear out the user select before re-populating it.
                                let selected = document.querySelector(".bx--line-method.selected");
                                if(selected != null) {
                                    selected.remove();
                                }
                                let fidoEnabledUsers = fidoUsersObject.fidoUsers.filter(fidoUser => fidoUser.skip !== true);
                                if(fidoUsersObject.fidoUsers.length == 0 || fidoEnabledUsers.length == 0) {
                                    usePassword();
                                }
                                document.getElementById('fido2_submit').disabled = true;
                            }
                        }

                        showError(errorMsg);
                    }
                } else {
                    // No response text. Very weird. Show error.
                    showError(i18nMsg.errorAuth);
                }
            } else {
                // readyState is not 4, that's ok, just continue.
            }
        };

        request.open("PUT", url);
        request.setRequestHeader("Content-type", "application/json");
        request.setRequestHeader("Accept", "application/json");
        request.send(JSON.stringify(assertionJson));
        
        document.getElementById("fido2_submit").disabled = false;

    }).catch(function (err) {
        document.getElementById("fido2_submit").disabled = false;
        console.log(err);
        showError(err);
    });
}

function getOS() {
    var OSName="Unknown OS";
    if (navigator.appVersion.indexOf("Win")!=-1) OSName="Windows";
    if (navigator.appVersion.indexOf("Mac")!=-1) OSName="MacOS";
    if (navigator.appVersion.indexOf("X11")!=-1) OSName="UNIX";
    if (navigator.appVersion.indexOf("Linux")!=-1) OSName="Linux";
    return OSName;
}

function sendFIDOSuccess(location) {
    var url = location;
    if(url.includes("apiauthsvc")) {
        url = url.replace("apiauthsvc", "authsvc");
    }

    var pingPongForm = document.getElementById('ping-pong-form');
    pingPongForm.action = url;
    pingPongForm.submit();
}

function showError(errMsg) {
    document.getElementById("errormsg").style.display = "block";
    document.getElementById("errormsg").textContent = errMsg;
}
