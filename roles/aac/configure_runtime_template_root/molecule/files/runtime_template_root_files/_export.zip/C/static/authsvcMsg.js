var authsvcMsg = {

"twoStepVerification":"Two-Step Verification",
"twoStepVerificationSettings":"Two-Step Verification Settings",
"twoStepVerificationSetup":"Set up two-step verification",

// Titles
"authenticate":"Authenticate",
"verification":"Verification",
"validation":"Validation",
"login":"Login",
"register":"Registration",

"howToFIDOTitle": "FIDO2 PAIR Demo",

"identifierFirstTitle": "Identifier First Authentication",
"signInOptions":"Sign in options",
"mmfa": "Mobile Multi-Factor Authentication",
"mmfaPending": "Mobile Multi-Factor Pending Authentication",

"enable":"Enable",
"enabled":"Enabled",
"disable":"Disable",
"disabled":"Disabled",

//Buttons
"back":"Back",
"submit":"Submit",
"verify":"Verify",
"add":"Add",
"remove":"Remove",
"save":"Save",
"validate":"Validate",
"finish":"Finish",
"signIn":"Sign in",
"choose":"Choose",
"enterCode":"Enter code",
"sendCode":"Send code",
"letsGo":"Let's go",
"signInFaster": "Sign in faster",
"continue": "Continue",
"rememberMe": "Remember me",
"showPassword": "Show password",
"actions": "Actions",
"checkStatus": "Check status",

"usernameInstructions":"Please enter your username to login:",
"username":"Username",
"password":"Password",

"welcome":"Welcome!",
"errorLabel":"Error",
"errorColonLabel":"Error: ",
"okGotIt":"Ok, got it.",
"enrollNow":"Enroll now",
"setUp":"Set up",
"done":"Done",
"success": "Success!",
"hello": "Hello USERNAME_MACRO!",
"detail": "Detail",

"redirect": "Redirect",
"redirecting": "Redirecting...",

"letsMakeSure":"Let's make sure it's you",
"letsRegisterToken":"Let's register your new Authenticator",
"letsRegisterFIDO":"Let's register your FIDO enabled device",
"fido2Authentication":"FIDO2 Authentication",
"fido2Registration":"FIDO2 Registration",
"fido2Instructions":"Check your browser for instructions on what to do next with your authenticator.",
"fido2Nickname":"Provide a nickname for this registration.",
"fido2ReadyInstructions":"Ready to use FIDO2 to verify it's you?",
"fido2SignInReady": "Your new sign in is ready for use.",
"fido2AuthenticateWith": "Authenticate with FIDO2",
"fido2FirstLine": "Want to sign in faster? Add device authentication when signing in to use your device's biometric unlock instead.",
"fido2SecondLine": "Note: Any users that are able to unlock this device with biometric unlock will also be able to access your account.",
"fido2Yes": "Yes",
"fido2NotNow": "Not now",
"fido2Never": "Never on this device",
"fido2ChooseAccount": "Pick an account to continue:",
"howToSignIn":"How would you like to sign in?",

"fido2Options":"Advanced Registration Options:",
"fido2RequireResidentKey":"Require resident key",

"user_not_found": "The user was not found.",
"username_password_mech_not_configured": "The Username Password Mechanism was not configured correctly.",
"login_failed": "Login failed. You have used an invalid user name or password.",

"no_second_factor": "No second factor methods enrolled.",

"genericBranch": "Generic Branching",
"chooseBranch": "Choose a branch",
"genericInstructions": "Pick an option from the list below.",

"deviceUnlock":"Security Key / Device Unlock",
"deviceUnlockWin":"Security Key / Windows Hello",
"deviceUnlockMac":"Security Key / Touch ID",

"fidoDescription": "Use a security key or this device's unlock method",
"mmfaDescription": "Get a push notification to your phone",
"passwordDescription": "Use your username and password",
"mmfaSelectDesc": "Please select which device you would like to use for authentication:",
"mmfaPendingDesc": "A notification was sent to your device. If you haven't received it yet, open IBM Verify.",
"mmfaTxnDetails": "Transaction details: ",
"mmfaStatus": "Status: ",
"mmfaRefreshDesc": "Click here to refresh the status of the transaction.",

"knowledgeQuestions": "Answer Security Questions",

"badOptionsRequest": "There was an issue with the options request.",

"fileUpdateMessage":"Warning: Update Template Files via File Downloads/Template Files to see revamped UI",

"mmfaTransactionStatusError":"An error has occurred while checking transaction status",

"qrloginLoginStatusError":"An error has occurred while checking login status",

"unexpectedResponse":"An unexpected response was received. Response Status: ",

"somethingWentWrong":"Something went wrong. Click to view error, or try again."
};
