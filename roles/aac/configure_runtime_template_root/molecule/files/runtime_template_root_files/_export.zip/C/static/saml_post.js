var signOnText = 'Please wait...';
document.write(signOnText);
document.forms[0].submit();
