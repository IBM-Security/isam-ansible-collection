window.addEventListener("load", startup);

var muac_scriptDataset = document.currentScript.dataset;
var muac_errorMessage = muac_scriptDataset.errorMessage;

function displayError() {
    if (muac_errorMessage != "") {
        var errorMsg = document.getElementById("errorMessage");
        errorMsg.textContent = errorMsg.textContent + muac_errorMessage;

        var errorDiv = document.getElementById("errorDiv");
        errorDiv.className = "errorMessage visible";
    }
}

function startup() {
    displayError();
}
