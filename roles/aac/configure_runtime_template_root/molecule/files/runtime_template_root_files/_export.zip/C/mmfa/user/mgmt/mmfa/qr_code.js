var getRequest = null;
var deleteRequest = null;
var code = null;
var clientId = null;

document.addEventListener('DOMContentLoaded', function () {
    code = getQueryParam("code");
    clientId = getQueryParam("client_id");
    if (code) {
        createQRCode(code, clientId);
        getQRCode(code, clientId);
        setupTimer();
    }
});

function buildClientQueryParam(clientId) {
    var clientParam = "";
    if (clientId != null && clientId.length > 0) {
        clientParam = "&client_id=" + clientId;
    }

    return clientParam;
}

function getQRCode(code, clientId) {
    getRequest = new XMLHttpRequest();
    getRequest.onreadystatechange = processGetQRCodeRequest;
    getRequest.open("GET", qrCodeBaseUrl + "/json?code=" + code + buildClientQueryParam(clientId), true);
    getRequest.send(null);
}

function processGetQRCodeRequest() {
    
    if (getRequest.readyState == 4) {
        if(getRequest.status == 200) {
            if (getRequest.responseText == "Not found") {
            } else {
                var response = JSON.parse(getRequest.responseText);
                
                var url = document.getElementById("detailsUrl");
                url.innerHTML = "Details: "+response['details_url'];
                var code = document.getElementById("accessCode");
                code.innerHTML = "Authorization Code: "+response['code'];
                var clientId = document.getElementById("clientId");
                clientId.innerHTML = "Client ID: "+response['client_id'];
            }
        }
    }
}

function createQRCode(code, clientId) {
    document.getElementById("qr_img").src = junction + "/sps/mmfa/user/mgmt/qr_code?code=" + code + buildClientQueryParam(clientId);

}

function getQueryParam(paramName) {
    if (paramName != null && paramName.length > 0) {
        var queryString = window.location.search.substring(1);
        var params = queryString.split("&");
        for ( var i = 0; i < params.length; i++) {
            var keyValue = params[i].split("=");
            if (keyValue[0] == paramName) {
                return keyValue[1];
            }
        }
    }

    return null;
}

function setupTimer(){
    document.querySelector("#codeTimer").textContent = "Code expires in 0:00:00";
    makeAjaxRequest("GET", grantBaseUrl, getGrantUUID, null);
}

function getGrantUUID(getRequest){
    if(getRequest.readyState == 4 && getRequest.status ==200) {
        if(getRequest.responseText == "Not found") {
        } else {
            var grants = JSON.parse(getRequest.responseText)["grants"];

            for (var obj in grants){
                var grant = grants[obj];
                if (grant["clientId"] == clientId){
                    var tokens = grants[obj]["tokens"];

                    for (var object in tokens){
                        var token = tokens[object];

                        if (token["subType"] == "authorization_code"){
                            startTimer(token["lifetime"]);
                            return;
                        }
                    }
                }
            }
        }
    }
}


function startTimer(time) {
    var time = parseInt(time);
    if (time != null & parseInt(time) > 0) {
        var auth_code_timer = setInterval(function () {
            var curr_secs = parseInt(time % 60, 10);
            var curr_mins = parseInt(time / 60, 10);
            var curr_hrs = parseInt(curr_mins / 60, 10);

            curr_secs = curr_secs < 10 ? "0" + curr_secs : curr_secs;
            curr_mins = curr_mins < 10 ? "0" + curr_mins : curr_mins;

            var timer_text = "";

            if(curr_hrs != 0) {
                timer_text += curr_hrs + ":";
            }

            timer_text += curr_mins + ":" + curr_secs;

            document.querySelector("#codeTimer").textContent = "Code expires in " + timer_text;

            if (--time < 0) {
                document.querySelector("#codeTimer").innerHTML = "Your QR code has expired. <a id=\"generateNewCode\" href=\"#\">Generate a new code.</a>";
                document.getElementById("generateNewCode").addEventListener("click", generateNewCode);
                //document.querySelector("#codeTimerButton").innerHTML = "<input class=\"button-1 ease-in-anim-fast\" type=\"button\" value=\"Register new authenticator\" onClick=\"registerAuthenticator();\">";
                clearInterval(auth_code_timer);
            }
        }, 1000);
    }
}

function generateNewCode() {
    registerAuthenticator();
    return false;
}

function checkIfIE(){
    var ie = false;
    var ua = window.navigator.userAgent;
    var old_ie = ua.indexOf('MSIE ');
    var new_ie = ua.indexOf('Trident/');

    if ((old_ie > -1) || (new_ie > -1)) {
        ie = true;
    }

    return ie;
}

function registerAuthenticator() {
    var codeURL = authorizeUrl + "?client_id=" + clientId + "&response_type=code&scope=mmfaAuthn";

    if (checkIfIE()){
        window.location.href = codeURL;
    } else {
        qrCodeRequest = new XMLHttpRequest();
        qrCodeRequest.onreadystatechange = processRegisterRequest;

        qrCodeRequest.open("GET", codeURL, true);
        qrCodeRequest.send(null);
    }
}

function processRegisterRequest() {
    if(qrCodeRequest.readyState == 4 && qrCodeRequest.status ==200) {
        if(qrCodeRequest.responseText == "Not found") {
        } else {
            window.location.href = qrCodeRequest.responseURL;
        }
    }
}
