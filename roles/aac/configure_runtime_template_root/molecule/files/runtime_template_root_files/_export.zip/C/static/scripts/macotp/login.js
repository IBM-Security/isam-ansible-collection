window.addEventListener("load", windowStart);

var macotpl_scriptDataset = document.currentScript.dataset;
var macotpl_errorMessage = macotpl_scriptDataset.errorMessage;
var macotpl_mappingRuleDataStr = macotpl_scriptDataset.mappingRuleData;
var macotpl_displaySelectButton = macotpl_scriptDataset.displayReselectButtonl
var macotpl_deliverAttrTxt = macotpl_scriptDataset.otpDeliveryAttr;

function displayError() {
    if (macotpl_errorMessage != "") {
        var errorMsg = document.getElementById("errorMessage");
        errorMsg.textContent = errorMsg.textContent + macotpl_errorMessage;

        var errorDiv = document.getElementById("errorDiv");
        errorDiv.className = "errorMessage visible";
    }
}

function displayMappingRuleData() {
    if (macotpl_mappingRuleDataStr != "") {
        var mrdText = document.getElementById("mappingRuleDataText");
        mrdText.textContent = mrdText.textContent + macotpl_mappingRuleDataStr;

        var mappingRuleDataDiv = document.getElementById('mappingRuleDataDiv');
        mappingRuleDataDiv.className = "visible";
    }
}

function displaySelectButton() {
    var reselectButtonDiv = document.getElementById('reselectButtonDiv');

    if (macotpl_displaySelectButton != "") {
        reselectButtonDiv.className = "";
    }
}

function displayDeliveryAttr() {
    var deliveryAttrSpan = document.getElementById('delivery_attr');

    if (macotpl_deliverAttrTxt != "") {
        deliveryAttrSpan.textContent = deliveryAttrSpan.textContent + macotpl_deliverAttrTxt;
        deliveryAttrSpan.className = "visible";
    }
}

function windowStart() {
    displayError();
    displayMappingRuleData();
    displaySelectButton();
    displayDeliveryAttr();
}