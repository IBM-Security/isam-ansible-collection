var scim_authenticator_schema = "urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Authenticator";
var scim_transaction_schema = "urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Transaction";

function ISAM_SCIM_INFO(mode, waitFunction, completeFunction, finalFunction) {
	//If user parameter is supplied, do it in the context of that user - otherwise for all users.
	//Different modes allowed:
	//- all
	//- transactions
	//- authenticators
	//- transactions+authenticators
	//- users
	var scim_base = "/scim/Me";
	var scim_query = null;
	switch (mode) {
		case "all":
			scim_query = "";
			break;
		case "allTransactions":
			scim_query = "?attributes=" + scim_transaction_schema + ":transactionsResolved," + scim_transaction_schema + ":attributesResolved," + scim_transaction_schema + ":transactionsPending," + scim_transaction_schema + ":attributesPending";
			break;
		case "resolvedTransactions":
			scim_query = "?attributes=" + scim_transaction_schema + ":transactionsResolved," + scim_transaction_schema + ":attributesResolved";
			break;
		case "pendingTransactions":
			scim_query = "?attributes=" + scim_transaction_schema + ":transactionsPending," + scim_transaction_schema + ":attributesPending";
			break;
		case "transactions":
			scim_query = "?attributes=" + scim_transaction_schema + ":transactionsPending," + scim_transaction_schema + ":transactionsResolved";
			break;
		case "authenticators":
			scim_query = "?attributes=" + scim_authenticator_schema + ":authenticators," + scim_authenticator_schema + ":fingerprintMethods," + scim_authenticator_schema + ":userPresenceMethods";
			break;
		case "authenticators+transactions":
			scim_query = "?attributes=" + scim_transaction_schema + ":transactionsPending," + scim_transaction_schema + ":transactionsResolved," + scim_authenticator_schema + ":authenticators," + scim_authenticator_schema + ":fingerprintMethods," + scim_authenticator_schema + ":userPresenceMethods";
			break;
		case "users":
			scim_query = "?attributes=userName,phoneNumbers,name";
			break;
	}

	getRequest = makeAjaxRequestJSON("GET", scim_base + scim_query, function(scimRequest) {
		if (scimRequest.readyState == 4) {
			if (scimRequest.status == 200) {
				if (scimRequest.responseText == "Not found") {} else {
					if(IsJsonString(scimRequest.responseText)){
						var response = JSON.parse(scimRequest.responseText);
						if (response != null) {
							//Response looks ~okay~, call the completeFunction
							completeFunction(scimRequest,finalFunction);
						}
					}else{
						return false;
					}
				}
			
			} else {
				//Still waiting on response, call the waitFunction
				if (typeof waitFunction != "undefined" && typeof waitFunction === "function") {
					waitFunction(scimRequest);
				}
			}
		} else {
			//Still waiting on response, call the waitFunction
			if (typeof waitFunction != "undefined" && typeof waitFunction === "function") {
				waitFunction(scimRequest);
			}
			if (scimRequest.readyState == 3) {
				if (scimRequest.responseURL.includes("TAM_OP") && scimRequest.responseText.includes("!DOCTYPE html") && mode != "pendingTransactions") {
					window.location = 'https://' + window.location.hostname + window.location.pathname;
				}else if(scimRequest.status == 404){
					if (finalFunction != "undefined" && typeof finalFunction == "function"){
						finalFunction(null);
					}
				}
			}
		}
	}, null);
	return getRequest;
}