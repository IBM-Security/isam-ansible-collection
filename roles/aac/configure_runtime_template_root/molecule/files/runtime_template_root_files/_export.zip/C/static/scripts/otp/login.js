window.addEventListener("load", startup);

var otpn_errorMsg = document.currentScript.dataset.errorTag;
var otpl_mapRuleData = document.currentScript.dataset.mappingRuleData;
var otpl_dispReselButton = document.currentScript.dataset.displayReselectButton
var otpl_deliveryAttr = document.currentScript.dataset.otpDeliveryAttr;
var otpl_methodType = document.currentScript.dataset.otpMethodType;

//<!-- Modified for TOTP -->
var login_OTP_METHOD_TYPE = otpl_methodType;
if (login_OTP_METHOD_TYPE == "totp_otp" || login_OTP_METHOD_TYPE == "hotp_otp" || login_OTP_METHOD_TYPE == "rsa_otp") {
    document.getElementById('otpHintSpan').style.cssText = 'display:none';
    document.getElementById('otpHintDashSpan').style.cssText = 'display:none';
}
//<!-- end modified for TOTP -->
//<!-- Modified for TOTP -->
//<!-- we use the method ID to decide if we are using TOTP. If we are, don't display the generate button. -->
var login_OTP_METHOD_TYPE = otpl_methodType;
if (login_OTP_METHOD_TYPE == "totp_otp" || login_OTP_METHOD_TYPE == "hotp_otp" || login_OTP_METHOD_TYPE == "rsa_otp") {
    document.getElementById('regenerateButtonDiv').style.cssText = 'display:none';
}

function displayError() {
    if (otpn_errorMsg != "") {
        var errorMsg = document.getElementById("errorMessage");
        errorMsg.textContent = errorMsg.textContent + otpn_errorMsg;

        var errorDiv = document.getElementById("errorDiv");
        errorDiv.className = "errorMessage visible";
    }
}

function displayMappingRuleData() {
    if (otpl_mapRuleData != "") {
        var mrdText = document.getElementById("mappingRuleDataText");
        mrdText.textContent = mrdText.textContent + otpl_mapRuleData;

        var mappingRuleDataDiv = document.getElementById('mappingRuleDataDiv');
        mappingRuleDataDiv.className = "visible";
    }
}

function displaySelectButton() {
    var reselectButtonDiv = document.getElementById('reselectButtonDiv');

    if (otpl_dispReselButton != "") {
        reselectButtonDiv.className = "";
    }
}

function displayDeliveryAttr() {
    var deliveryAttrSpan = document.getElementById('delivery_attr');

    if (otpl_deliveryAttr != "") {
        deliveryAttrSpan.textContent = deliveryAttrSpan.textContent + otpl_deliveryAttr;
        deliveryAttrSpan.className = "visible";
    }
}

function startup() {
    displayError();
    displayMappingRuleData();
    displaySelectButton();
    displayDeliveryAttr();
}