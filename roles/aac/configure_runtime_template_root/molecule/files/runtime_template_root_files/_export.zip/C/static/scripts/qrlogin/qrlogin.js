window.addEventListener("load", onLoadPage);

var qrl_dsi = document.currentScript.dataset.dsi;
var qrl_lsi = document.currentScript.dataset.lsi;
var qrl_inBranch = document.currentScript.dataset.inBranch;
var qrl_action = document.currentScript.dataset.action;

var qrl_req = null;

var qrl_locationHostPort = location.hostname + (location.port ? ':' + location.port : '');
var qrl_baseURL = location.protocol + '//' + qrl_locationHostPort;
var qrl_jct = getJunctionName();
var qrl_formAction = qrl_jct + qrl_action.replace(/&operation=[a-z]*/, ''); // remove operation from initial action because we manage that separately now
var qrl_type = null; // will be null, unless the user presses one of the buttons
var qrl_ajaxTimer = null; // points to the result of setTimeout, so that a pending poll can be canceled
var qrl_ajaxActive = false; // is an ajax operation to the apiauthsvc currently active
var qrl_pollTime = 2000;

function processRequest(request) {

    if (request.readyState == 4) {
        console.log("The poll received status: " + request.status + " and response text is: " + request["responseText"]);
        // request done, process it
        if (request.status == 200) {
            var json = null;
            var responseText = null;
            if (request.responseText) {
                var responseText = request.responseText;
                var jsonResponse = null;
                try {
                    jsonResponse = JSON.parse(responseText);
                } catch (e) {
                    // we got a 200, but not valid JSON - that's an error
                }

                if (jsonResponse != null && jsonResponse["action"] != null) {
                    // this is a successful poll, decide what to do next

                    // check if we are ready to login
                    var loginReady = jsonResponse["loginready"];
                    if (loginReady != 'true') {

                        if (jsonResponse.action != null) {
                            qrl_formAction = jsonResponse.action;
                        }
                        if (jsonResponse.location != null) {
                            qrl_formAction = jsonResponse.location;
                        }
                        // restart the poll unless there is a manual operation about to happen
                        if (qrl_type == null) {
                            qrl_ajaxTimer = window.setTimeout(startPolling, qrl_pollTime);
                        }
                    } else {
                        // make sure we don't try and do anything else
                        qrl_type = null;
                        if (jsonResponse.action != null) {
                            qrl_formAction = jsonResponse.action;
                        }
                        if (jsonResponse.location != null) {
                            qrl_formAction = jsonResponse.location;
                        }
                        // we must have an answer - get the browser moving again
                        var myForm = document.getElementById('submitForm');
                        myForm.action = qrl_formAction.replace("apiauthsvc", "authsvc");
                        myForm.dsi.value = qrl_dsi;
                        myForm.submit();
                    }
                } else {
                    // 200, but not json response body - error

                    // make sure we don't try and do anything else
                    qrl_type = null;

                    // set up catchall error/status messages
                    errorStr = authsvcMsg.qrloginLoginStatusError;

                    // display whatever we came up with, and hide further operations
                    displayError();
                }
            }
        } else {
            // not a good 200 response - is there error text to display?

            // make sure we don't try and do anything else
            qrl_type = null;

            // set up catchall error/status messages
            errorStr = authsvcMsg.qrloginLoginStatusError;
            errorStr = authsvcMsg.unexpectedResponse + request.status;
            if (request.responseText) {
                try {
                    var rspObj = JSON.parse(request.responseText);
                    if (rspObj != null && rspObj.error != null) {
                        errorStr = rspObj.error;
                    }
                } catch (e) {
                    // probably not JSON - just go with our generic error message
                }
            }

            // display whatever we came up with, and hide further operations
            displayError();
        }

        //
        // If a button was pressed while we were doing the last ajax operation,
        // act on it now
        //
        if (qrl_type != null) {
            submitReselect();
        }

        // we are no longer in an active poll
        qrl_ajaxActive = false;

    } else {
        // readyState is not 4, that's ok, just continue.
    }
}

function startPolling() {
    qrl_ajaxActive = true;
    var url = buildPollURL();
    console.log("Polling: " + url);
    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {
        processRequest(request);
    };
    request.open("PUT", url);
    request.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    request.setRequestHeader("Accept", "application/json;charset=UTF-8");
    var putData = {
        "operation": "verify",
        "polling": "true"
    };
    putData["dsi"] = qrl_dsi;
    request.send(JSON.stringify(putData));
}

function disableSubmitButtons() {
    document.getElementById("fido_submit_button").disabled = true;
    document.getElementById("submit_button").disabled = true;
}

function performOperation(submittedType) {

    disableSubmitButtons();
    qrl_type = submittedType;
    if (qrl_ajaxTimer != null) {
        window.clearTimeout(qrl_ajaxTimer);
    }

    // if we are not in an active ajax call, manually invoke it
    // if we are, then the callback handler will do this
    // after it get's it's latest response and updates formAction
    if (!qrl_ajaxActive) {
        submitReselect();
    }
}

function submitReselect() {
    // posts the operation form in the window context
    var operationForm = document.getElementById("operationForm");

    // update the action, and the hidden val which used to be the submit button
    operationForm.action = qrl_baseURL + qrl_formAction.replace("apiauthsvc", "authsvc") + "&operation=returnToDecision";
    console.log("operationForm.action: " + operationForm.action);
    operationForm.type.value = qrl_type;

    if (qrl_type == "password") {
        var input = document.createElement('input');
        input.type = 'hidden';
        input.name = "username";
        input.value = document.getElementById("username").value;
        operationForm.appendChild(input);
        var pInput = document.createElement('input');
        pInput.type = 'hidden';
        pInput.name = "password";
        pInput.value = document.getElementById("password").value;
        operationForm.appendChild(pInput);
    }

    addHidden(operationForm, "ReturnToDecision", "ReturnToDecision");

    operationForm.submit();
}

function addHidden(theForm, key, value) {
    // Create a hidden input element, and append it to a form
    var input = document.createElement('input');
    input.type = 'hidden';
    input.name = key;
    input.value = value;
    theForm.appendChild(input);
}

function displayError() {
    var errorDiv = document.getElementById('errId');
    if (errorStr != "") {
        errorDiv.textContent = errorStr;
        errorDiv.className = "error-msg visible";

        // Hide the QR Code
        document.getElementById('qrcode').classList.add("hidden");
    } else {
        errorDiv.className = "hidden";
        document.getElementById('qrcode').classList.remove("hidden");
    }
}

function enableButton() {
    var usernameInput = document.getElementById("username");
    var passwordInput = document.getElementById("password");

    if (usernameInput.value != null && usernameInput.value != "" && usernameInput.validity.valid &&
            passwordInput.value != null && passwordInput.value != "" && passwordInput.validity.valid) {
        document.getElementById("submit_button").disabled = false;
    } else {
        document.getElementById("submit_button").disabled = true;
    }
}

function chooseAlternative(value) {
    if (value.options[value.selectedIndex].id == "password-option") {
        document.getElementById("username_form").classList.remove("hidden");
        document.getElementById("fido2_div").classList.add("hidden");
    } else {
        document.getElementById("username_form").classList.add("hidden");
        document.getElementById("fido2_div").classList.remove("hidden");
    }
}

function buildPollURL() {
    var result = qrl_baseURL + qrl_formAction + "&operation=verify&ajax=true";
    if (!result.includes("apiauthsvc")) {
        result = result.replace("authsvc", "apiauthsvc");
    }
    return result;
}

function onLoadPage() {
    if (qrl_inBranch && qrl_inBranch.length > 0) {
        document.getElementById("alternatives").classList.remove("hidden");
        document.getElementById("fido_img").src = getJunctionName() + "/sps/static/design_images/u2f_device.svg";

        var input = document.querySelector('#username');
        input.addEventListener("keyup", function(event) {
            event.preventDefault();
            // Enter key is 13
            if (event.keyCode === 13) {
                document.querySelector('#submit_button').click();
            }
        });
        var input = document.querySelector('#password');
        input.addEventListener("keyup", function(event) {
            event.preventDefault();
            // Enter key is 13
            if (event.keyCode === 13) {
                document.querySelector('#submit_button').click();
            }
        });
    }

    /*
     * Generate the qrcode
     */
    var qrgenservlet = qrl_baseURL + '/mga/sps/mmfa/user/mgmt/qr_code?lsi=' + qrl_lsi;
    qrdiv.innerHTML = "<img id=qrcode src=\"" + qrgenservlet + "\">";

    /*
     * Poll the auth svc to find out when we can leave this page.
     */
    if (qrl_ajaxTimer == null && !qrl_ajaxActive) {
        qrl_ajaxTimer = window.setTimeout(startPolling, qrl_pollTime);
    }

    document.getElementById("select_id").addEventListener("change", function() {
        chooseAlternative(this)
    });
    document.getElementById("fido_submit_button").addEventListener("click", function() {
        performOperation('fido2')
    });
    document.getElementById("username").addEventListener("input", enableButton);
    document.getElementById("password").addEventListener("input", enableButton);

    document.getElementById("submit_button").addEventListener("click", function() {
        performOperation('password')
    });
}