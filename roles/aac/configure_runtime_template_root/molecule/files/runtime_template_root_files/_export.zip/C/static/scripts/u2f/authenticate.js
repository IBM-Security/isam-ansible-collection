window.addEventListener("load", startup);

var u2fa_data_tags = document.getElementById('u2f_authenticate_tag');
var u2fa_datasetValues = u2fa_data_tags.dataset;
var u2fa_existingTokens = [];
var u2fa_filterAppId = window.location.origin;
var u2fa_appId = u2fa_datasetValues.u2fAppId;
var u2fa_challenge = u2fa_datasetValues.u2fChallenge;
var u2fa_version = u2fa_datasetValues.u2fVersion;
var u2fa_submitAction = u2fa_datasetValues.action;
var u2fa_cancelAction = u2fa_datasetValues.cancelAction;

var u2fa_authenticateRequest = {
    "appId": u2fa_appId,
    "challenge": u2fa_challenge,
    "version": u2fa_version
};

var u2faJSON = JSON.parse(u2fa_data_tags.textContent);
var u2fa_existingTokenString = u2faJSON["u2fTokens"];

function checkTokens() {
    if (u2fa_authenticateRequest.appId == null || u2fa_authenticateRequest.appId.trim() == "") {
        u2fa_authenticateRequest.appId = window.location.protocol + "//" + window.location.hostname;
        if (location.port) {
            u2fa_authenticateRequest.appId += ":" + location.port;
        }
    }

    var tokens = (u2fa_existingTokenString != undefined)?JSON.parse(JSON.stringify(u2fa_existingTokenString)):[];
    if (tokens.length > 0) {
        for (var i = 0; i < tokens.length; i++) {
            var tokenAttrs = tokens[i];
            var token = {
                keyHandle: tokenAttrs['key_handle'],
                version: u2fa_authenticateRequest.version,
                appId: tokenAttrs['app_id']
            };
            if (token['appId'] == u2fa_filterAppId) {
                u2fa_existingTokens.push(token);
            }
        }
        document.getElementById("tokenDiv").style.display = "block";
        authenticateToken();

    } else {
        document.getElementById("noTokensDiv").style.display = "block";
    }
}

function authenticateToken() {
    if (u2f != null) {
        u2f.sign(
            u2fa_authenticateRequest.appId,
            u2fa_authenticateRequest.challenge,
            u2fa_existingTokens,
            function(response) {
                if (response["signatureData"] != null) {
                    document.getElementById("authenticateForm").keyHandle.value = response.keyHandle;
                    document.getElementById("authenticateForm").clientData.value = response.clientData;
                    document.getElementById("authenticateForm").signatureData.value = response.signatureData;
                    document.getElementById("authenticateForm").submit();
                } else {
                    var errMsg = i18nMsg.errorAuth;
                    if (response.errorCode) {
                        errMsg = i18nMsg.errorAuthSysadmin;
                        if (response.errorCode == 2 | response.errorCode == 4) {
                            errMsg = i18nMsg.errorAuth;
                        } else if (response.errorCode == 5) {
                            errMsg = i18nMsg.errorTimedOut;
                        }
                    }
                    showError(errMsg);
                }
            },
            300
        );

    } else {
        showError(i18nMsg.errorAuthSysadmin);
    }
}

function cancel() {
    document.getElementById("cancelForm").submit();
}

function populateStrings() {
    document.title = i18nMsg.titleAuth;
    document.getElementById("pageTitle").textContent = i18nMsg.authPageTitle;
    document.getElementById("tokenPrompt").textContent = i18nMsg.tokenPrompt;
    document.getElementById("noTokensPrompt").textContent = i18nMsg.noTokensPrompt;
    document.getElementById("cancelButton").value = i18nMsg.cancel;
}

function showError(errMsg) {
    document.getElementById("errId").textContent = errMsg;
    document.getElementById("error-box").className = "error-box active";
}

function startup() {
    populateStrings();
    checkTokens();

    document.getElementById("cancelButton").addEventListener("click", cancel);
}