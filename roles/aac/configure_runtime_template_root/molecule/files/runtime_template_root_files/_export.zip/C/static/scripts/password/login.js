window.addEventListener('load', (event) => {
    onLoadPage();
});

var pwd_login_dataVals = document.currentScript.dataset;
var pwd_login_errormsg = pwd_login_dataVals.errorMessage;

function onLoadPage() {
    showError();
    setFocus();
}

function showError() {
    var elem = document.getElementById("errId");
    if (pwd_login_errormsg == "") {
        elem.className = "";
    } else {
        elem.className = "errorMessage";
    }
}

function setFocus() {
    document.getElementById("username").focus();
}
