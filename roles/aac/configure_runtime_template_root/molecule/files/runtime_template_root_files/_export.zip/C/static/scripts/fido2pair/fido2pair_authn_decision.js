window.addEventListener('load', function() {
    startup();

    var jsLinks = document.querySelectorAll('[href="#"]');

    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }
});

var f2p_ad_tagData = document.currentScript.dataset;
var f2p_ad_tagJson = JSON.parse(document.getElementById('f2p_ad_tags').textContent);

var f2p_ad_rpId = f2p_ad_tagData.fidoRpId;
var f2p_ad_timeout = f2p_ad_tagData.fidoTimeout;
var f2p_ad_challenge = f2p_ad_tagData.fidoChallenge;
var f2p_ad_userVerification = f2p_ad_tagData.fidoUserVerification;
var f2p_ad_userId = f2p_ad_tagData.fidoUserId;
var f2p_ad_status = f2p_ad_tagData.fidoStatus;
var f2p_ad_errorMessage = f2p_ad_tagData.fidoErrorMessage;
var f2p_ad_stateId = f2p_ad_tagData.state;
var f2p_ad_action = f2p_ad_tagData.action;
var f2p_ad_persistentUsername = f2p_ad_tagData.persistentUsername;
var f2p_ad_allowCredentialsStr = f2p_ad_tagJson["fidoAllowCredentials"];
var f2p_ad_extensionsStr = f2p_ad_tagJson["fidoExtensions"];
var f2p_ad_inFIDOBranch = false;

// Some browsers have a restriction where the navigator.credentials.get call cannot be
// initiated from an automatic action like onload but instead must be called from a
// user initiated action like a button.
// The following boolean can be used to control whether the button to trigger
// navigator.credentials.get is always shown (false), or whether the button should be
// only shown for browsers that have the user-initiation restriction (true).
var f2p_ad_browserCheck = true;

var f2p_ad_publicKey = null;

// Safari 3.0+ "[object HTMLElementConstructor]"
var f2p_ad_isSafari = /constructor/i.test(window.HTMLElement) || (function(p) {
    return p.toString() === "[object SafariRemoteNotification]";
})(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

var f2p_ad_fidoStorage = window.localStorage;

var f2p_ad_optionsGetUrl = getJunctionName() + f2p_ad_action;

function checkLocalStorage() {
    var fidoUsersObject = JSON.parse(f2p_ad_fidoStorage.getItem('fidoUsersObject'));
    return fidoUsersObject;
}

function updateLocalStorage(fidoUsersObject) {
    f2p_ad_fidoStorage.setItem('fidoUsersObject', JSON.stringify(fidoUsersObject));
}

function setMostRecent(username) {
    var fidoUsersObject = checkLocalStorage();

    if (fidoUsersObject != null) {
        fidoUsersObject.mostRecent = username
        updateLocalStorage(fidoUsersObject);
    }
}

function createEventListeners() {

    document.getElementById("fido2_submit").addEventListener("click", optionsGet);
    document.getElementById("sign-in-another-way").addEventListener("click", usePassword);

    var loginForm = document.getElementById('username_password_form');
    var formSubmit = document.getElementById('formSubmit');

    loginForm.addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13
        if (event.keyCode === 13) {
            formSubmit.click();
        }
    });

    formSubmit.addEventListener("click", function(event) {
        event.preventDefault();
        var valid = true;
        loginForm.userInput = {};
        loginForm.userInput.username = encodeURI(document.getElementById('username').value);
        loginForm.userInput.password = encodeURI(document.getElementById('password').value);
        if (loginForm.userInput.username == "") {
            document.getElementById('username').required = 'true';
            valid = false;
        }
        if (loginForm.userInput.password == "") {
            document.getElementById('password').required = 'true';
            valid = false;
        }
        if (valid) {
            let fidoUsersObject = checkLocalStorage();
            if (fidoUsersObject != null) {
                let fidoUsers = fidoUsersObject.fidoUsers;
                let existingRego = fidoUsers.filter(fidoUser => fidoUser.username === loginForm.userInput.username);
                if(existingRego.length > 0) {
                    loginForm.existingRego.value = "true";
                }
            }
            if(f2p_ad_inFIDOBranch) {
                loginForm.operation.value = "returnToDecision";
            }
            loginForm.submit();
        }
    });
}

function populateStrings() {
    document.title = authsvcMsg.howToFIDOTitle;
    document.querySelector('#username_password_div h1').textContent = authsvcMsg.login;
    document.querySelector('#fido-login-div h1').textContent = authsvcMsg.fido2AuthenticateWith;
    document.getElementById('account-instructions').textContent = authsvcMsg.fido2ChooseAccount;
    document.querySelector('#fido-login-div button').textContent = authsvcMsg.signIn;
    document.getElementById('usernameLabel').textContent = authsvcMsg.username;
    document.getElementById('passwordLabel').textContent = authsvcMsg.password;
    document.getElementById('formSubmit').value = authsvcMsg.login;
}

function detectFIDOUsers() {
    // Get any entries from browser local storage and add username to the select
    // input defaulting to most recently used.
    var fidoUsersObject = checkLocalStorage();
    if (fidoUsersObject != null && fidoUsersObject.fidoUsers != null &&
            fidoUsersObject.fidoUsers.length > 0) {
        // display FIDO div
        var fidoArray = fidoUsersObject.fidoUsers;
        var mostRecent = fidoUsersObject.mostRecent;

        var userSelect = document.getElementById("userSelectSection");
        var atLeastOneUserFound = false;
        fidoArray.forEach(fidoUser => {
            if (!fidoUser.skip) {
                if(f2p_ad_persistentUsername != null && f2p_ad_persistentUsername != "" &&
                        fidoUser.username != f2p_ad_persistentUsername)
                {
                    return;
                }
                // Found a non skipped user
                atLeastOneUserFound = true;
                var userDiv = document.createElement('div');
                userDiv.className = "bx--line-method";
                userDiv.username = fidoUser.username;
                userDiv.tabIndex = "0";

                userDiv.onclick = function () {
                    let selected = document.querySelector(".bx--line-method.selected");
                    if(selected != null) {
                        selected.classList.remove('selected');
                    }

                    this.classList.add('selected');
                    document.getElementById('fido2_submit').disabled = false;
                };

                userDiv.addEventListener("keyup", function(event) {
                    event.preventDefault();
                    // Enter key is 13, space is 32
                    if (event.keyCode === 13 || event.keyCode == 32) {
                        this.click();
                    }
                });

                var iconAndNameDiv = document.createElement('div');
                iconAndNameDiv.className = "iconAndName";

                var img = document.createElement('img');
                img.className = "userIcon";
                img.src = getJunctionName()+"/sps/static/design_images/user.svg";
                iconAndNameDiv.appendChild(img);

                var nameDiv = document.createElement('div');
                nameDiv.textContent = fidoUser.username;
                iconAndNameDiv.appendChild(nameDiv);

                userDiv.appendChild(iconAndNameDiv);
                userSelect.appendChild(userDiv);

                if (fidoUser.username == mostRecent || fidoUser.username == f2p_ad_persistentUsername) {
                    userDiv.classList.add('selected');
                    document.getElementById('fido2_submit').disabled = false;
                }

            }
            else {
                return false;
            }
        });

        // If no unskipped users were found then return should be false
        return atLeastOneUserFound;
    } else {
        return false;
    }
}

function getPersistentToken(selectedUsername) {
    let fidoUsers = checkLocalStorage().fidoUsers;
    let selectedRego = fidoUsers.filter(fidoUser => fidoUser.username === selectedUsername);
    if(selectedRego.length > 0 && selectedRego[0].persistent != null) {
        return selectedRego[0].persistent;
    }
    return null;
}

function getCredentialId(selectedUsername) {
    let fidoUsers = checkLocalStorage().fidoUsers;
    let selectedRego = fidoUsers.filter(fidoUser => fidoUser.username === selectedUsername);
    if(selectedRego.length > 0 && selectedRego[0].rawId != null) {
        return selectedRego[0].rawId;
    }
    return null;
}

function usePassword() {
    document.getElementById("errormsg").style.display = "none";
    document.getElementById("username_password_div").classList.remove("hidden");
    document.getElementById("fido-login-div").classList.add("hidden");
}

function useFIDO() {
    document.getElementById("username_password_div").classList.add("hidden");
    document.getElementById("fido-login-div").classList.remove("hidden");
}

function startup() {
    populateStrings();
    createEventListeners();

    // Check browser for FIDO2 UVPA capability before enabling any FIDO2 processing
    PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
        .then((isuvpaa) => {

            if (isuvpaa) {
                // UVPA is available to browser.
                var fidoFound = detectFIDOUsers();
                if(fidoFound) {
                    useFIDO();
                }
            } else {
                // UVPA is not available to browser.
                var usernameForm = document.getElementById("username_password_form");
                usernameForm.skip.value = "skip";
            }
        }
    );
}
