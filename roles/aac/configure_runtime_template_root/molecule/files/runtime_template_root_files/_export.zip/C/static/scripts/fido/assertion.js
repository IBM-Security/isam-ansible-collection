window.addEventListener("load", startup);

var assertJSON = JSON.parse(document.getElementById('fido_assertion_tags').textContent);
var assert_dataSetValues = document.currentScript.dataset;

var assert_rpId = assert_dataSetValues.fidoRpId;
var assert_timeout = assert_dataSetValues.fidoTimeout;
var assert_challenge = assert_dataSetValues.fidoChallenge;
var assert_allowCredentials = assertJSON["fidoAllowCredentials"];
var assert_extensions = assertJSON["fidoExtensions"];
var assert_userVerification = assert_dataSetValues.fidoUserVerification;
var assert_userId = assert_dataSetValues.fidoUserId;
var assert_status = assert_dataSetValues.fidoStatus;
var assert_errorMessage = assert_dataSetValues.fidoErrorMessage;
var assert_stateId = assert_dataSetValues.state;
var assert_action = assert_dataSetValues.action;

// Some browsers have a restriction where the navigator.credentials.get call cannot be
// initiated from an automatic action like onload but instead must be called from a
// user initiated action like a button.
// The following boolean can be used to control whether the button to trigger
// navigator.credentials.get is always shown (false), or whether the button should be
// only shown for browsers that have the user-initiation restriction (true).
var assert_browserCheck = false;

var assert_publicKey = null;

function cancel() {
    document.getElementById("cancelForm").submit();
}

function base64URLEncodeJSON(json) {
    var str = JSON.stringify(json);
    var result = utf8tob64u(str);
    return result;
}

function base64URLEncode(bytes, encoding = 'utf-8') {
    if (bytes == null || bytes.length == 0) {
        return null;
    }
    var str = base64js.fromByteArray(new Uint8Array(bytes));
    str = str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    return str;
}

function base64URLDecode(str, encoding = 'utf-8') {
    if (str == null || str == "") {
        return null;
    }

    var str = str.replace(/-/g, '+').replace(/_/g, '\/');

    var pad = str.length % 4;
    if (pad) {
        str += new Array(5 - pad).join('=');
    }

    var bytes = base64js.toByteArray(str);
    return bytes.buffer;
}

function populateStrings() {
    document.title = authsvcMsg.fido2Authentication;
    document.querySelector('#assertion-section h1').textContent = authsvcMsg.twoStepVerification;
    document.getElementById("instructions").textContent = authsvcMsg.fido2ReadyInstructions;
    document.getElementById("loginButton").value = authsvcMsg.letsGo;

    document.querySelector("#error-section h1").textContent = authsvcMsg.errorLabel;

    document.getElementById("error_img").src = getJunctionName() + "/sps/static/design_images/u2f_error.svg";
    document.getElementById("welcome_img").src = getJunctionName() + "/sps/static/design_images/u2f_device.svg";
}

function optionsGet() {

    var url = getJunctionName() + assert_action;
    if (!url.includes("apiauthsvc")) {
        url = url.replace("authsvc", "apiauthsvc");
    }

    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {

        if (request.readyState == 4) {
            if (request.responseText) {

                var json = null;
                try {
                    json = JSON.parse(request.responseText);
                } catch (e) {
                    // we got a 200, but not valid JSON - that's an error
                    showError(authsvcMsg.badOptionsRequest);
                }

                if (json != null) {

                    if (json.stateId != null) {
                        document.getElementById("assertionForm").StateId.value = json.stateId;
                        assert_stateId = json.stateId;
                    }

                    if (json.location != null) {
                        document.getElementById("cancelForm").action = json.location.replace("apiauthsvc", "authsvc") + "&operation=cancel";
                    }

                    if (request.status == 200) {

                        assert_rpId = json.rpId;
                        assert_timeout = json.timeout;
                        assert_challenge = json.challenge;
                        assert_allowCredentials = json.allowCredentials;
                        assert_extensions = json.extensions;
                        assert_userVerification = json.userVerification;
                        assert_userId = json.userId;

                        buildOptions();

                        credentialsGet();

                    } else {
                        // Response wasn't a 200. Show error.
                        var errorMsg = authsvcMsg.badOptionsRequest;
                        if (json.error != null) {
                            errorMsg = json.error;
                        } else if (json.errorMessage != null) {
                            errorMsg = json.errorMessage;
                        } else if (json.exceptionMsg != null) {
                            errorMsg = json.exceptionMsg;
                        }
                        showError(errorMsg);
                    }

                } else {
                    // Response isn't json. Very weird. Show error.
                    showError(authsvcMsg.badOptionsRequest);
                }
            } else {
                // No response text. Very weird. Show error.
                showError(authsvcMsg.badOptionsRequest);
            }
        } else {
            // readyState is not 4, that's ok, just continue.
        }
    };

    request.open("POST", url);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");
    request.send(JSON.stringify({
        "StateId": assert_stateId
    }));

}

function buildOptions() {

    var extensions = {};
    if (assert_extensions != null && assert_extensions != "") {
        extensions = assert_extensions;
    }

    assert_publicKey = {
        "rpId": assert_rpId,
        "timeout": assert_timeout,
        "challenge": base64URLDecode(assert_challenge),
        "extensions": extensions,
        "userId": assert_userId
    };

    if (assert_userVerification != null && assert_userVerification != "") {
        assert_publicKey.userVerification = assert_userVerification;
    }

    var allowCredentials = [];
    if (assert_allowCredentials != null) {
        var allowCredentialsJson = assert_allowCredentials;
        if (allowCredentialsJson.length > 0) {
            for (i in allowCredentialsJson) {
                allowCredentialsJson[i].id = base64URLDecode(allowCredentialsJson[i].id);
                allowCredentials.push(allowCredentialsJson[i]);
            }
        }

        assert_publicKey.allowCredentials = allowCredentials;
    }
}

function credentialsGet() {
    document.getElementById("loginButton").disabled = true;
    let publicKey = assert_publicKey;

    navigator.credentials.get({
        publicKey
    }).then(function(assertion) {

        var assertionForm = document.getElementById("assertionForm");
        assertionForm.id.value = assertion.id;
        assertionForm.rawId.value = base64URLEncode(assertion.rawId);
        assertionForm.clientDataJSON.value = base64URLEncode(assertion.response.clientDataJSON);
        assertionForm.authenticatorData.value = base64URLEncode(assertion.response.authenticatorData);
        assertionForm.signature.value = base64URLEncode(assertion.response.signature);
        assertionForm.userHandle.value = base64URLEncode(assertion.response.userHandle);
        assertionForm.type.value = assertion.type;
        assertionForm.getClientExtensionResults.value = base64URLEncodeJSON(assertion.getClientExtensionResults());
        assertionForm.authenticatorAttachment.value = assertion.authenticatorAttachment;
        assertionForm.submit();
        document.getElementById("loginButton").disabled = false;

    }).catch(function(err) {
        document.getElementById("loginButton").disabled = false;
        showError(err);
    });
}

function retry() {
    document.getElementById("error-section").classList.remove('bx--dialog-content--visible');
    document.getElementById("error-section").classList.add('bx--dialog-content--hidden');
    setTimeout(function() {
        document.getElementById("error-section").style.left = '100%';
    }, 300);
    document.getElementById("assertion-section").style.left = '';
    document.getElementById("assertion-section").classList.add('bx--dialog-content--visible');
    document.getElementById("assertion-section").classList.remove('bx--dialog-content--hidden');

    if (assert_browserCheck && !assert_isSafari) {
        optionsGet();
    }
}

function showError(errMsg) {
    document.getElementById("assertion-section").classList.remove('notransition');
    document.getElementById("assertion-section").classList.remove('bx--dialog-content--visible');
    document.getElementById("assertion-section").classList.add('bx--dialog-content--hidden');
    setTimeout(function() {
        document.getElementById("assertion-section").style.left = '-100%';
    }, 300);
    document.getElementById("error-section").style.left = '';
    document.getElementById("error-section").classList.add('bx--dialog-content--visible');
    document.getElementById("error-section").classList.remove('bx--dialog-content--hidden');
    document.getElementById("errorMessage").textContent = errMsg;
}

// Safari 3.0+ "[object HTMLElementConstructor]"
var assert_isSafari = /constructor/i.test(window.HTMLElement) || (function(p) {
    return p.toString() === "[object SafariRemoteNotification]";
})(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

function startup() {
    populateStrings();

    buildOptions();

    if (assert_browserCheck && !assert_isSafari) {
        document.getElementById("loginButton").classList.add("hidden");
        optionsGet();
    }

    document.getElementById("retryButton").addEventListener("click", retry);
    document.getElementById("cancelButton").addEventListener("click", cancel);
    document.getElementById("loginButton").addEventListener("click", optionsGet);

    var styleChange = [];
    styleChange.push(document.getElementById("cancelButton"));
    styleChange.push(document.getElementById("retryButton"));

    for (var x = 0; x < styleChange.length; x++) {
        styleChange[x].style = "background-image: url('/'" + getJunctionName() + "'/sps/static/design_images/back-light.svg');";
    }

    var jsLinks = document.querySelectorAll('[href="#"]');

    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }

}