window.addEventListener("load", function() {
    document.getElementById("accept").addEventListener("click", enableSubmitButton);
    document.getElementById("notAccept").addEventListener("click", enableSubmitButton);
})

function enableSubmitButton() {
    document.getElementById('Submit').disabled = false;
}
