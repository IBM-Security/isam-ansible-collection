var junction = getJunctionName();
var baseUrl = getJunctionName() + "/sps/mga/user/mgmt";
var clientsBaseUrl = baseUrl + "/clients";
var deviceBaseUrl = baseUrl + "/device";
var grantBaseUrl = baseUrl + "/grant";
var mmfaBaseUrl = getJunctionName() + "/sps/mmfa/user/mgmt";
var authenticatorsBaseUrl = mmfaBaseUrl + "/authenticators";
var authMethodBaseUrl = mmfaBaseUrl + "/auth_methods";
var qrCodeBaseUrl = mmfaBaseUrl + "/qr_code";
var authorizeUrl = getJunctionName() + "/sps/oauth/oauth20/authorize";
var registerUrl = getJunctionName() + "/sps/oauth/oauth20/register/";
var otpBaseUrl = baseUrl + "/otp";
var knowledgeQuestionBaseUrl = baseUrl + "/questions";
var fidoBaseUrl = getJunctionName() + "/sps/fido2/";
var fidoAuthenticatorsBaseUrl = fidoBaseUrl + "registrations";
var fidoAttestationOptionsUrl = "/attestation/options";
var fidoAttestationResultUrl = "/attestation/result";
var fidoAssertionOptionsUrl = "/assertion/options";
var fidoAssertionResultUrl = "/assertion/result";
var u2fPolicyUrl = getJunctionName() + "/sps/apiauthsvc?PolicyId=urn:ibm:security:authentication:asf:u2f_register";
var shortU2fPolicyUrl = getJunctionName() + "/sps/apiauthsvc/policy/u2f_register";

function getJunctionName() {
	var jct = window.getCookie("IV_JCT");
	if (jct != null && jct != "") {
		return jct;
	} else {
    return "@JUNCTION@";
	}
}

function getCookie(cookieName) {
	var cookies = document.cookie;
	var start = cookies.indexOf(" " + cookieName + "=");
	if(start == -1) {
		start = cookies.indexOf(cookieName + "=");
	}
	if(start == -1) {
		value = "";
	} else {
		valueStart = cookies.indexOf("=", start) + 1;
		var valueEnd = cookies.indexOf(";", start);
		if(valueEnd == -1) {
			valueEnd = cookies.length;
		}
		value = unescape(cookies.substring(valueStart, valueEnd));

	}
	return value;
}

function makeAjaxRequest(method, url, callback, data) {
	var request;
	request = new XMLHttpRequest();
	request.onreadystatechange = function() {callback(request);};
	request.open(method,url,true);
	request.send(data);

	return request;
}

function makeJsonAjaxRequest(method, url, callback, data) {
	var request;
	request = new XMLHttpRequest();
	request.onreadystatechange = function() {callback(request);};
	request.open(method,url,true);
	request.setRequestHeader("Content-type", "application/json");
	request.setRequestHeader("Accept", "application/json");
	request.send(data);

	return request;
}
