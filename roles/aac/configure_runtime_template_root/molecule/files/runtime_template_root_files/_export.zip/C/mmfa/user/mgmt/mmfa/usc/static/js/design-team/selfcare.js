var deviceCards,
finishAddDeviceButton,
devicesListed,
tokensListed;

function justInTimeNotify (emphasizedSubject, predicate, sticky) {
  var notificationRibbon = document.querySelectorAll('.ibmsy-sc-intime-alert');

  for (var i = 0; i < notificationRibbon.length; i ++) {
      var notificationText = notificationRibbon[i].querySelector('p');

      if (sticky == null){
          if (!notificationRibbon[i].classList.contains("ibmsy-sc-intime-alert-top")){
              notificationText.innerHTML = '<b>' + emphasizedSubject + '</b>' + ' ' + predicate;
              notificationRibbon[i].classList.add('ibmsy-sc-intime-alert--visible');
          
              removejustInTimeNotify(notificationRibbon[i]);
          }
      }else{
          notificationText = notificationRibbon[notificationRibbon.length - 1].querySelector('p');
          notificationText.innerHTML =  emphasizedSubject + ' ' +  '<a href = "#" style="color:white" onclick="removejustInTimeNotify(null, true)"><b>' + predicate + '</b></a>';
          notificationRibbon[notificationRibbon.length - 1].classList.add('ibmsy-sc-intime-alert--visible');
      }
      
  }
}

function removejustInTimeNotify(notificationRibbon, sticky){
    if (sticky == null){
      setTimeout(function() {
        notificationRibbon.classList.remove('ibmsy-sc-intime-alert--visible');
      }, 3000);
    }else{
        var notificationRibbon = document.querySelectorAll('.ibmsy-sc-intime-alert');
          for (var i = 0; i < notificationRibbon.length; i ++) {
            notificationRibbon[i].classList.remove('ibmsy-sc-intime-alert--visible');
          }
    }
}

function checkDevicesEmpty () {
    //console.log("Checking devices...");
    if (typeof devicesListed != "undefined " && devicesListed != null){
        var anyDevices = false;
        //console.log("Checking devices...not null");
        for (var i = 0; i < devicesListed.length; i ++) {
            //console.log("Checking devices...iterating");
            var deviceLength = devicesListed[i].querySelectorAll('ul').length;

            //console.log("Checking devices...looks like we have: " + deviceLength);
            if (deviceLength >= 1) {
                devicesListed[i].classList.remove('ibmsy-sc-device-container--empty');
                $(".imbsy-add-device").attr("data-target", "verify-screen");
                anyDevices = true;

            } else {
                if (devicesListed[i].classList.contains('mobile-device-container')){
                    devicesListed[i].classList.add('ibmsy-sc-device-container--empty');
                    $(".imbsy-add-device").attr("data-target", "section-welcome");
                }
            }
        }

        if(anyDevices) {
            $(".no-devices-container")[0].classList.remove('ibmsy-all-device-containers-empty');
        } else {
            $(".no-devices-container")[0].classList.add('ibmsy-all-device-containers-empty');
        }
    }
}

function deleteDevice (deviceCard) {
  var alertDialog = deviceCard.querySelector('.ibmsy-sc-alert');
  var cancelButton = deviceCard.querySelector('.ibmsy-device-secondary');
  var deleteButton = deviceCard.querySelector('.ibmsy-device-primary');

  alertDialog.style.display = 'block';

  cancelButton.addEventListener('click', function (event) {
    alertDialog.style.display = '';
  });

  deleteButton.addEventListener('click', function (event) {

    var this_id = $(this).attr('id');
    
    if (deviceCard.classList.contains('token-device')){
        deleteU2FDevice($(deviceCard).attr('id'));
    }else if (deviceCard.classList.contains('browser-device')){
        deleteBrowserDevice(this_id);       
    }else{
        deleteAuthenticator(this_id);
    }

    var deviceName = deviceCard.querySelector('.ibmsy-device-title').innerText;

    deviceCard.parentNode.removeChild(deviceCard);

    justInTimeNotify(deviceName, 'has been deleted.');

    if ($(this).attr("operation") == "u2f"){
        devicesListed = document.querySelectorAll('.ibmsy-sc-device-container');
    }
    checkDevicesEmpty();
  });
}

function changeDeviceName (deviceCard) {
  var deviceTitle = deviceCard.querySelector('div.ibmsy-device-title');
  var deviceTitleInput = deviceCard.querySelector('input.ibmsy-device-title');

  deviceTitle.style.display = 'none';
  deviceTitleInput.value = '';
  deviceTitleInput.setAttribute('placeholder', deviceTitle.innerText);
  deviceTitleInput.classList.remove("hidden");
  deviceTitleInput.focus();

  deviceTitleInput.addEventListener('keyup', changeDeviceNameKeyListener);
  deviceTitleInput.addEventListener('blur', changeDeviceNameBlurListener);
}

function changeDeviceNameKeyListener(event) {
    deviceCard = this.parentNode.parentNode;
    deviceTitle = deviceCard.querySelector('div.ibmsy-device-title');

    if (event.keyCode === 13) {
        if (this.value !== '') {
            deviceTitle.innerText = this.value;
            if (deviceCard.classList.contains('token-device')){
                changeU2FDeviceName($(deviceCard).attr('id'), this.value);
            }
            justInTimeNotify('', 'Device name successfully changed.')
        }
        deviceTitle.style.display = '';
        this.classList.add("hidden");
        this.removeEventListener('keyup', changeDeviceNameKeyListener);
        this.removeEventListener('blur', changeDeviceNameBlurListener);
    }

    if (event.keyCode === 27) {
        deviceTitle.style.display = '';
        this.classList.add("hidden");
        this.value = '';
        this.removeEventListener('keyup', changeDeviceNameKeyListener);
        this.removeEventListener('blur', changeDeviceNameBlurListener);
    }
}

function changeDeviceNameBlurListener(event) {
    deviceCard = this.parentNode.parentNode;
    deviceTitle = deviceCard.querySelector('div.ibmsy-device-title');

    if (this.value !== '') {
        deviceTitle.innerText = this.value;
        if (deviceCard.classList.contains('token-device')){
            changeU2FDeviceName($(deviceCard).attr('id'), this.value);
        }
        justInTimeNotify('', 'Device name successfully changed.')
    }
    deviceTitle.style.display = '';
    this.classList.add("hidden");

    this.removeEventListener('blur', changeDeviceNameBlurListener);
    this.removeEventListener('keyup', changeDeviceNameKeyListener);
}

function toggleDeviceActive(deviceCard) {

    if (deviceCard.classList.contains('device-deactivated')) {

        if (deviceCard.classList.contains('token-device')){
            deviceCard.querySelector('[data-function="changeDeviceName"]').style.display = "block";
        }

        var this_id = $(deviceCard.querySelector('[data-function="toggleDeviceActive"]')).attr('id');

        if (deviceCard.classList.contains('token-device')) {
            activateU2FDevice($(deviceCard).attr('id'));
        } else {
            activateDevice($(deviceCard).attr('id'), this_id);
        }

        deviceCard.querySelector('.ibmsy-device-lastUsed').textContent = i18nMsg.enabled;

        deviceCard.classList.remove('device-deactivated');
        deviceCard.querySelector('[data-function="toggleDeviceActive"]').textContent = i18nMsg.disableDevice;

    } else if(deviceCard.classList.contains('device-activated') || !deviceCard.classList.contains('device-activated')) {
        deviceCard.classList.add('device-deactivated');
        deviceCard.querySelector('[data-function="toggleDeviceActive"]').textContent = i18nMsg.enableDevice;

        if (deviceCard.classList.contains('token-device')){
          deviceCard.querySelector('[data-function="changeDeviceName"]').style.display = "none";
        }

        deviceCard.querySelector('.ibmsy-device-lastUsed').textContent = i18nMsg.disabled;
    
        var this_id = $(deviceCard.querySelector('[data-function="toggleDeviceActive"]')).attr('id');
        if (deviceCard.classList.contains('browser-device')){
            deactivateBrowserDevice($(deviceCard).attr('id'), this_id); 
        }else if (deviceCard.classList.contains('token-device')){
            deactivateU2FDevice($(deviceCard).attr('id'));
        }else{
            deactivateDevice($(deviceCard).attr('id'), this_id);
        }

    }
}

function addMenuEventListener (menuItem) {
  menuItem.addEventListener('click', function (event) {
    var parentCard = menuItem.parentNode.parentNode.parentNode;
    menuItem.parentNode.style.display = '';
    window[menuItem.getAttribute('data-function')](parentCard);
  });
}

function cardCompareFunction (a, b) {
  var aDateString = a.querySelector('.ibmsy-device-lastUsed').innerText;
  var bDateString = b.querySelector('.ibmsy-device-lastUsed').innerText;

  var unitVals = {
    'hour': 1,
    'day': 2,
    'week': 3,
    'month': 4,
    'year': 5
  }

  var aUnit = aDateString.substring(aDateString.indexOf(' ', 10) + 1);
  aUnit = aUnit.substring(0, aUnit.indexOf(' '));
  if (aUnit.indexOf('s') > 0) { aUnit = aUnit.substring(0, aUnit.indexOf('s')); }

  var bUnit = bDateString.substring(bDateString.indexOf(' ', 10) + 1);
  bUnit = bUnit.substring(0, bUnit.indexOf(' '));
  if (bUnit.indexOf('s') > 0) { bUnit = bUnit.substring(0, bUnit.indexOf('s')); }

  if (unitVals[aUnit] - unitVals[bUnit] === 0) {
    aVal = (aDateString.substring(10, aDateString.indexOf(aUnit) - 1));
    bVal = (bDateString.substring(10, bDateString.indexOf(aUnit) - 1));
    return aVal - bVal;
  }

  return unitVals[aUnit] - unitVals[bUnit];

}

function sortDevices () {
  var activeDevices = [];
  var inactiveDevices = [];
  var cardList = document.querySelector('.ibmsy-sc-device-container');

  for (var i = 0; i < deviceCards.length; i ++) {
    var deviceCard = deviceCards[i];
  // for (var deviceCard of deviceCards) {
    if (deviceCard.classList.contains('device-deactivated')) {
      inactiveDevices.push(deviceCard);
    } else {
      activeDevices.push(deviceCard);
    }
  }

  activeDevices.sort(cardCompareFunction);
  inactiveDevices.sort(cardCompareFunction);

  for (var i = 0; i < activeDevices.length; i ++) {
    cardList.appendChild(activeDevices[i]);
  }
  for (var i = 0; i < inactiveDevices.length; i ++) {
    cardList.appendChild(inactiveDevices[i]);
  }
}

function addDevice () {

  var deviceCards = document.querySelectorAll('.ibmsy-sc-device');
  Array.prototype.forEach.call(deviceCards, function (thisCard) {
        var cardMenuButton = thisCard.querySelector('.ibmsy-more-menu');
        var cardMenu = thisCard.querySelector('.ibmsy-dropdown-list');
        var cardmenuItems = thisCard.querySelectorAll('.ibmsy-dropdown-list > li')

        cardMenuButton.addEventListener('click', function (event) {
          event.preventDefault();
          for (var i = 0; i < document.querySelectorAll('.ibmsy-dropdown-list').length; i ++) {
          document.querySelectorAll('.ibmsy-dropdown-list')[i].style.display = '';
          }

          cardMenu.style.display = 'block';
        });

        for (var i = 0; i < cardmenuItems.length; i ++) {
          addMenuEventListener(cardmenuItems[i]);
        }
      });
}

function finishAddDevice (deviceName) {
    ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, updateHTML);
  var welcomeSection = document.querySelector('[data-name="section-welcome-authenticators"]');
  var parent = welcomeSection.parentNode;
  parent.insertBefore(welcomeSection, parent.querySelector('[data-name="section-complete-modal"]'));
  welcomeSection.style.transition = 'all 0s linear';
  welcomeSection.classList.remove('ibmsy-modal-content--hidden');
  welcomeSection.style.left = '';
  document.querySelector('.ibmsy-footer-nav').setAttribute('data-name', 'selfcare');
  addDevice();

  welcomeSection.style.transition = '';

  setTimeout(function () {
    showContentSection('section-welcome-authenticators');
  }, 10);

  modalBackButton = document.querySelector('.ibmsy-modal-back');
  modalBackButton.style.display = 'none';

  setTimeout(function() {
    parent.insertBefore(welcomeSection, parent.querySelector('.ibmsy-footer-nav'));
    justInTimeNotify(deviceName, 'can now be used for verification!');

    var sections = document.querySelectorAll('.ibmsy-modal-content--hidden');
    for (var i = 0; i < sections.length; i ++) {
      var section = sections[i];
      section.classList.remove('ibmsy-modal-content--hidden');
      section.style.left = '';
      var illustration = section.querySelector('.ibmsy-example-animation');
      if (illustration) {
        illustration.classList.remove('ibmsy-example-animation--hidden');
      }
    }

    for (var i = 0; i < document.querySelectorAll('.success-check').length; i ++) {
      document.querySelectorAll('.success-check')[i].style.display = '';
    }

    contentSectionHistory = [];
  }, 200);

  setTimeout(function () {
    document.querySelector('[data-name="section-complete-modal"]').style.left = '';
  }, 500);
}

window.addEventListener("load", function () {
  deviceCards = document.querySelectorAll('.ibmsy-sc-device');
  finishAddDeviceButton = document.querySelector('.ibmsy-finish-enrollment');
  devicesListed = document.querySelectorAll('.ibmsy-sc-device-container');

  document.querySelector('.imbsy-add-device').addEventListener('click', function (event) {
    document.querySelector('.ibmsy-footer-nav').setAttribute('data-name', '');
  });

  document.addEventListener('click', function (event) {
    if (!event.target.classList.contains('ibmsy-more-menu')) {
      var cardMenus = document.querySelectorAll('.ibmsy-dropdown-list');
      for (var i = 0; i < cardMenus.length; i ++) {
        cardMenus[i].style.display = '';
      }
    }
  });

  if (typeof finishAddDeviceButton != "undefined" && finishAddDeviceButton != null){
      finishAddDeviceButton.addEventListener('click', function () {
        finishAddDevice("Original");
      });
  };

  Array.prototype.forEach.call(deviceCards, function (thisCard) {
    var cardMenuButton = thisCard.querySelector('.ibmsy-more-menu');
    var cardMenu = thisCard.querySelector('.ibmsy-dropdown-list');
    var cardmenuItems = thisCard.querySelectorAll('.ibmsy-dropdown-list > li')

    cardMenuButton.addEventListener('click', function (event) {
      event.preventDefault();
      for (var i = 0; i < document.querySelectorAll('.ibmsy-dropdown-list').length; i ++) {
      document.querySelectorAll('.ibmsy-dropdown-list')[i].style.display = '';
      }

      cardMenu.style.display = 'block';
    });

    for (var i = 0; i < cardmenuItems.length; i ++) {
      addMenuEventListener(cardmenuItems[i]);
    }
  });

  checkDevicesEmpty();
  sortDevices();
});
