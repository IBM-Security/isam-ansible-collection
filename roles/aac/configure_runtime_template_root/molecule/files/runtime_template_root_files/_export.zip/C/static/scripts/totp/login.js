window.addEventListener("load", startup);

var totpl_errorStr = document.currentScript.dataset.errorTag;

function displayError() {
    var errorDiv = document.getElementById("errorDiv");

    if (totpl_errorStr != "") {
        errorDiv.innerHTML = "<p><b>" + ciMsg.errorLabel + " - </b>" + totpl_errorStr + "</p>";
        errorDiv.className = "errorMessage visible";
    }
}

function validateOtp(button) {
    var container = button.parentNode.parentNode;
    var otpInput = container.querySelector('#otp');
    var otp = otpInput.value;

    if (checkValid(otpInput, "otp")) {
        document.querySelector(".bx--loader").classList.remove('hidden');
        document.querySelector(".bx--welcome-illustrations .bx--launch-animation").classList.add('hidden');
        document.getElementById("validateForm").otp.value = otp;
        document.getElementById("validateForm").submit();
    }
}

function showValidation() {
    document.getElementById("connect-section").classList.remove('bx--dialog-content--visible');
    document.getElementById("connect-section").classList.add('bx--dialog-content--hidden');
    setTimeout(function() {
        document.getElementById("connect-section").style.left = '-100%';
    }, 300);
    document.getElementById("validation-section").style.left = '';
    document.getElementById("validation-section").classList.add('bx--dialog-content--visible');

    setTimeout(function() {
        document.getElementById("otp").focus();
    }, 300);
}

function checkValid(input) {
    var valid = false;
    var value = input.value;
    if (value != null && value != "" && input.validity.valid) {
        valid = true;
    }
    if (valid) {
        if (input.classList.contains('input-invalid')) {
            input.classList.remove('input-invalid');
        }
    } else {
        input.classList.add('input-invalid');
    }
    document.getElementById("validate-button").disabled = !valid;

    return valid;
}

function populateStrings() {
    document.title = ciMsg.totpLogin;
    document.querySelector('#validation-section h3').textContent = ciMsg.twoStepVeri;
    document.querySelector('#validation-section h1').textContent = ciMsg.totpLogin;
    document.getElementById("instructions").textContent = ciMsg.totpVerificationInstructions;
    document.querySelectorAll("#validation-section p")[2].textContent = ciMsg.accessCode;
    document.getElementById("otp").placeholder = ciMsg.enterCode;
    document.querySelector("#validation-section .button-bottom").textContent = ciMsg.validate;
}

function startup() {
    populateStrings();

    displayError();

    var input = document.querySelector('#otp');
    input.addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13, space is 32
        if (event.keyCode === 13 || event.keyCode == 32) {
            document.querySelector('#validate-button').click();
        }
    });

    document.getElementById("otp").addEventListener('input', function() {
        checkValid(this)
    });
    document.getElementById("validate-button").addEventListener('click', function() {
        validateOtp(this)
    });
}
