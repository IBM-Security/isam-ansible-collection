
function deleteAuthenticator(authenticatorId) {
	makeAjaxRequestJSON("DELETE", authenticatorsBaseUrl + "/" + authenticatorId, processDeleteRequest, null);
	ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, updateHTML);
}

function processDeleteRequest(deleteRequest) {
	if (deleteRequest.readyState == 4 && (deleteRequest.status == 200 || deleteRequest.status == 204)) {
		if (deleteRequest.responseText == "Not found") {} else {
			ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, updateHTML);
		}
	}
}

function getDeviceState(deviceId, grantId) {
	getRequest = makeAjaxRequestJSON("GET", junction + "/sps/mga/user/mgmt/grant", function(getRequest) {
		if (getRequest.readyState == 4) {
			if (getRequest.status == 200) {
				//console.log(getRequest);
				var msg = JSON.parse(getRequest.response);
				grants = msg["grants"];
				var no_disabled = 0;
				$.each(grants, function(i, grant) {
					var enabled = grant["isEnabled"];
					if (grant["id"] == grantId) {
						if (!enabled) {
							no_disabled += 1;
							if ($(".ibmsy-sc-device#" + deviceId).hasClass("device-activated") || !$(".ibmsy-sc-device#" + deviceId).hasClass("device-deactivated")) {
								var deviceCard = $(".ibmsy-sc-device#" + deviceId);
								deviceCard.removeClass("device-activated");
								deviceCard.addClass("device-deactivated");
								deviceCard.get(0).querySelector('[data-function="toggleDeviceActive"]').innerText = 'Activate this device';
								deviceCard.get(0).querySelector('[data-function="changeDeviceName"]').remove();
							} else {
								//console.log("Already disabled");
							}
						} else if (enabled) {
							if ($(".ibmsy-sc-device#" + deviceId).hasClass("device-deactivated")) {
								var deviceCard = $(".ibmsy-sc-device#" + deviceId);
								deviceCard.removeClass("device-deactivated");
								deviceCard.addClass("device-activated");
								var changeName = document.createElement('li');
								changeName.innerText = 'Change Device name';
								changeName.setAttribute('data-function', 'changeDeviceName');
								var setPrimary = document.createElement('li');
								setPrimary.innerText = 'Set as default device';
								deviceCard.get(0).querySelector('[data-function="toggleDeviceActive"]').innerText = 'Deactivate this device';
								deviceCard.get(0).querySelector('ul').insertBefore(changeName, deviceCard.get(0).querySelector('[data-function="toggleDeviceActive"]'));
							} else if ($(".ibmsy-sc-device#" + deviceId).hasClass("device-activated")) {
								//console.log("already activated");
							}
						}
					}
				});
				$("#authenticators-disabled").text(no_disabled);
			}
		}
	}, null);
	return getRequest;
}

function deactivateDevice(deviceId, grantId) {
	var grant_body = "{\"isEnabled\":false}";
	getRequest = makeAjaxRequestJSON("PUT", junction + "/sps/mga/user/mgmt/grant/" + grantId, function() {
		if (getRequest.readyState == 4) {
			if (getRequest.status == 200) {
//				 getDeviceState(deviceId, grantId);

				  ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, deactivateCallback);
			}
		}
	}, grant_body);
	return getRequest;
}

function activateDevice(deviceId, grantId) {
	var grant_body = "{\"isEnabled\":true}";
	getRequest = makeAjaxRequestJSON("PUT", junction + "/sps/mga/user/mgmt/grant/" + grantId, function() {
		if (getRequest.readyState == 4) {
			if (getRequest.status == 200) {
//				 getDeviceState(deviceId, grantId);

				  ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, deactivateCallback);
			}
		}
	}, grant_body);
	return getRequest;
}

function deactivateCallback(scimRequest){
	  //displayAuthenticatorSummary(authenticators, authMethods);
}


function abortTransaction(uuid, rowNode) {
	//console.log("aborting transaction");
	var scim_body = "" + "{" + "\"schemas\":" + "[\"urn:ietf:params:scim:api:messages:2.0:PatchOp\"]," + "\"Operations\":[{" + "\"op\":\"add\"," + "\"path\":\"urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Transaction:transactionsPending[transactionId eq " + uuid + "].txnStatus\"," + "\"value\": \"ABORT\"" + "}]" + "}";
	request = makeAjaxRequestJSON("PATCH", "/scim/Me?excludedAttributes=urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Transaction:transactionsResolved,urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Transaction:attributesResolved,urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Transaction:attributesPending,urn:ietf:params:scim:schemas:extension:isam:1.0:MMFA:Transaction:transactionsPending", function(patchRequest) {
		if (patchRequest.readyState == 4) {
			if (patchRequest.status == 200) {
				if (patchRequest.responseText){
					patchRequest.readyState = null;
					//console.log(patchRequest);
					setTimeout(function(){
						if (rowNode == null){
							ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, updateHTML);
						}else{
							pending_transactions_table.row(rowNode).remove().draw();
							return;
						}
					}
					,500);
				}
			}
		}
	}, scim_body);
	return request;
}


function displayAuthenticators(authenticators, authMethods, elements) {
	var number_disabled = 0;
	
	if (authenticators.length > 0) {
		//Remove all the authenticators from the contains, and if it exists - the container
		$(".ibmsy-sc-device-container").children().remove();
		
		$.each(authenticators, function(i, authenticator) {
			
			//Check for enabled
			var enabled_text = i18nMsg.enabled;
			var toggle_text = i18nMsg.disableDevice;
			var class_text = "device-activated";
			if (authenticator.enabled == false) {
				enabled_text = i18nMsg.disabled;
				toggle_text = i18nMsg.enableDevice;
				number_disabled += 1;
				class_text = "device-deactivated"
			}
		
			//Add the device
			var authenticator_device = '\
			<div class="ibmsy-sc-device '+class_text+'" id = "' + authenticator.id + '"> \
				<div class="ibmsy-sc-more-dropdown"> \
					<button class="ibmsy-more-menu" id = "' + authenticator.id + '"> \
					</button> \
					<ul class="ibmsy-dropdown-list"> \
						<li data-function="changeDeviceName" style="display:none">'+i18nMsg.editDeviceName+'</li>\
						<li id = "' + authenticator.oauthGrant + '" data-function="toggleDeviceActive">' + toggle_text + '</li>\
						<li id = "' + authenticator.id + '" data-function="deleteDevice">'+i18nMsg.deleteDevice+'</li>\
					</ul> \
				</div> \
				<div class="ibmsy-sc-device-illustration"> \
					<img src="/sps/mmfa/user/mgmt/html/mmfa/usc/static/img/design-team/Phone-1_Illustraion.svg" alt="illustration" /> \
				</div> \
				<div class="ibmsy-sc-device-info"> \
					<div class="ibmsy-device-title">' + decode_utf8(authenticator.deviceName) + '</div> \
					<input type="text" class="ibmsy-device-title hidden" placeholder="' + decode_utf8(authenticator.deviceName) + '">\
					<div class="ibmsy-device-type">' + authenticator.deviceType + ' (' + authenticator.osVersion + ')</div> \
					<div class="ibmsy-device-lastUsed">' + enabled_text + '</div> \
				</div>\
				\
				<div class="ibmsy-sc-alert">\
					<div class="alert-title">\
						<h3 class="ibmsy-h3">'+i18nMsg.areYouSure+'</h3>\
					</div>\
					<p class="type-body-s">'+i18nMsg.deleteDeviceWarnMg+'\
					</p>\
					<div class="alert-actions">\
						<button id = "' + authenticator.id + '" class="ibmsy-device-secondary cancel" alt="Cancel">'+i18nMsg.cancel+'</button>\
						<button id = "' + authenticator.id + '" class="ibmsy-device-primary delete" alt="Yes, Delete">'+i18nMsg.deleteConfrmation+'</button>\
					</div>\
				</div>\
			</div>';
			
			$(".ibmsy-sc-device-container").append(authenticator_device);
			
		});			
		
		if (typeof checkDevicesEmpty != "undefined") {
			checkDevicesEmpty();
		}
		
		if (typeof addDevice != "undefined") {
			addDevice();
		}
		
		if (elements != null){
			setTimeout(function(){displayElements("full", elements[0], elements[1], elements[2]);},200);
		}
		
	} else {

		checkDevicesEmpty();
		if (elements != null){
			setTimeout(function(){
				//console.log("selfcare empty");
				displayElements("empty", elements[0], elements[1], elements[2]);},200);
		}
		
	}

}

function getJunctionName() {
	var jct = window.getCookie("IV_JCT");
	if (jct != null && jct != "") {
		return jct;
	} else {
    return "@JUNCTION@";
	}
}

function deactivateU2FDevice(deviceId) {
	makeJsonAjaxRequest("GET", u2fPolicyUrl, function(policyGetRequest) {
		if (policyGetRequest.readyState == 4 && policyGetRequest.status == 200) {
			if (policyGetRequest.responseText == "Not found") {
			} else {
				parseGetU2FTokensRequest(policyGetRequest);

				var req_json = {};
				req_json.action = "update";
				req_json.id = deviceId;
				req_json.enabled = false;

				makeAjaxRequestJSON("PUT", getJunctionName() + "/sps/apiauthsvc?PolicyId=urn:ibm:security:authentication:asf:u2f_register", function(policyPutRequest) {
					if (policyPutRequest.readyState == 4) {
						if (policyPutRequest.status == 204) {
							ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, null);
						}
					}
				}, JSON.stringify(req_json));
			}
		}
	}, null);
}

function activateU2FDevice(deviceId) {
	makeJsonAjaxRequest("GET", u2fPolicyUrl, function(policyGetRequest) {
		if (policyGetRequest.readyState == 4 && policyGetRequest.status == 200) {
			if (policyGetRequest.responseText == "Not found") {
			} else {
				parseGetU2FTokensRequest(policyGetRequest);

				var req_json = {};
				req_json.action = "update";
				req_json.id = deviceId;
				req_json.enabled = true;

				makeAjaxRequestJSON("PUT", getJunctionName() + "/sps/apiauthsvc?PolicyId=urn:ibm:security:authentication:asf:u2f_register", function(policyPutRequest) {
					if (policyPutRequest.readyState == 4) {
						if (policyPutRequest.status == 204) {
							ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, null);
						}
					}
				}, JSON.stringify(req_json));
			}
		}
	}, null);
}
	
function deleteU2FDevice(deviceId) {
	makeJsonAjaxRequest("GET", u2fPolicyUrl, function(policyGetRequest) {
		if (policyGetRequest.readyState == 4 && policyGetRequest.status == 200) {
			if (policyGetRequest.responseText == "Not found") {
			} else {
				parseGetU2FTokensRequest(policyGetRequest);

				var req_json = {};
				req_json.action = "unregister";
				req_json.id = deviceId;

				makeAjaxRequestJSON("PUT", getJunctionName() + "/sps/apiauthsvc?PolicyId=urn:ibm:security:authentication:asf:u2f_register", function(policyPutRequest) {
					if (policyPutRequest.readyState == 4) {
						if (policyPutRequest.status == 204) {
							ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, null);
							getU2FTokens(); 
						}
					}
				}, JSON.stringify(req_json));
			}
		}
	}, null);
}

function changeU2FDeviceName(deviceId, newDeviceTitle){

	makeJsonAjaxRequest("GET", u2fPolicyUrl, function(policyGetRequest) {

		if (policyGetRequest.readyState == 4 && policyGetRequest.status == 200) {
			parseGetU2FTokensRequest(policyGetRequest);

			var req_json = {};
			req_json.action = "update";
			req_json.id = deviceId;
			req_json.name = newDeviceTitle;

			makeAjaxRequestJSON("PUT", getJunctionName() + "/sps/apiauthsvc?PolicyId=urn:ibm:security:authentication:asf:u2f_register", function(policyPutRequest) {

				if (policyPutRequest.readyState == 4) {
					if (policyPutRequest.status == 204) {
						ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, null);
					}
				}
			}, JSON.stringify(req_json));
		}
	}, null);
}

$( document ).ready(function() {
	$('div[id^="transaction-receipt-"] img').click(function(event) {
		$(this).get(0).src = getJunctionName() + "/sps/static/loader_light.gif";
		loadReceipt($(this).get(0).id, 0, 500);
	});
	
	$('div[id^="transaction-delete-"] img').click(function(event) {
		$(this).get(0).src = getJunctionName() + "/sps/static/loader_light.gif";
		abortTransaction($(this).get(0).id);
	});

});
