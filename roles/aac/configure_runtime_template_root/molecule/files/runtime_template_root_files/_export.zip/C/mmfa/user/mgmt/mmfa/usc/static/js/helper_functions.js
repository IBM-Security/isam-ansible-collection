//Bizarrely this is needed for the Recaptcha load on demand feature
var onloadCallback = function() {};

function resubmitRecaptcha() {
	grecaptcha.reset();
}

function easingTimeout(delay, fn) {
	var id,
		invoker = function() {
			fn();
			delay = Math.floor(delay + (10 * 2));
			delay_global = delay;
			if (delay) {
				id = setTimeout(invoker, delay);
			} else {
				id = null;
			}
		}
		// start it off
	id = setTimeout(invoker, delay);
	return {
		clear: function() {
			if (id) {
				clearTimeout(id);
				id = null;
			}
		}
	}
}

function getQueryParamString(url, paramName) {
	if (paramName != null && paramName.length > 0) {
		var queryString = url;
		var params = queryString.split("&");
		for (var i = 0; i < params.length; i++) {
			var keyValue = params[i].split("=");
			if (keyValue[0] == paramName) {
				return keyValue[1];
			}
		}
	}
	return null;
}

function buildQueryParam(param, value, first) {
	var clientParam = "";
	if (value != null && value.length > 0) {
		if (first == true) {
			clientParam = "?" + param + "=" + value;
		} else {
			clientParam = "&" + param + "=" + value;
		}
	}
	return clientParam;
}

function checkIfIE() {
	var ie = false;
	var ua = window.navigator.userAgent;
	var old_ie = ua.indexOf('MSIE ');
	var new_ie = ua.indexOf('Trident/');
	if ((old_ie > -1) || (new_ie > -1)) {
		ie = true;
	}
	return ie;
}

function makeAjaxRequestJSON(method, url, callback, data) {
	var request;
	request = new XMLHttpRequest();
	request.onreadystatechange = function() {
		callback(request);
	};
	request.open(method, url, true);
	request.setRequestHeader("Accept", "application/json");
	request.setRequestHeader("Content-Type", "application/json");
	request.send(data);
	return request;
}

function guid() {
	function s4() {
		return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
	}
	return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}

function get_wss_location(){
	var loc = window.location,
	web_socket_uri;
	if (loc.protocol === "https:") {
		web_socket_uri = "wss:";
	} else {
		web_socket_uri = "ws:";
	}
	web_socket_uri += "//" + loc.host;
	web_socket_uri += "/mga/websock/mmfa-wss/";
	return web_socket_uri;
}

function decode_utf8(s) {
	return decodeURIComponent(escape(s));
}
$.fn.wrapInTag = function(opts) {
	var tag = opts.tag || 'strong',
		words = opts.words || [],
		regex = RegExp(words.join('|'), 'gi') // case insensitive
		,
		replacement = '<' + tag + '>$&</' + tag + '>';
	return this.html(function() {
		return $(this).text().replace(regex, replacement);
	});
};

function isValidEmailAddress(emailAddress) {
	var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
	return pattern.test(emailAddress);
};

function isValidNumber(transferamount) {
	return !isNaN($.isNumeric(transferamount));
};

function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function capitalize(string) {
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

function displayPageAlert(type){
	deleteDeviceCover = document.querySelector('.ibmsy-alert-cover');
	deleteDeviceCover.style.display = 'inherit';
	deleteDeviceDialog = document.querySelector('.ibmsy-alert-modal-box');
	deleteDeviceDialog.style.display = 'inherit';
	
	if (type == "none"){	
		deleteDeviceDialog.childNodes[1].childNodes[1].textContent = "No Registered Device";
		deleteDeviceDialog.childNodes[3].childNodes[0].textContent = "Please register a device before trying this transaction.";
	}else if (type == "disabled"){	
		deleteDeviceDialog.childNodes[1].childNodes[1].textContent = "No Enabled Device";
		deleteDeviceDialog.childNodes[3].childNodes[0].textContent = "Please re-activate your device before trying this transaction.";
	}else if (type == "no-user-presence"){
		deleteDeviceDialog.childNodes[1].childNodes[1].textContent = "Unable to Complete Transaction";
		deleteDeviceDialog.childNodes[3].childNodes[0].textContent = "Sorry, your device doesn't support User Presence, which is required to approve this transaction.";
	}else if (type == "no-touch"){	
		deleteDeviceDialog.childNodes[1].childNodes[1].textContent = "Unable to Complete Transaction";
		deleteDeviceDialog.childNodes[3].childNodes[0].textContent = "Sorry, your device doesn't support Touch ID, which is required to approve this transaction.";
	}
}

function dateToString (date) {
	  // Use an array to format the month numbers
	  var months = [
	    "January",
	    "February",
	    "March",
	     "April","May","June","July","August","September", "October","November","December"
	  ];

	  // Use an object to format the timezone identifiers
	  var timeZones = {
	    "360": "EST"
	  };

	  var month = months[date.getMonth()];
	  var day = date.getDate();
	  var year = date.getFullYear();

	  var hours = date.getHours();
	  var minutes = date.getMinutes();
	  var time = (hours > 11 ? (hours - 11) : (hours + 1)) + ":" + ('0' + minutes).slice(-2) + " " +(hours > 11 ? "PM" : "AM");
//	  var time = (hours > 11 ? (hours - 11) : (hours + 1)) + ":" + ('0' + minutes).slice(-2);
	  var timezone = timeZones[date.getTimezoneOffset()];

	  // Returns formatted date as string (e.g. January 28, 2011 - 7:30PM EST)
//	  return month + " " + day + ", " + year + " at " + time ;
//	  return day + ", " + month + ", " + year + ", " + time ;
	  return month + " " + day + ", " + year + ", " + time ;
}


function removeTableRow(table, row){
	if (table != null && row != null){
		table.row(row).remove().draw();
		var resent_spinner = $('td[id^="transaction-delete-"] #cancel');
		if (resent_spinner != "undefined" && resent_spinner != null && resent_spinner != []){
			var img = $(resent_spinner).children("div");
			$(img).removeClass("hidden");
			var img = $(resent_spinner).children("img");
			$(img).addClass("hidden");
		}
	}
}

function confirmation_succeed(){
	if (document.querySelector('[data-name="section-confirmation"]')) {
		if($("#from-account option:selected").text() != "" && $("#to-account option:selected").text() != ""){
			$('.ibmsy-request-message .ibmsy-confirmation-message').text($("#from-account option:selected").text() + " to " + $("#to-account option:selected").text());
		}
		showContentSection('section-confirmation');
	}
}

function confirmation_fail(reason){
	if (document.querySelector('[data-name="section-confirmationfailed"]')) {
		if($("#from-account option:selected").text() != "" && $("#to-account option:selected").text() != ""){
			if (reason != null){
				switch(reason){
				case "none":
					$('.ibmsy-request-message .ibmsy-confirmation-message').text("You don't have a registered device.");
					break;
				case "no-touch":
					$('.ibmsy-request-message .ibmsy-confirmation-message').text("The device doesn't have fingerprint authentication enabled.");
					break;
				case "no-user-presence":
					$('.ibmsy-request-message .ibmsy-confirmation-message').text("The device doesn't have user presence authentication enabled.");
					break;
				case "disabled":
					$('.ibmsy-request-message .ibmsy-confirmation-message').text("The device is disabled.");	
					break;
				default:
					$('.ibmsy-request-message .ibmsy-confirmation-message').text($("#from-account option:selected").text() + " to " + $("#to-account option:selected").text());
					break;
				}
			}else{
				$('.ibmsy-request-message .ibmsy-confirmation-message').text($("#from-account option:selected").text() + " to " + $("#to-account option:selected").text());
			}
		}
		showContentSection('section-confirmationfailed');
	}
}

function clearAllIntervals(){

	trace("Clearing all intervals");
	
	if (typeof socket_interval != "undefined" && socket_interval != null) {
		clearInterval(socket_interval);
	}
	if (typeof authsvc_interval != "undefined" && authsvc_interval != null) {
		clearInterval(authsvc_interval);
	}
	
}


//----------

function trace(message, level) {
	var prefix = "MFA DEMOSITE";
	
	switch (level) {
		case "fine":
		case "info":
		case "warning":
		case "error":
			break;
		default:
			level = "info";
			break;
	}
	var caller = arguments.callee.caller.name;
	if (caller == null) {
		caller = "Direct Invocation";
	}
	if (message != null && message != "undefined") {
		//console.log("[" + level.toUpperCase() + "] " + prefix + " | " + caller + " | " + message)
	} else {
		//console.log("[" + level.toUpperCase() + "] " + prefix + " | " + caller + " | Tracepoint - No Message")
	}
}