window.addEventListener("load", startup);

var rsasid_errorMessage = document.currentScript.dataset.errorMessage;

function displayError() {
    if (rsasid_errorMessage != "") {
        var errorMsg = document.getElementById("errorMessage");
        errorMsg.textContent = errorMsg.textContent + rsasid_errorMessage;

        var errorDiv = document.getElementById("errorDiv");
        errorDiv.className = "errorMessage visible";
    }
}

function startup() {
    displayError();
}
