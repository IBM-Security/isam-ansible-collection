window.addEventListener("load", windowStart);

var mmfalw_dataSetValues = document.currentScript.dataset;

var mmfalw_locationHostPort = location.hostname + (location.port ? ':' + location.port : '');
var mmfalw_baseURL = location.protocol + '//' + mmfalw_locationHostPort;
var mmfalw_baseWebSocketURL = 'wss://' + mmfalw_locationHostPort;
var mmfalw_jct = getJunctionName();
var mmfalw_formAction = mmfalw_jct + mmfalw_dataSetValues.action.replace(/&operation=[a-z]*/, ''); // remove operation from initial action because we manage that separately now
var mmfalw_manualOperation = null; // will be null, unless the user presses one of the buttons
var mmfalw_ajaxTimer = null; // points to the result of setTimeout, so that a pending poll can be canceled
var mmfalw_ajaxActive = false; // is an ajax operation to the apiauthsvc currently active
var mmfalw_pollTime = 2000;
var mmfalw_transactionStatus = mmfalw_dataSetValues.mmfaTransactionStatus;
var mmfalw_errorTitle = "";
var mmfalw_errorStr = mmfalw_dataSetValues.errorMessage;
var mmfalw_txnIdAttrTxt = mmfalw_dataSetValues.mmfaTransactionId;
var mmfalw_ctxMsgAttrTxt = mmfalw_dataSetValues.mmfaContextMessage;
var mmfalw_returnEnabled = mmfalw_dataSetValues.returnEnabled;
var mmfalw_totpEnrolled = mmfalw_dataSetValues.totpEnrolled;

function displayError() {
    var errorTile = document.getElementById('errorTile');
    if (mmfalw_errorStr != "") {
        document.getElementById("transactionTile").classList.add("hidden");
        errorTile.classList.remove("hidden");
        document.getElementById('errorDetail').textContent = mmfalw_errorStr;
        if (mmfalw_errorTitle != "") {
            document.getElementById('errorTitle').textContent = mmfalw_errorTitle;
        }
    } else {
        errorTile.classList.add("hidden");
    }
}

function displayContextAttrs() {

    if (mmfalw_txnIdAttrTxt != "") {
        var txnIdAttrSpan = document.getElementById('mmfa_transaction_id');
        txnIdAttrSpan.textContent = mmfalw_txnIdAttrTxt;
    }

    if (mmfalw_ctxMsgAttrTxt != "") {
        var ctxMsgAttrSpan = document.getElementById('mmfa_context_message');
        ctxMsgAttrSpan.textContent = mmfalw_ctxMsgAttrTxt;
    }
}

function displayStatus() {
    var statusDiv = document.getElementById('statusDiv');
    var statusSpan = document.getElementById('statusSpan');
    if (mmfalw_transactionStatus != "") {
        statusSpan.textContent = mmfalw_transactionStatus;
        statusDiv.classList.remove("hidden");
    } else {
        statusDiv.classList.add("hidden");
    }
}

function hideOperations() {
    var operationsDiv = document.getElementById('operationsDiv');
    operationsDiv.classList.add("hidden");
    document.querySelector('.sectionTitle').classList.add("hidden");
}

function disableOperationButtons() {
    document.getElementById("verifyButton").disabled = true;
    document.getElementById("cancelButton").disabled = true;
    document.getElementById("renotifyButton").disabled = true;
    document.getElementById("reselectButton").disabled = true;
    document.getElementById("returnToDecisionButton").disabled = true;
}

function performOperation(op) {

    disableOperationButtons();
    mmfalw_manualOperation = op;
    if (mmfalw_ajaxTimer != null) {
        window.clearTimeout(mmfalw_ajaxTimer);
    }

    // if we are not in an active ajax call, manually invoke it
    // if we are, then the callback handler will do this
    // after it get's it's latest response and updates formAction
    if (!mmfalw_ajaxActive) {
        submitManualOperation();
    }
}

function submitManualOperation() {
    // posts the operation form in the window context
    var operationForm = document.getElementById("operationForm");

    // update the action, and the hidden val which used to be the submit button
    operationForm.action = mmfalw_baseURL + mmfalw_formAction.replace("apiauthsvc", "authsvc") + "&operation=" + mmfalw_manualOperation;
    console.log("operationForm.action: " + operationForm.action);

    var v = null;
    if (mmfalw_manualOperation == "verify") {
        v = "Verify";
    } else if (mmfalw_manualOperation == "cancel") {
        v = "Cancel";
    } else if (mmfalw_manualOperation == "push") {
        v = "Renotify";
    } else if (mmfalw_manualOperation == "select") {
        v = "Reselect";
    } else if (mmfalw_manualOperation == "returnToDecision") {
        v = "ReturnToDecision";
    }

    if (v != null) {
        addHidden(operationForm, v, v);
    }
    operationForm.submit();
}

function addHidden(theForm, key, value) {
    // Create a hidden input element, and append it to a form
    var input = document.createElement('input');
    input.type = 'hidden';
    input.name = key;
    input.value = value;
    theForm.appendChild(input);
}

function buildPollURL() {
    var result = mmfalw_baseURL + mmfalw_formAction + "&operation=verify&ajax=true";
    if (!result.includes("apiauthsvc")) {
        result = result.replace("authsvc", "apiauthsvc");
    }
    return result;
}

function poll() {
    mmfalw_ajaxActive = true;
    var url = buildPollURL();
    console.log("polling: " + url);
    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {
        processPoll(request);
    };

    request.open("PUT", url);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");
    // send same parameters as the old FORM method of pressing the Verify button
    var putBody = {
        "Verify": "Verify"
    };
    request.send(JSON.stringify(putBody));
}

function processPoll(request) {
    if (request.readyState == 4) {
        console.log("The poll received readyState: " + request.readyState + " and status: " + request.status);
        console.log("The poll response text is: " + request["responseText"]);
        // request done, process it
        if (request.status == 200) {
            var json = null;
            var responseText = null;
            if (request.responseText) {
                var responseText = request.responseText;
                if (responseText.includes("}{")) {
                    responseText = responseText.substring(responseText.indexOf("}{") + 1);
                }
                var jObj = null;
                try {
                    jObj = JSON.parse(responseText);
                } catch (e) {
                    // we got a 200, but not valid JSON - that's an error
                }
                if (jObj != null) {
                    var status = "";
                    if (jObj.mmfa_transaction_status) {
                        status = jObj.mmfa_transaction_status;
                    } else {
                        status = jObj.status;
                    }

                    if (status == "pending") {
                        if (jObj.action != null) {
                            mmfalw_formAction = jObj.action;
                        }
                        if (jObj.location != null) {
                            mmfalw_formAction = jObj.location;
                        }
                        // restart the poll unless there is a manual operation about to happen
                        if (mmfalw_manualOperation == null) {
                            mmfalw_ajaxTimer = window.setTimeout(poll, mmfalw_pollTime);
                        }
                    } else {
                        // make sure we don't try and do anything else
                        mmfalw_manualOperation = null;
                        if (jObj.action != null) {
                            mmfalw_formAction = jObj.action;
                        }
                        if (jObj.location != null) {
                            mmfalw_formAction = jObj.location;
                        }
                        window.location = mmfalw_formAction.replace("apiauthsvc", "authsvc") + "&operation=verify";
                    }
                } else {
                    // 200, but not json response body - error

                    // make sure we don't try and do anything else
                    mmfalw_manualOperation = null;

                    // set up catchall error/status messages
                    mmfalw_errorTitle = authsvcMsg.mmfaTransactionStatusError;

                    // display whatever we came up with, and hide further operations
                    hideOperations();
                    displayError();
                    displayStatus();
                }
            }
        } else {
            // not a good 200 response - is there error text to display?

            // make sure we don't try and do anything else
            mmfalw_manualOperation = null;

            // set up catchall error/status messages
            mmfalw_errorTitle = authsvcMsg.mmfaTransactionStatusError;
            mmfalw_errorStr = authsvcMsg.unexpectedResponse + request.status;
            if (request.responseText) {
                try {
                    var rspObj = JSON.parse(request.responseText);
                    if (rspObj != null && rspObj.error != null) {
                        mmfalw_errorStr = rspObj.error;
                        // clear status string, since showing the server-returned error is enough
                        mmfalw_transactionStatus = "";
                    }
                } catch (e) {
                    // probably not JSON - just go with our generic error message
                }
            }

            // display whatever we came up with, and hide further operations
            hideOperations();
            displayError();
            displayStatus();
        }

        //
        // If a button was pressed while we were doing the last ajax operation,
        // act on it now
        //
        if (mmfalw_manualOperation != null) {
            submitManualOperation();
        }

        // we are no longer in an active poll
        mmfalw_ajaxActive = false;

    } else {
        // readyState is not 4, that's ok, just continue.
    }
}

// debug vars
var mmfalw_lastwsevent = null;
var mmfalw_lastwserror = null;
var mmfalw_lastmsgstatus = null;
// kept as a global so that we can close it if the user presses cancel
var mmfalw_socket = null;

var mmfalw_retry = 5;

function establishWebSocket() {
    var wsURL = mmfalw_baseWebSocketURL + mmfalw_jct + '/websock/mmfa-wss/' + mmfalw_txnIdAttrTxt;

    try {
        mmfalw_socket = new WebSocket(wsURL);

        mmfalw_socket.onopen = function(e) {
            mmfalw_lastwsevent = e;
            // if we're open, inform the server what txnid we want notification of change on
            if (e != null && e.type == 'open') {
                var msg = "subscribe";
                e.target.send(msg);
            }
        };

        mmfalw_socket.onmessage = function(e) {
            mmfalw_lastwsevent = e;
            var msg = JSON.parse(e.data);
            if (msg != null && msg.txnid == mmfalw_txnIdAttrTxt) {
                mmfalw_lastmsgstatus = msg.status;
                if (msg.status == "pending") {
                    // this was the ack from the server that
                    // proves our websocket is active
                } else if (msg.status == "canceled") {
                    // On Chrome we get an ack back when we cancel the
                    // transaction. Close the socket but don't redirect.
                    e.target.close();
                } else {
                    // close the socket, we're done
                    e.target.close();
                    // get the browser to pick up the answer
                    console.log("web socket detected status update");
                    performOperation('verify');
                }
            }
        };

        mmfalw_socket.onclose = function(e) {
            // 1006 is an unexpected close
            if (e.code == 1006 && (mmfalw_lastmsgstatus == null || mmfalw_lastmsgstatus == "pending")) {
                if (mmfalw_retry > 0) {
                    establishWebSocket();
                    mmfalw_retry -= 1;
                } else if (mmfalw_ajaxTimer == null && !mmfalw_ajaxActive) {
                    // start a poll thread if we are not already running one
                    console.log("starting polling because websockets failed");
                    mmfalw_ajaxTimer = window.setTimeout(poll, mmfalw_pollTime);
                }
            }
        };
    } catch (exception) {
        console.log("unable to open websocket: "+exception);
    }
}

function windowStart() {
    if (window.innerWidth <= 1366) {
        Array.prototype.forEach.call(document.querySelectorAll('.bx--tile--content p'), function(pElement) {
            pElement.classList.add("hidden");
        });
    }
    displayContextAttrs();
    displayStatus();
    displayError();
    establishWebSocket();
    // start polling, if we are not already
    if (mmfalw_ajaxTimer == null && !mmfalw_ajaxActive) {
        mmfalw_ajaxTimer = window.setTimeout(poll, mmfalw_pollTime);
    }

    if (mmfalw_returnEnabled && mmfalw_returnEnabled == "true" && mmfalw_totpEnrolled && mmfalw_totpEnrolled == "true") {
        document.getElementById("returnToDecisionButton").classList.remove("hidden");
    }

    document.getElementById("verifyButton").addEventListener('click', function() {
        performOperation('verify');
    });
    document.getElementById("cancelButton").addEventListener('click', function() {
        performOperation('cancel');
    });
    document.getElementById("renotifyButton").addEventListener('click', function() {
        performOperation('push');
    });
    document.getElementById("reselectButton").addEventListener('click', function() {
        performOperation('select');
    });
    document.getElementById("returnToDecisionButton").addEventListener('click', function() {
        performOperation('returnToDecision');
    });
}
