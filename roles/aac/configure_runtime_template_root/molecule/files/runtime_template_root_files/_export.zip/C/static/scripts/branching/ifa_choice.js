window.addEventListener("load", startup);

var ifa_tags = document.currentScript.dataset

var ifa_action = ifa_tags.action;
var ifa_url = getJunctionName() + ifa_action;

var ifa_errorMacro = ifa_tags.errorMessage;

var ifa_isFIDO = ifa_tags.isFido;
var ifa_isMMFA = ifa_tags.isMmfa;
var ifa_fingerprintPreferred = ifa_tags.fingerprintPreferred == "true";

var usernameMacro = ifa_tags.username;


function startup() {
    populateStrings();
    createGrid();
    createEventListeners();

    document.getElementById("password-error-twistie").style.display = "none";
    document.getElementById("fido-error-twistie").style.display = "none";
    document.getElementById("choice-error-twistie").style.display = "none";
}

function populateStrings() {
    document.title = ciMsg.authMethodSelection;
    document.querySelector('h1').textContent = authsvcMsg.signInOptions;
    document.getElementById('welcome').textContent = authsvcMsg.hello.replace("USERNAME_MACRO", usernameMacro);
    document.getElementById('description').textContent = authsvcMsg.howToSignIn;
    document.querySelector('#fido-method-container b').textContent = authsvcMsg.deviceUnlock;
    let deviceOS = getOS();
    if(deviceOS == "MacOS") {
        document.querySelector('#fido-method-container b').textContent = authsvcMsg.deviceUnlockMac;
    } else if (deviceOS == "Windows") {
        document.querySelector('#fido-method-container b').textContent = authsvcMsg.deviceUnlockWin;
    }

    document.getElementById("fido2-description").textContent = authsvcMsg.fidoDescription;
    document.querySelector('#app-method-container b').textContent = ciMsg.ibmVerifyApp;
    document.getElementById("mmfa-description").textContent = authsvcMsg.mmfaDescription;
    document.querySelector('#password-method-container b').textContent = authsvcMsg.password;
    document.getElementById("password-description").textContent = authsvcMsg.passwordDescription;

    document.getElementById("fido-title").textContent = authsvcMsg.fido2Authentication;
    document.getElementById("fido-description").textContent = authsvcMsg.fido2ReadyInstructions;
    document.getElementById("fido-submit").value = authsvcMsg.signIn;
    document.getElementById('fido-error-title').textContent = authsvcMsg.somethingWentWrong;
    document.getElementById('fido-error-detail').textContent = authsvcMsg.detail;
    document.getElementById('choice-error-title').textContent = authsvcMsg.somethingWentWrong;
    document.getElementById('choice-error-detail').textContent = authsvcMsg.detail;

    document.getElementById("username-label").textContent = authsvcMsg.username;
    document.getElementById("password-label").textContent = authsvcMsg.password;
    document.getElementById("show-password-label").textContent = authsvcMsg.showPassword;
    document.getElementById("password-submit").value = authsvcMsg.signIn;
    document.getElementById('password-error-title').textContent = authsvcMsg.somethingWentWrong;
    document.getElementById('password-error-detail').textContent = authsvcMsg.detail;

    document.getElementById("mmfa-select-title").textContent = authsvcMsg.mmfa;
    document.getElementById("mmfa-select-desc").textContent = authsvcMsg.mmfaSelectDesc;

    document.getElementById("mmfa-wait-title").textContent = authsvcMsg.mmfaPending;
    document.getElementById("mmfa-wait-desc").textContent = authsvcMsg.mmfaPendingDesc;
    document.getElementById("mmfa-error-title").textContent = authsvcMsg.errorColonLabel;
    document.getElementById("mmfa-transaction").textContent = authsvcMsg.mmfaTxnDetails;
    document.getElementById("status-name-span").textContent = authsvcMsg.mmfaStatus;
    document.getElementById("mmfa-action-title").textContent = authsvcMsg.actions;
    document.getElementById("mmfa-check-status").textContent = authsvcMsg.checkStatus;
    document.getElementById("mmfa-check-desc").textContent = authsvcMsg.mmfaRefreshDesc;
}

function createGrid() {

    var verify_method_div = document.getElementById("app-method-container");
    var fido_method_div = document.getElementById("fido-method-container");

    if (ifa_isFIDO == "true") {
        setupFIDOMethod();
        fido_method_div.appendChild(document.createElement('hr'));
        fido_method_div.classList.remove("hidden");
    }

    if (ifa_isMMFA == "true") {
        setupVerifyMethod();
        verify_method_div.appendChild(document.createElement('hr'));
        verify_method_div.classList.remove("hidden");
    }

    if(ifa_isFIDO != "true" && ifa_isMMFA != "true") {
        choosePassword();
    } else {
        document.getElementById("loader").style.display = "none";
        document.getElementById("method-container").style.display = "block";
    }
}

function createEventListeners() {
    document.getElementById("choice-back-button").addEventListener("click", function() {
        cancel("choice")
    });
    document.getElementById("password-back-button").addEventListener("click", function() {
        cancel("password")
    });
    document.getElementById("fido-back-button").addEventListener("click", function() {
        cancel("fido")
    });
    document.getElementById("mmfa-back-button").addEventListener("click", function() {
        cancel("mmfa")
    });
    document.getElementById("mmfa-select-back-button").addEventListener("click", function() {
        cancel("mmfa-select")
    });

    document.getElementById("password-method-container").addEventListener("click", choosePassword);

    document.getElementById("password-submit").addEventListener("click", submitPassword);

    document.getElementById("fido-submit").addEventListener("click", optionsGet);

    document.getElementById("password-error-button").addEventListener("click", function() {
        showErrorDetail("password-error-twistie", "password-error-arrow");
    });
    document.getElementById("password-error-button").addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13, space is 32
        if (event.keyCode === 13 || event.keyCode == 32) {
            this.click();
        }
    });

    document.getElementById("fido-error-button").addEventListener("click", function() {
        showErrorDetail("fido-error-twistie", "fido-error-arrow");
    });
    document.getElementById("fido-error-button").addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13, space is 32
        if (event.keyCode === 13 || event.keyCode == 32) {
            this.click();
        }
    });

    document.getElementById("choice-error-button").addEventListener("click", function() {
        showErrorDetail("choice-error-twistie", "choice-error-arrow");
    });
    document.getElementById("choice-error-button").addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13, space is 32
        if (event.keyCode === 13 || event.keyCode == 32) {
            this.click();
        }
    });

    var jsLinks = document.querySelectorAll('[href="#"]');
    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }

    document.getElementById("password-method-container").addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13, space is 32
        if (event.keyCode === 13 || event.keyCode == 32) {
            this.click();
        }
    });

    document.getElementById("username").addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13
        if (event.keyCode === 13) {
            submitPassword();
        }
    });
    document.getElementById("password").addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13
        if (event.keyCode === 13) {
            submitPassword();
        }
    });
}

function setupFIDOMethod() {
    var fido_method_div = document.getElementById("fido-method-container");

    fido_method_div.onclick = function() {
        chooseMethod("fido");
    };

    fido_method_div.addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13, space is 32
        if (event.keyCode === 13 || event.keyCode == 32) {
            this.click();
        }
    });
}

function setupVerifyMethod() {
    var verify_method_div = document.getElementById("app-method-container");

    verify_method_div.onclick = function() {
        chooseMethod("mmfa");
    };

    verify_method_div.addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13, space is 32
        if (event.keyCode === 13 || event.keyCode == 32) {
            this.click();
        }
    });
}

function choosePassword() {
    chooseMethod("password");
}

function chooseMethod(type) {
    var url = ifa_url;
    if(!url.includes("apiauthsvc")) {
        url = url.replace("authsvc", "apiauthsvc");
    }

    var methodJson = {};
    methodJson.operation = "verify";
    methodJson.action = "chooseAuth";
    methodJson.type = type;
    if(type == "mmfa" || type == "fido") {
        methodJson.username = usernameMacro;
    }

    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {

        if (request.readyState == 4) {

            var json = processJsonResponse(request);
            if(json != null) {

                var errorMessage = checkError(json);
                if(errorMessage != null) {
                    showError(errorMessage);
                } else {

                    if(json.mechanism == "urn:ibm:security:authentication:asf:mechanism:password") {
                        console.log("Password mechanism was chosen by user.");
                        showPassword();

                    } else if(json.mechanism == "urn:ibm:security:authentication:asf:mechanism:fido2") {
                        console.log("FIDO mechanism was chosen by user.");

                        let publicKey = JSON.parse(JSON.stringify(json), (key, value) => {
                            if (value == null || value == '' || value == [] || value == {}) {
                                return undefined;
                            }
                            return value;
                        });

                        if(("status" in publicKey) == true) {
                            delete publicKey['status'];
                        }
                        if(("errorMessage" in publicKey) == true) {
                            delete publicKey['errorMessage'];
                        }
                        if(("mechanism" in publicKey) == true) {
                            delete publicKey['mechanism'];
                        }
                        if(("location" in publicKey) == true) {
                            delete publicKey['location'];
                        }

                        swapSection("choice", "fido");
                        processCredentialsGet(publicKey, false);

                    } else if(json.mechanism == "urn:ibm:security:authentication:asf:mechanism:mmfa") {
                        console.log("MMFA mechanism was chosen by user.");

                        if(json.mmfaDevices != null && json.mmfaDevices.length > 0) {
                            showMMFAChoice(json);
                        } else {
                            showMMFA(json, "choice");
                        }
                    }
                }
            }

        } else {
            // readyState is not 4, that's ok, just continue.
        }
    };

    request.open("PUT", url);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");
    request.send(JSON.stringify(methodJson));
}

function showPassword() {
    swapSection("choice", "password");

    setTimeout(function() {
        document.getElementById("password").focus();
    }, 300);
}

function showMMFA(json, previousSection) {
    if (json.transactionId != "") {
        var txnIdAttrSpan = document.getElementById('mmfa-transaction-id');
        txnIdAttrSpan.textContent = json.transactionId;
    }

    if (json.contextMessage != "") {
        var ctxMsgAttrSpan = document.getElementById('mmfa-context-message');
        ctxMsgAttrSpan.textContent = json.contextMessage;
    }
    var statusDiv = document.getElementById('status-div');
    var statusSpan = document.getElementById('status-span');
    if (json.status != "") {
        statusSpan.textContent = json.status;
        statusDiv.classList.remove("hidden");
    } else {
        statusDiv.classList.add("hidden");
    }

    kickoffMMFA(json.location, usernameMacro);
    swapSection(previousSection, "mmfa");
}

function showMMFAChoice(json) {
    populateDeviceSelection(json, ifa_fingerprintPreferred);
    swapSection("choice", "mmfa-select");
}

function togglePassword() {
    let passwordField = document.getElementById("password");
    let passwordCheckbox = document.getElementById("show-password");
    
    if(passwordCheckbox.checked) {
        passwordField.type = "text";
    } else {
        passwordField.type = "password";
    }
}

function submitPassword() {
    hideError();

    var loginForm = document.getElementById('username_password_form');
    var usernameSubmit = document.getElementById('username-submit');

    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;
    var valid = true;
    if (username == "") {
        document.getElementById('username').required = 'true';
        valid = false;
    }
    if (password == "") {
        document.getElementById('password').required = 'true';
        valid = false;
    }
    if (valid) {

        var url = ifa_url;
        if(!url.includes("apiauthsvc")) {
            url = url.replace("authsvc", "apiauthsvc");
        }

        var passwordJson = {};
        passwordJson.username = encodeURI(username);
        passwordJson.password = encodeURI(password);
        passwordJson.operation = 'verify';

        var request = new XMLHttpRequest();
        request.onreadystatechange = function() {

            if (request.readyState == 4) {
                var json = processJsonResponse(request);
                if(json != null) {
                    var errorMessage = checkError(json);
                    if(errorMessage != null) {
                        showError(errorMessage);
                    } else {
                        sendSuccess(json["location"], username);
                    }
                }
            } else {
                // readyState is not 4, that's ok, just continue.
            }
        };

        request.open("PUT", url);
        request.setRequestHeader("Content-type", "application/json");
        request.setRequestHeader("Accept", "application/json");
        request.send(JSON.stringify(passwordJson));
    }

}

function optionsGet() {
    hideError();

    var url = ifa_url;
    if (!url.includes("apiauthsvc")) {
        url = url.replace("authsvc", "apiauthsvc");
    }

    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {

        if (request.readyState == 4) {
            var json = processJsonResponse(request);
            if(json != null && request.status == 200) {

                var errorMessage = checkError(json);
                if(errorMessage != null) {
                    showError(errorMessage);
                } else {
                    processCredentialsGet(json);
                }
            }
        } else {
            // readyState is not 4, that's ok, just continue.
        }
    };

    request.open("POST", url);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");
    request.send(JSON.stringify({}));
}

function processCredentialsGet(param) {
    document.getElementById("fido-submit").disabled = true;

    publicKey = {
        "rpId": param.rpId,
        "timeout": param.timeout,
        "challenge": base64URLDecode(param.challenge),
        "extensions": param.extensions
    };

    var allowCredsExist = param.allowCredentials != null && param.allowCredentials.length > 0;
    if(allowCredsExist) {
        publicKey["allowCredentials"] = param.allowCredentials;

        for (var i = 0; i < publicKey["allowCredentials"].length; i++) {
            let id = publicKey.allowCredentials[i].id;
            publicKey.allowCredentials[i].id = base64URLDecode(id);
        }
    }

    if(param.userVerification != null && param.userVerification != "") {
        publicKey.userVerification = param.userVerification;
    }

    let responseLocation = param["location"];
    if(responseLocation != null) {
        ifa_url = responseLocation;
    }

    console.log("FIDO options: " + JSON.stringify({publicKey}));
    navigator.credentials.get({publicKey}).then(function (assertion) {

        var url = ifa_url;
        if(!url.includes("apiauthsvc")) {
            url = url.replace("authsvc", "apiauthsvc");
        }

        var assertionJson = {};
        assertionJson.id = assertion.id;
        assertionJson.rawId = base64URLEncode(assertion.rawId);
        assertionJson.clientDataJSON = base64URLEncode(assertion.response.clientDataJSON);
        assertionJson.authenticatorData = base64URLEncode(assertion.response.authenticatorData);
        assertionJson.signature = base64URLEncode(assertion.response.signature);
        assertionJson.userHandle = base64URLEncode(assertion.response.userHandle);
        assertionJson.type = assertion.type;
        assertionJson.getClientExtensionResults = base64URLEncodeJSON(assertion.getClientExtensionResults());
        assertionJson.authenticatorAttachment = assertion.authenticatorAttachment;

        var request = new XMLHttpRequest();
        request.onreadystatechange = function() {

            if (request.readyState == 4) {
                var json = processJsonResponse(request);
                if(json != null) {

                    var errorMessage = checkError(json);
                    if(errorMessage != null) {
                        showError(errorMessage);
                    } else {
                        sendSuccess(json["location"], usernameMacro);
                    }
                }
            } else {
                // readyState is not 4, that's ok, just continue.
            }
        };

        request.open("PUT", url);
        request.setRequestHeader("Content-type", "application/json");
        request.setRequestHeader("Accept", "application/json");
        request.send(JSON.stringify(assertionJson));

    }).catch(function (err) {
        document.getElementById("fido-submit").disabled = false;
        console.log(err);
        showError(err);
    });
}

function cancel(step) {
    let stateId = ifa_url.substring(ifa_url.indexOf('=') + 1);
    if(stateId == "") {
        // Something has gone wrong and we no longer have a valid state ID.
        // Restart the policy.
        window.location.href = ifa_url.substring(0, ifa_url.indexOf('?') + 1) + "PolicyId=urn:ibm:security:authentication:asf:ifa&username=" + usernameMacro;
    } else {
        if(step == "choice") {
            document.getElementById("cancel-form").submit();

        } else if (step == "mmfa") {
            performMMFAOperation('returnToDecision');
            swapSection("mmfa", "choice");

        } else if (step == "fido" || step == "mmfa-select") {
            returnToDecision(step, false);

        } else if (step == "password") {
            // If there are no registrations, or both MMFA and FIDO are disabled,
            // the password back button should skip all the way back to the start.
            var cancel = ifa_isFIDO != "true" && ifa_isMMFA != "true";
            returnToDecision(step, cancel);
        }
    }
}

function returnToDecision(step, cancel) {
    var url = ifa_url;
    if(!url.includes("apiauthsvc")) {
        url = url.replace("authsvc", "apiauthsvc");
    }

    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {

        if (request.readyState == 4) {
            var json = processJsonResponse(request);
            if(json != null) {


                var errorMessage = checkError(json);
                if(errorMessage != null) {
                    showError(errorMessage);
                } else {
                    swapSection(step, "choice");

                    if(cancel) {
                        document.getElementById("cancel-form").submit();
                    }
                }
            }
        } else {
            // readyState is not 4, that's ok, just continue.
        }
    };

    request.open("PUT", url);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");
    request.send(JSON.stringify({"operation":"returnToDecision"}));
}

function swapSection(before, after) {
    hideError();
    setTimeout(function() {
        document.getElementById(before + "-section").classList.add('bx--dialog-content--hidden');
        document.getElementById(before + "-section").classList.remove('bx--dialog-content--visible');
        if(after == "choice") {
            document.getElementById(before + "-section").style.left = '100%';
        } else {
            document.getElementById(before + "-section").style.left = '-100%';
        }
    }, 100);

    setTimeout(function() {
        document.getElementById(after + "-section").classList.remove('bx--dialog-content--hidden');
        document.getElementById(after + "-section").style.left = '';
        document.getElementById(after + "-section").classList.add('bx--dialog-content--visible');
    }, 200);
}

function showError(errMsg) {
    document.getElementById("password-error-msg").style.visibility = "visible";
    document.getElementById("password-error-content").textContent = errMsg;
    document.getElementById("fido-error-msg").style.visibility = "visible";
    document.getElementById("fido-error-content").textContent = errMsg;
    document.getElementById("choice-error-msg").style.visibility = "visible";
    document.getElementById("choice-error-content").textContent = errMsg;
}

function hideError() {
    document.getElementById("password-error-msg").style.visibility = "hidden";
    document.getElementById("password-error-content").textContent = "";
    document.getElementById("fido-error-msg").style.visibility = "hidden";
    document.getElementById("fido-error-content").textContent = "";
    document.getElementById("choice-error-msg").style.visibility = "hidden";
    document.getElementById("choice-error-content").textContent = "";
}

function processJsonResponse(request) {
    if (request.responseText) {
        var json = null;
        try {
            json = JSON.parse(request.responseText);
        } catch (e) {
            // we got a 200, but not valid JSON - that's an error
            showError(authsvcMsg.errorAuth);
        }

        if(json.stateId != null || json.state != null) {
            stateId = json.stateId != null ? json.stateId : json.state;
            if (ifa_url.indexOf('?StateId=') > 0) {
                ifa_url= ifa_url.substring(0, ifa_url.indexOf('=') + 1);
                ifa_url = ifa_url + stateId;
            }
        }

        if(json.location != null) {
            document.getElementById("ping-pong-form").action = json.location.replace("apiauthsvc","authsvc");
            document.getElementById("cancel-form").action = json.location.replace("apiauthsvc","authsvc");
        }

        if(json != null) {
            return json;
        } else {
            // Bad response, show an error.
            showError(authsvcMsg.errorAuth);
        }
    } else {
        // No response text. Very weird. Show error.
        showError(authsvcMsg.errorAuth);
    }
}

function checkError(json) {
    errorMsg = null;
    if(json.error != null && json.error != "") {
        errorMsg = json.error;
    } else if(json.errorMessage != null && json.errorMessage != "") {
        errorMsg = json.errorMessage;
    } else if(json.exceptionMsg != null && json.exceptionMsg != "") {
        errorMsg = json.exceptionMsg;
    } else if(json.message != null && json.message != "") {
        errorMsg = json.message;
    }

    return errorMsg;
}

function sendSuccess(location, username) {
    var storage = window.localStorage;
    var ifaUsersObject = JSON.parse(storage.getItem('ifaUsersObject'));

    if(ifaUsersObject != null) {
        var rememberMe = ifaUsersObject["rememberMe"];

        // If remember me is present, not necessarily true or false, we want to process it
        // and potentially remove it.
        if(rememberMe != null) {
            delete ifaUsersObject["rememberMe"];

            // If remember me is present AND true, store the username.
            if(rememberMe) {
                ifaUsersObject["mostRecent"] = username;
            }

            // Save to storage.
            storage.setItem('ifaUsersObject', JSON.stringify(ifaUsersObject));
        }
    }

    sendFIDOSuccess(location);
}

function showErrorDetail(divId, svgId) {
    var currentDisplay = document.getElementById(divId).style.display;
    document.getElementById(svgId).classList.toggle("active");
    if(currentDisplay == "none") {
        document.getElementById(divId).style.display = "block";
    } else {
        document.getElementById(divId).style.display = "none";
    }
}
