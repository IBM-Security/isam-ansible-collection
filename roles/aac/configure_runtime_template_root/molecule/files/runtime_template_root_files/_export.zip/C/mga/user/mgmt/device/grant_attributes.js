window.addEventListener("load", startup);

var getRequest = null;
var deleteRequest = null;
var grantId = getGrantIdFromPath();
if (grantId) {
	getAttributes(grantId);
}

function getAttributes(grantId) {
	getRequest = new XMLHttpRequest();
	getRequest.onreadystatechange = processGetRequest;
	getRequest.open("GET", grantBaseUrl + "/" + grantId, true);
	getRequest.send(null);
}

function processGetRequest() {

	if (getRequest.readyState == 4 && getRequest.status == 200) {
		if (getRequest.responseText == "Not found") {
		} else {
			var grantInfo = JSON.parse(getRequest.responseText);

			var enabledBox = document.getElementById('grantEnabled');
			var grantId = grantInfo['id'];
			enabledBox.setAttribute('grantId', grantId);

			enabledBox.onclick = function() {
				enableGrant(this.getAttribute('grantId'), this.checked);
			};
			if (grantInfo['isEnabled'] == true) {
				enabledBox.checked = true;
			}

			createTokensTable(grantInfo['tokens']);
			createAttributesTable(grantInfo['attributes']);
			var grantIdTokensTable = document.getElementById('grantIdTokensTable');
			grantIdTokensTable.innerHTML = grantId;
			var grantIdAttrsTable = document.getElementById('grantIdAttrsTable');
			grantIdAttrsTable.innerHTML = grantId;
		}
	}
}

function createAttributesTable(attributes) {
	var table = document.getElementById("attributesTable");
	for ( var i = 0; i < attributes.length; i++) {
		var attr = attributes[i];
		var tr = table.insertRow(-1);

		var nameTd = tr.insertCell(-1);
		var valueTd = tr.insertCell(-1);
		var readonlyTd = tr.insertCell(-1);

		var valueElement = document.createElement("input");
		var readonlyValue = "N";

		valueElement.name = attr['name'];
		valueElement.value = attr['value'];

		if (attr['sensitive']) {
			valueElement.setAttribute("type", 'password');
			valueElement.value = "";
		} else {
			valueElement.setAttribute("type", 'text');
		}
		if (attr['readonly']) {
			valueElement.setAttribute("readonly", true);
			readonlyValue = "Y";
		}

		nameTd.innerHTML = attr['name'];
		valueTd.appendChild(valueElement);
		readonlyTd.innerHTML = readonlyValue
	}
}

function createTokensTable(tokens) {
	var table = document.getElementById("tokensTable");
	for ( var i = 0; i < tokens.length; i++) {
		var token = tokens[i];
		var tr = table.insertRow(-1);

		var typeTd = tr.insertCell(-1);
		var subTypeTd = tr.insertCell(-1);
		var dateCreatedTd = tr.insertCell(-1);
		var lifeTimeTd = tr.insertCell(-1);
		var lastActivityTd = tr.insertCell(-1);
		var scopeTd = tr.insertCell(-1);

		typeTd.innerHTML = token['type'];
		subTypeTd.innerHTML = token['subType'];
		dateCreatedTd.innerHTML = token['dateCreated'];
		lifeTimeTd.innerHTML = token['lifetime'];
		lastActivityTd.innerHTML = token['lastUsed'];
		scopeTd.innerHTML = token['scope'];
	}
}

function deleteGrant() {
	deleteRequest = new XMLHttpRequest();
	deleteRequest.onreadystatechange = processDeleteRequest;
	deleteRequest.open("DELETE", grantBaseUrl + "/" + grantId, true);
	deleteRequest.send(null);
}

function processDeleteRequest() {
	if (deleteRequest.readyState == 4 && deleteRequest.status == 200) {
		if (deleteRequest.responseText == "Not found") {
		} else {
			window.location = junction
					+ "/sps/mga/user/mgmt/html/device/device_selection.html";
		}
	}
}

function getGrantIdFromPath() {
	var queryString = window.location.search.substring(1);
	var params = queryString.split("&");
	for ( var i = 0; i < params.length; i++) {
		var keyValue = params[i].split("=");
		if (keyValue[0] == "id") {
			return keyValue[1];
		}
	}

	return null;
}

function enableGrant(grantId, enabled) {
	var json = {};
	json['isEnabled'] = enabled;
	makeAjaxRequest("PUT", grantBaseUrl + "/" + grantId, processEnableRequest, JSON.stringify(json));
}

function processEnableRequest(enableRequest) {
	if (enableRequest.readyState == 4 && enableRequest.status == 200) {
		if (enableRequest.responseText == "Not found") {
		} else {
			var json = JSON.parse(enableRequest.responseText);
			window.alert(json['result']);
		}
	}
}

function formToAttributesJson() {
	var attributes = [];
	var grantIdAttrsTable = document.getElementById('attributesTable');

	var inputElements = grantIdAttrsTable.getElementsByTagName( 'input' );
	for (var i = 0; i < inputElements.length; i++) {
		var isReadonly = inputElements[i].getAttribute('readonly');
		var isSensitive = inputElements[i].getAttribute('type') == "text" ? false : true;
		var attrName = inputElements[i].getAttribute('name');
		var attrValue = inputElements[i].value;

		if (!isReadonly) {
			if (!isSensitive || attrValue != "") {
				var attrJson = {}
				attrJson['name'] = attrName;
				attrJson['value'] = attrValue;
				attributes.push(attrJson);
			}
		}
	}

	return attributes;
}

function updateAttributes() {
	var json = {};
	var enabledBox = document.getElementById('grantEnabled');
	json['isEnabled'] = enabledBox.checked;
	json['attributes'] = formToAttributesJson();

	makeAjaxRequest("PUT", grantBaseUrl + "/" + grantId, processEnableRequest, JSON.stringify(json));
}

function startup() {
	document.getElementById("updateAttributesButton").addEventListener("click", updateAttributes);
	document.getElementById("deleteGrantButton").addEventListener("click", deleteGrant);
}