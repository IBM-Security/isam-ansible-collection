window.addEventListener('load', startup);

var otpcp_errorMsg = document.currentScript.dataset.errorTag;
var otpcp_mapRuleData = document.currentScript.dataset.mappingRuleData;
var otpcp_dispReselButton = document.currentScript.dataset.displayReselectButton

function displayError() {
    if (otpcp_errorMsg != "") {
        var errorMsg = document.getElementById("errorMessage");
        errorMsg.textContent = errorMsg.textContent + otpcp_errorMsg;

        var errorDiv = document.getElementById("errorDiv");
        errorDiv.className = "errorMessage visible";
    }
}

function displayMappingRuleData() {
    if (otpcp_mapRuleData != "") {
        var mrdText = document.getElementById("mappingRuleDataText");
        mrdText.textContent = mrdText.textContent + otpcp_mapRuleData;

        var mappingRuleDataDiv = document.getElementById('mappingRuleDataDiv');
        mappingRuleDataDiv.className = "visible";
    }
}

function displaySelectButton() {
    var reselectButtonDiv = document.getElementById('reselectButtonDiv');

    if (otpcp_dispReselButton != "") {
        reselectButtonDiv.className = "";
    }
}

function startup() {
    displayError();
    displayMappingRuleData();
    displaySelectButton();
}