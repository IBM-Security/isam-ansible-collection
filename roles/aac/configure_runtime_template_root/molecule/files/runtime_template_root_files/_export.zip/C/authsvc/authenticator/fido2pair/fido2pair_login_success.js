let fido2pairToken = document.currentScript.dataset.fido2pairToken;
let fido2pairUsername = document.currentScript.dataset.fido2pairUsername;

window.addEventListener('load', (event) => {
    let fidoUsersObjectStr = localStorage.getItem("fidoUsersObject");
    fidoUsersObject = (fidoUsersObjectStr == null ? { users: {} } : JSON.parse(fidoUsersObjectStr));

    if (fido2pairToken != null && fido2pairToken != "" && fido2pairToken != "Unknown") {
        Object.keys(fidoUsersObject.fidoUsers).forEach((index) => {
            if (fidoUsersObject.fidoUsers[index].username == fido2pairUsername) {
                fidoUsersObject.fidoUsers[index].persistent = fido2pairToken;
                localStorage.setItem('fidoUsersObject', JSON.stringify(fidoUsersObject));
            }
        });
    } else {
        console.log("Unable to locate authentication token.");
    }
});