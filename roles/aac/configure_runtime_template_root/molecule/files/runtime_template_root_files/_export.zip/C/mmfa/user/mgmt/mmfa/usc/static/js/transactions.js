var transactions_table = null;

function displayTransactionsTable(scimRequest) {

	if (scimRequest != null){
		if (transactions.length != 0) {

			transactions_table
			    .clear()
			    .draw();
			
			$.each(transactions, function(i, transaction) {
				transaction.values = [];
				transaction.name = [];
				transaction.dataType = [];
				for (k = 0; k < attributes.length; k++) {
					if (transaction.transactionId == attributes[k].transactionId) {
						transaction.values.push(attributes[k].values);
						transaction.name.push(attributes[k].name);
						transaction[attributes[k].name] = attributes[k].values;
						transaction.dataType.push(attributes[k].dataType);
					}
				}
				var type = "Transaction";
				if (typeof transaction.values[0] != "undefined" && transaction.values != null) {
					if (transaction.values[0][0].includes("transaction")) {
						type = "Transaction";
					} else if (transaction.values[0][0].includes("device")) {
						type = "Device Add";
					} else {
						type = "Sign-in";
					}
				}
				var method = "User Presence";
				if (typeof transaction.authnPolicyURI != "undefined" && transaction.values != null) {
					if (transaction.authnPolicyURI == "urn:ibm:security:authentication:asf:mmfa_response_user_presence") {
						method = "User Presence";
					} else if (transaction.authnPolicyURI == "urn:ibm:security:authentication:asf:mmfa_response_fingerprint") {
						method = "Fingerprint";
					}
				}
				
				var rowadd = transactions_table.row.add(["",
				    transaction.txnStatus,
     				transaction.transactionId,
				    transaction["mmfa.request.context.message"],
	 				type,
					method,
					transaction["mmfa.request.push.notification.sent"] != null ? transaction["mmfa.request.push.notification.sent"] == false ? "Not Sent" : "Sent" : "Not enabled",
					dateToString(new Date(transaction.creationTime))
				]);

				
				var rowNode = rowadd.node();
				
				if (transactions[i].txnStatus == "PENDING") {
					$(rowNode).addClass("tablecolor-pending");
				} else if (transactions[i].txnStatus == "SUCCESS") {
					$(rowNode).addClass("tablecolor-success");
				} else {
					$(rowNode).addClass("tablecolor-fail");
				}
				$(".tablecolor-pending td:first-child").addClass("clickity");
				$(".tablecolor-success td:first-child").addClass("clickity");
				$(".tablecolor-fail td:first-child").addClass("clickity");
				$("#transactionsTable").on('draw.dt', function() {
					$(".tablecolor-pending td:first-child").addClass("clickity");
					$(".tablecolor-success td:first-child").addClass("clickity");
					$(".tablecolor-fail td:first-child").addClass("clickity");
				});
		});
		transactions_table.columns.adjust().draw();

		displayElements("full", loading_elements_transaction_table, null_elements_transaction_table, content_elements_transaction_table);
		$("#transactionsTable").css("width", "100%");		
	} else {
		displayElements("empty", loading_elements_transaction_table, null_elements_transaction_table, content_elements_transaction_table);
	}
	}else{
		displayElements("empty", loading_elements_transaction_table, null_elements_transaction_table, content_elements_transaction_table);
	}
}

function loadReceipt(transactionId, transaction_value, timeout) {
	setTimeout(function(){
		values = "$" + transaction_value;
		var now = new Date();
		lastActivityTime = now.toISOString();
		if (transaction_value == null) {
			$.each(transactions, function(i, transaction) {
				$.each(attributes, function(k, attribute) {
					if (transactionId == attribute.transactionId) {
						transaction.values = attribute.values;
						transaction.name = attribute.name;
						transaction.dataType = attribute.dataType;
					}
				});
				if (transaction["transactionId"] == transactionId) {
					values = transaction["values"][0][0];
					lastActivityTime = transaction["lastActivityTime"];
					return;
				}
			});
		}
		var url_submit = '/protected/bank/receipt'
		var form = $('<form action="' + url_submit + '" method="post" style="display:none">' + '<input type="text" name="isam_success" value="true" />' + '<input type="text" name="transaction_id" value="' + transactionId + '" />' + '<input type="text" name="values" value="' + values + '" />' + '<input type="text" name="lastActivityTime" value="' + lastActivityTime + '" />' + '</form>');
		$('body').append(form);
		form.submit();
	}, timeout);
}

/* Formatting function for row details - modify as you need */
function expand(additional) {
	var hidden = "hidden";
	if (additional.txnStatus == "PENDING") {
		hidden = "";
	}
	// `d` is the original data object for the row
	return '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">' + '<tr>' + '<td>Authentication Policy Action:</td>' + '<td>' + additional.authnPolicyAction + '</td>' + '<td rowspan="5" colspan="2" style="cursor:pointer"><div class="' + hidden + '">Cancel</div><img class = "' + hidden + '" onclick = "javascript:abortTransactionTable(\'' + additional.transactionId + '\')" style = "display:inline" src="' + static_path + '/img/32_trashcan.svg"></td>' + '<td rowspan="5" colspan="2" style="cursor:pointer">Receipt<img onclick = "javascript:loadReceipt(\'' + additional.transactionId + '\', 0, 0)" style = "display:inline" src="' + static_path + '/img/32_report.svg"></td>' + '</tr>' + '<tr>' + '<td>Authentication Policy URI:</td>' + '<td>' + additional.authnPolicyURI + '</td>' + '</tr>' + '<tr>' + '<td>Authentication Policy URI:</td>' + '<td>' + additional.name + '</td>' + '</tr>' + '<tr>' + '<td>Request URL:</td>' + '<td>' + additional.requestUrl + '</td>' + '</tr>' + '<tr>' + '<td>Extra info:</td>' + '<td>' + additional.dataType + ': [ ' + additional.values + ' ] </td>' + '</tr>' + '</table>';
}

$(document).ready(function() {		
	
	var color_fail = "#dc0000";
	var color_pending = "#fd8c00";
	var color_success = "#00ac46";

	  $.fn.dataTable.moment( 'MMMM D, YYYY at HH:MMA' );
	  $.fn.dataTable.moment( 'MMMM D, YYYY at HH:MM' );

	  $.fn.dataTable.moment( 'D, MMMM, YYY, HH:MM' );
	  $.fn.dataTable.moment( 'MMMM D, YYY, HH:MM'  );
	  $.fn.dataTable.moment( 'MMMM D, YYY, HH:MM a'  );
	  
	transactions_table = $('#transactionsTable').DataTable( {
     "lengthChange": false,
	 "pageLength": 9,
         "order": [[ 7, "desc" ]],
       "columnDefs": [
	    { "width": "20%", "targets": 1 }
	  ]
    });    
		
	displayElements("loading", loading_elements_transaction_table, null_elements_transaction_table, content_elements_transaction_table);

	ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, displayTransactionsTable);
	
	// Add event listener for opening and closing details
	$('#transactionsTable tbody').on('click', 'td.clickity', function () {
	     var tr = $(this).closest('tr');
			//console.log(tr);
	     var row = transactions_table.row( tr );
	
	     if ( row.child.isShown() ) {
	         // This row is already open - close it
	         row.child.hide();
	         tr.removeClass('shown');
	     }
	     else {
	         // Open this row
	        	for (i = 0; i < transactions.length; i++) { 
	        		if (transactions[i].transactionId == row.data()[2]){
	 	            row.child( expand(transactions[i]) ).show();
	 	            tr.addClass('shown');
	        			break;
	        		}	    			
	 		}
	     }
	 } );  
  
});
