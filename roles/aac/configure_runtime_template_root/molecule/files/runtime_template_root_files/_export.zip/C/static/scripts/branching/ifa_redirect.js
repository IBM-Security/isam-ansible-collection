window.addEventListener("load", startup);

var ifa_dataSet = document.currentScript.dataset

var ifa_errorMacro = ifa_dataSet.errorMessage;
var ifa_redirectURL = ifa_dataSet.redirectUrl;
var ifa_username = ifa_dataSet.username;

function populateStrings() {
    document.title = authsvcMsg.redirect;
    document.querySelector('h1').textContent = authsvcMsg.redirecting;
}

function startup() {
    populateStrings();

    var storage = window.localStorage;
    var ifaUsersObject = JSON.parse(storage.getItem('ifaUsersObject'));

    if(ifaUsersObject != null) {
        var rememberMe = ifaUsersObject["rememberMe"];

        // If remember me is present, not necessarily true or false, we want to process it
        // and potentially remove it.
        if(rememberMe != null) {
            delete ifaUsersObject["rememberMe"];

            // If remember me is present AND true, store the username.
            if(rememberMe) {
                ifaUsersObject["mostRecent"] = ifa_username;
            }

            // Save to storage.
            storage.setItem('ifaUsersObject', JSON.stringify(ifaUsersObject));
        }
    }

    window.location.href = ifa_redirectURL;
}
