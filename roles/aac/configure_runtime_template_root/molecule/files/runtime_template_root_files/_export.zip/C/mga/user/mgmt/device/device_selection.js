window.addEventListener("load", startup);

var qrCodeRequest = null;

var u2fTokens = [];

var relyingParties = @FIDO2_RELYING_PARTIES@;

// Safari 3.0+ "[object HTMLElementConstructor]"
var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

function initialisePage() {
    getDevices();
    getGrants();
    getAuthenticators();
    getFIDOAuthenticators();
    getU2FTokens();
    getDynamicClients();
}

function getDevices() {
    makeAjaxRequest("GET", deviceBaseUrl, processGetDevicesRequest, null);
}
function getDynamicClients() {
    makeAjaxRequest("GET", clientsBaseUrl, processGetClientsRequest, null);
}

function getGrants() {
    makeAjaxRequest("GET", grantBaseUrl, processGetGrantsRequest, null);
}

function getAuthenticators() {
    makeAjaxRequest("GET", authenticatorsBaseUrl, processGetAuthenticatorsRequest, null);
}

function getFIDOAuthenticators() {
    var request;
    makeJsonAjaxRequest("GET", fidoAuthenticatorsBaseUrl, processGetFIDOAuthenticatorsRequest, null);
}

function getU2FTokens() {
    var request;
    makeJsonAjaxRequest("GET", u2fPolicyUrl, processGetU2FTokensRequest, null);
}

function processGetDevicesRequest(getRequest) {
    if(getRequest.readyState == 4 && getRequest.status ==200) {
        if(getRequest.responseText == "Not found") {
        } else {
            var deviceInfo = JSON.parse(getRequest.responseText);
            var devices = deviceInfo['devices'];
            createDevicesTable(devices);
        }
    }
}

function processGetClientsRequest(getRequest) {
    if(getRequest.readyState == 4 && getRequest.status ==200) {
        if(getRequest.responseText == "Not found") {
        } else {
            var clientsInfo = JSON.parse(getRequest.responseText);
            var clients = clientsInfo['clients'];
            createClientsTable(clients);
        }
    }
}

function processGetGrantsRequest(getRequest) {
    if (getRequest.readyState == 4 && getRequest.status == 200) {
        if (getRequest.responseText == "Not found") {
        } else {
            var grantInfo = JSON.parse(getRequest.responseText);
            var grants = grantInfo['grants'];
            createGrantsTable(grants);
        }
    }
}

function processGetAuthenticatorsRequest(getRequest) {
    if (getRequest.readyState == 4 && getRequest.status == 200) {
        if (getRequest.responseText == "Not found") {
        } else {
            var authenticatorsInfo = JSON.parse(getRequest.responseText);
            createAuthenticatorTable(authenticatorsInfo);
        }
    }
}

function processGetFIDOAuthenticatorsRequest(getRequest) {
    if (getRequest.readyState == 4 && getRequest.status == 200) {
        if (getRequest.responseText == "Not found") {
        } else {
            fidoAuthenticatorsRequest = JSON.parse(getRequest.responseText);
            createFIDOAuthentiatorsTable(fidoAuthenticatorsRequest);
        }
    }
}

function processGetU2FTokensRequest(getRequest) {
    if (getRequest.readyState == 4 && getRequest.status == 200) {
        if (getRequest.responseText == "Not found") {
        } else {
            registerRequest = JSON.parse(getRequest.responseText);
            createU2FTokensTable(registerRequest);
        }
    } else if (getRequest.readyState == 4 && getRequest.status == 400) {
        // Try with shortened url
        var request;
        makeJsonAjaxRequest("GET", shortU2fPolicyUrl, processGetShortU2FTokensRequest, null);
    }
}

function processGetShortU2FTokensRequest(getRequest) {
    if (getRequest.readyState == 4 && getRequest.status == 200) {
        if (getRequest.responseText == "Not found") {
        } else {
            registerRequest = JSON.parse(getRequest.responseText);
            createU2FTokensTable(registerRequest);
        }
    }
}

function createGrantsTable(grants) {
    var table = document.getElementById("grantTable");
    for(var i = 0; i < grants.length; i++) {
        var grant = grants[i];
        var tr = table.insertRow(-1);

        var nameTd = tr.insertCell(-1);
        var idTd = tr.insertCell(-1);
        var enabledTd = tr.insertCell(-1);
        var clientIdTd = tr.insertCell(-1);
        var deleteTd = tr.insertCell(-1);

        var grantA = document.createElement('a');
        grantA.href = junction + "/sps/mga/user/mgmt/html/device/grant_attributes.html?id=" + grant['id'];
        grantA.innerHTML = grant['id'];
        idTd.appendChild(grantA);

        nameTd.innerHTML = grant['clientName'];
        clientIdTd.innerHTML = grant['clientId'];

        var enabledBox = document.createElement('input');
        enabledBox.type = 'checkbox';
        enabledBox.name = 'grantEnabled';
        enabledBox.checked = grant['isEnabled'];
        enabledBox.id = grant['id'];
        enabledBox.onclick = function () { enableGrant(this.id, this.checked); };
        enabledTd.appendChild(enabledBox);

        var a = document.createElement('a');
        a.id = grant['id'];
        a.onclick = function(){ deleteGrant(this.id); return false; };
        a.href = "";
        a.innerHTML = mgmtMsg.removeString;
        deleteTd.appendChild(a);

    }
}

function createDevicesTable(devices) {
    var table = document.getElementById("deviceTable");
    for(var i = 0; i < devices.length; i++) {
        var device = devices[i];
        var tr = table.insertRow(-1);

        var nameTd = tr.insertCell(-1);
        var enabledTd = tr.insertCell(-1);
        var lastActivityTd = tr.insertCell(-1);
        var deleteTd = tr.insertCell(-1);

        var deviceA = document.createElement('a');
        deviceA.href = junction + "/sps/mga/user/mgmt/html/device/device_attributes.html?id=" + device['id'];
        deviceA.innerHTML = device['name'];
        nameTd.appendChild(deviceA);

        lastActivityTd.innerHTML = device['lastUsedTime'];

        var enabledBox = document.createElement('input');
        enabledBox.type = 'checkbox';
        enabledBox.name = 'deviceEnabled';
        enabledBox.checked = device['isEnabled'];
        enabledBox.id = device['id'];
        enabledBox.onclick = function () { enableDevice(this.id, this.checked); };
        enabledTd.appendChild(enabledBox);

        var a = document.createElement('a');
        a.id = device['id'];
        a.onclick = function(){ deleteDevice(this.id); return false; };
        a.href = "";
        a.innerHTML = mgmtMsg.removeString;
        deleteTd.appendChild(a);
    }
}
function createClientsTable(clients) {
    var table= document.getElementById("clientsTable");
    for(var i = 0; i < clients.length; i++) {
        var client = clients[i];
        var tr = table.insertRow(-1);

        var definitionIdTd = tr.insertCell(-1);
        var clientIdTd = tr.insertCell(-1);
        var removeClientTd = tr.insertCell(-1);

        var definition = client.data.registration_client_uri.match(/register\/([^]*)(?=\?)/)[1];

        definitionIdTd.innerHTML = definition

        var uri = client.data['registration_client_uri'];

        var server_relative = uri.replace(/https:\/\/.*?(?=\/)/, "");
        if(!server_relative.startsWith(junction)) {
            server_relative = junction + server_relative;
        }

        var clientA = document.createElement('a');
        clientA.href = junction + "/sps/mga/user/mgmt/html/client.html?uri=" + encodeURIComponent(server_relative);
        clientA.innerHTML = client['clientId'];
        clientIdTd.appendChild(clientA);

        var a = document.createElement('a');
        a.id = client['clientId'];
        a.href = server_relative;
        a.onclick = function(){ deleteClient(server_relative); return false; };
        a.innerHTML = mgmtMsg.removeString;
        removeClientTd.appendChild(a);
    }
}

function createAuthenticatorTable(authenticators) {
    var table = document.getElementById("authenticatorTable");

    for(var i = 0; i < authenticators.length; i++) {
        var authenticator = authenticators[i];
        var tr = table.insertRow(-1);

        var idTd = tr.insertCell(-1);
        var deviceNameTd = tr.insertCell(-1);
        var typeTd = tr.insertCell(-1);
        var osVersionTd = tr.insertCell(-1);
        var oauthGrantTd = tr.insertCell(-1);
        var enabledTd = tr.insertCell(-1);
        var deleteTd = tr.insertCell(-1);

        var grantA = document.createElement('a');
        grantA.href = junction + "/sps/mga/user/mgmt/html/device/grant_attributes.html?id=" + authenticator['oauth_grant'];
        grantA.innerHTML = authenticator['oauth_grant'];
        oauthGrantTd.appendChild(grantA);

        var authenticatorA = document.createElement('a');
        authenticatorA.href = junction + "/sps/mmfa/user/mgmt/html/mmfa/auth_methods.html?id=" + authenticator["id"];
        authenticatorA.innerHTML = authenticator['id'];
        idTd.appendChild(authenticatorA);

        var name = authenticator['device_name'];
        if(name != null && name != "") {
            deviceNameTd.innerHTML = name;
        }

        var type = authenticator['device_type'];
        if(type != null && type != "") {
            typeTd.innerHTML = type;
        }

        var os = authenticator['os_version'];
        if(os != null && os != "") {
            osVersionTd.innerHTML = os;
        }

        var enabled = authenticator['enabled'];
        enabledTd.innerHTML = enabled;

        var a = document.createElement('a');
        a.id = authenticator['id'];
        a.onclick = function(){ deleteAuthenticator(this.id); return false; };
        a.href = "";
        a.innerHTML = mgmtMsg.removeString;
        deleteTd.appendChild(a);

    }
}

function createFIDOAuthentiatorsTable(response) {
    var table = document.getElementById("fidoAuthenitcatorTable");
    var testString= document.getElementById("testString").innerHTML;

    var optionsString = "";
    if(relyingParties) {
        Object.keys(relyingParties).forEach(function(rpId,index) {
            optionsString += "<option>";
            optionsString += rpId;
            optionsString += "</option>";
        });
    }
    document.getElementById("relyingPartySelection").innerHTML = optionsString;

    response.sort(function(a, b){return (a.nickname > b.nickname)})
    response.sort(function(a, b){return (a.rpId > b.rpId)})

    for(var i = 0; response && i < response.length; i++) {
        var authenticator = response[i];
        var tr = table.insertRow(-1);

        var rpTd = tr.insertCell(-1);
        var nicknameTd = tr.insertCell(-1);
        var brandTd = tr.insertCell(-1);
        var typeTd = tr.insertCell(-1);
        var enabledTd = tr.insertCell(-1);
        var verifiedTd = tr.insertCell(-1);
        var createdTd = tr.insertCell(-1);
        var lastUsedTd = tr.insertCell(-1);
        var deleteTd = tr.insertCell(-1);

        var rpId = authenticator['rpId'];
        if(rpId != null && rpId != "") {
            rpTd.innerHTML = rpId;
        }

        var nickname = authenticator['nickname'];
        if(nickname != null && nickname != "") {
            nicknameTd.textContent = nickname;
        }

        if(authenticator['metadata'] != null) {
            var description = authenticator['metadata']['description'];
            var icon = authenticator['metadata']['icon'];
            if(icon != null && icon != "") {
                var div = document.createElement('div');
                div.style = "text-align: center";
                var img = document.createElement('img');
                img.alt = (description != null) ? description : "";
                img.style = "width:32px; padding:0px;";
                img.src = icon;
                div.appendChild(img);
                brandTd.appendChild(div);
            }
            if(description != null && description != "") {
                var p = document.createElement('p');
                p.style = (icon != null && icon != "") ? "margin-bottom:0px;" : "margin:0px;";
                p.textContent = description;
                brandTd.appendChild(p);
            }
        }

        var type = authenticator['version'];
        if(type != null) {
            typeTd.textContent = type == 1 ? "U2F" : "WebAuthn";
        }

        var enabledBox = document.createElement('input');
        enabledBox.type = 'checkbox';
        enabledBox.name = 'fidoEnabled';
        enabledBox.checked = authenticator['enabled'];
        enabledBox.disabled = true;
        enabledTd.appendChild(enabledBox);

        var verifiedBox = document.createElement('input');
        verifiedBox.type = 'checkbox';
        verifiedBox.name = 'fidoVerified';
        verifiedBox.checked = authenticator['userVerified'];
        verifiedBox.disabled = true;
        verifiedTd.appendChild(verifiedBox);

        var options = { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', timeZoneName:'long' };
        var created = authenticator['created'];
        if(created != null && created != "") {
            var createdDate = new Date(Date.parse(created));
            var createdLocalized = createdDate.toUTCString();
            try {
                createdLocalized = createdDate.toLocaleString(getNavigatorLanguage(), options);
            } catch (e) {
                // Fallback to toUTCString if toLocaleString isn't supported in this browser.
            }
            createdTd.textContent = createdLocalized ? createdLocalized : created;
        }

        var lastUsed = authenticator['lastUsed'];
        if(lastUsed != null && lastUsed != "") {
            var lastUsedDate = new Date(Date.parse(lastUsed));
            var lastUsedLocalized = lastUsedDate.toUTCString();
            try {
                lastUsedLocalized = lastUsedDate.toLocaleString(getNavigatorLanguage(), options);
            } catch (e) {
                // Fallback to toUTCString if toLocaleString isn't supported in this browser.
            }
            lastUsedTd.textContent = lastUsedLocalized ? lastUsedLocalized : lastUsed;
        }

        deleteTd.style = "padding:0px;";
        var deleteInput = document.createElement('input');
        deleteInput.classList = "button-1 ease-in-anim-fast";
        deleteInput.type = "button";
        deleteInput.style = "margin:8px;";
        deleteInput.id = authenticator['credentialId'];
        deleteInput.onclick = function(){ deleteFIDOAuthenticator(this.id); return false; };
        deleteInput.value = mgmtMsg.removeString;
        deleteTd.appendChild(deleteInput);

        if(window.location.hostname.includes(rpId) && optionsString.includes(rpId)) {
            var testInput = document.createElement('input');
            testInput.classList = "button-1 ease-in-anim-fast";
            testInput.type = "button";
            testInput.style = "margin:8px;";
            testInput.id = authenticator['credentialId'];
            testInput.onclick = function(){ testFIDOAuthenticator(this.id); return false; };
            testInput.value = testString;
            deleteTd.appendChild(testInput);
        }
    }
}

function createU2FTokensTable(response) {
    var table = document.getElementById("u2fTokenTable");
    
    var tokens = response.tokens;

    for(var i = 0; tokens && i < tokens.length; i++) {
        var token = tokens[i];
        var tr = table.insertRow(-1);

        var idTd = tr.insertCell(-1);
        var nameTd = tr.insertCell(-1);
        var appIdTd = tr.insertCell(-1);
        var enabledTd = tr.insertCell(-1);
        var deleteTd = tr.insertCell(-1);

        var id = token['id'];
        if(id != null && id != "") {
            idTd.innerHTML = id;
        }

        var name = token['name'];
        if(name != null && name != "") {
            nameTd.textContent = name;
        }

        var appId = token['app_id'];
        if(appId != null && appId != "") {
            appIdTd.textContent = appId;
        }

        var enabledBox = document.createElement('input');
        enabledBox.type = 'checkbox';
        enabledBox.name = 'enabled';
        enabledBox.checked = token['enabled'];
        enabledBox.id = token['id'];
        enabledBox.onclick = function () { enableToken(this.id, this.checked); };
        enabledTd.appendChild(enabledBox);

        var a = document.createElement('a');
        a.id = token['id'];
        a.onclick = function(){ deleteU2FToken(this.id); return false; };
        a.href = "";
        a.innerHTML = mgmtMsg.removeString;
        deleteTd.appendChild(a);

        var u2fToken = {
            keyHandle: token['key_handle'],
            version:   registerRequest.version,
            appId:     token['app_id']
        };
        u2fTokens.push(u2fToken);
    }
}

function deleteClient(clientUri) {
    makeJsonAjaxRequest("DELETE", clientUri, processDeleteRequest, null);
}

function deleteDevice(deviceId) {
    makeAjaxRequest("DELETE", deviceBaseUrl + "/" + deviceId, processDeleteRequest, null);
}

function deleteGrant(grantId) {
    makeAjaxRequest("DELETE", grantBaseUrl + "/" + grantId, processDeleteRequest, null);
}

function deleteAuthenticator(authenticatorId) {
    makeAjaxRequest("DELETE", authenticatorsBaseUrl + "/" + authenticatorId, processDeleteRequest, null);
}

function deleteFIDOAuthenticator(credId) {
    clearFIDOError();

    var fidoStorage = window.localStorage;
    var fidoUsersObject = JSON.parse(fidoStorage.getItem('fidoUsersObject'));
    if (fidoUsersObject != null) {
        var fidoUsers = fidoUsersObject.fidoUsers;

        // Only attempt removal if we have a browser storage item that matches the cred ID.
        console.log("Attempting to remove registration [" + credId + "] from local storage.");

        var removedRego = fidoUsers.filter(fidoUser => fidoUser.rawId === credId);
        fidoUsersObject.fidoUsers = fidoUsers.filter(fidoUser => fidoUser.rawId !== credId);

        if(removedRego.length > 0 && removedRego[0].username == fidoUsersObject.mostRecent) {
            delete fidoUsersObject.mostRecent;
        }

        fidoStorage.setItem('fidoUsersObject', JSON.stringify(fidoUsersObject));
    }

    makeAjaxRequest("DELETE", fidoAuthenticatorsBaseUrl + "/" + credId, processDeleteRequest, null);
}

function deleteU2FToken(tokenId) {
    var json = {"action":"unregister", "id":tokenId};
    makeJsonAjaxRequest("PUT", registerRequest.location, processDeleteRequest, JSON.stringify(json));
}

function processDeleteRequest(deleteRequest) {
    if(deleteRequest.readyState == 4 && (deleteRequest.status ==200 ||
            deleteRequest.status == 204)) {
        if(deleteRequest.responseText == "Not found") {
        } else {
            location.reload();
        }
    }
}

function enableDevice(deviceId, enabled) {
    var json = {};
    json['isEnabled'] = enabled;
    makeAjaxRequest("PUT", deviceBaseUrl + "/" + deviceId, processEnableRequest, JSON.stringify(json));
}

function enableGrant(grantId, enabled) {
    var json = {};
    json['isEnabled'] = enabled;
    makeAjaxRequest("PUT", grantBaseUrl + "/" + grantId, processEnableRequest, JSON.stringify(json));
}

function enableToken(tokenId, enabled) {
    var json = {"action":"update", "id":tokenId, "enabled":enabled};
    makeJsonAjaxRequest("PUT", registerRequest.location, processU2FEnableRequest, JSON.stringify(json));
}

function processEnableRequest(enableRequest) {
    if(enableRequest.readyState == 4 && enableRequest.status ==200) {
        if(enableRequest.responseText == "Not found") {
        } else {
            var json = JSON.parse(enableRequest.responseText);
            window.alert(json['result']);
        }
    }
}

function checkIfIE(){
    var ie = false;
    var ua = window.navigator.userAgent;
    var old_ie = ua.indexOf('MSIE ');
    var new_ie = ua.indexOf('Trident/');

    if ((old_ie > -1) || (new_ie > -1)) {
    ie = true;
    }

    return ie;
}

function registerAuthenticator() {
    var clientID = document.getElementById("oauthClientSelection").value;

    if (clientID == undefined || clientID.length == 0) {
        clientID = "AuthenticatorClient";  // Default client ID
    }

    var codeURL = authorizeUrl + "?client_id=" + clientID + "&response_type=code&scope=mmfaAuthn";

    if (checkIfIE()){
        window.location.href = codeURL;
    }else{
        qrCodeRequest = new XMLHttpRequest();
        qrCodeRequest.onreadystatechange = processRegisterRequest;

        qrCodeRequest.open("GET", codeURL, true);
        qrCodeRequest.send(null);
    }
}

function processRegisterRequest() {
    if(qrCodeRequest.readyState == 4 && qrCodeRequest.status ==200) {
        if(qrCodeRequest.responseText == "Not found") {
        } else {
            window.location.href = qrCodeRequest.responseURL;
        }
    }
}

function getNavigatorLanguage() {
    if (navigator.languages && navigator.languages.length) {
        return navigator.languages[0];
    } else {
        return navigator.userLanguage || navigator.language || navigator.browserLanguage || 'en';
    }
}

window.onclick = function(event) {
    if(event.target == document.getElementById("fido2RegistrationPopup")) {
        document.getElementById("fido2RegistrationPopup").style.display = "none";
    }
    if(event.target == document.getElementById("fido2TestPopup")) {
        document.getElementById("fido2TestPopup").style.display = "none";
    }
    if(event.target == document.getElementById("namePopup")) {
        document.getElementById("namePopup").style.display = "none";
    }
}

window.onkeydown = function(event) {
    // keycode 27 is escape
    if(event.keyCode == 27) {
        document.getElementById("fido2RegistrationPopup").style.display = "none";
        document.getElementById("fido2TestPopup").style.display = "none";
        document.getElementById("namePopup").style.display = "none";
        document.getElementById("registrationPopup").style.display = "none";
    }
};

function getOS() {
    var OSName="Unknown OS";
    if (navigator.appVersion.indexOf("Win")!=-1) OSName="Windows";
    if (navigator.appVersion.indexOf("Mac")!=-1) OSName="MacOS";
    if (navigator.appVersion.indexOf("X11")!=-1) OSName="UNIX";
    if (navigator.appVersion.indexOf("Linux")!=-1) OSName="Linux";
    return OSName;
}

function startup() {

    initialisePage();

    document.getElementById("registerAuthenticatorButton").addEventListener("click", registerAuthenticator);
    document.getElementById("registerFIDOAuthenticatorButton").addEventListener("click", registerFIDOAuthenticator);
    document.getElementById("showU2fButton").addEventListener("click", showU2F);
    document.getElementById("registerTokenButton").addEventListener("click", registerToken);
    document.getElementById("submitRegOptionsButton").addEventListener("click", submitRegOptions);
    document.getElementById("cancelFIDORegistrationButton").addEventListener("click", cancelFIDORegistration);
    document.getElementById("submitButton").addEventListener("click", submit);
    document.getElementById("cancel").addEventListener("click", cancel);
    document.getElementById("friendlyName").addEventListener("keyup", validateName);
    document.getElementById("nickname").addEventListener("keyup", validateFIDONickname);
    document.getElementById("submitFIDOButton").addEventListener("click", submitFIDONickname);
    document.getElementById("cancelFIDORegistrationButton2").addEventListener("click", cancelFIDORegistration);
    document.getElementById("registrationDoneButton").addEventListener("click", function(event) {
        location.reload();
    });
    document.getElementById("testDoneButton").addEventListener("click", function(event) {
        location.reload();
    });
    document.getElementById("clearFidoStorageButton").addEventListener("click", clearFIDOStorage);
    document.getElementById("submitFIDOClearButton").addEventListener("click", submitFIDOClear);
    document.getElementById("cancelFIDOClearButton").addEventListener("click", cancelFIDOClear);

    var jsLinks = document.querySelectorAll('[href="#"]');

    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }
}