window.addEventListener("load", startup);

var infoassertJSON = JSON.parse(document.getElementById('im_fido_assertion_tags').textContent);
var info_assert_dataTag = document.currentScript.dataset;

var info_assert_rpId = info_assert_dataTag.fidoRpId;
var info_assert_timeout = info_assert_dataTag.fidoTimeout;
var info_assert_challenge = info_assert_dataTag.fidoChallenge;
var info_assert_allowCredentials = infoassertJSON["fidoAllowCredentials"];
var info_assert_extensions = infoassertJSON["fidoExtension"];
var info_assert_userVerification = info_assert_dataTag.fidoUserVerification;
var info_assert_userId = info_assert_dataTag.fidoUserId;
var info_assert_status = info_assert_dataTag.fidoStatus;
var info_assert_errorMessage = info_assert_dataTag.fidoErrorMessage;
var info_assert_apiUrl = getJunctionName() + info_assert_dataTag.action;

// Some browsers have a restriction where the navigator.credentials.get call cannot be
// initiated from an automatic action like onload but instead must be called from a
// user initiated action like a button.
// The following boolean can be used to control whether the button to trigger
// navigator.credentials.get is always shown (false), or whether the button should be
// only shown for browsers that have the user-initiation restriction (true).
var info_assert_browserCheck = false;

var info_assert_publicKey = null;

function cancel() {
    document.getElementById("cancelForm").submit();
}


function base64URLEncode(bytes, encoding = 'utf-8') {
    if (bytes == null || bytes.length == 0) {
        return null;
    }
    var str = base64js.fromByteArray(new Uint8Array(bytes));
    str = str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    return str;
}

function base64URLDecode(str, encoding = 'utf-8') {
    if (str == null || str == "") {
        return null;
    }

    var str = str.replace(/-/g, '+').replace(/_/g, '\/');

    var pad = str.length % 4;
    if (pad) {
        str += new Array(5 - pad).join('=');
    }

    var bytes = base64js.toByteArray(str);
    return bytes.buffer;
}

function populateStrings() {
    document.title = authsvcMsg.fido2Authentication;
    document.querySelector('#assertion-section h1').textContent = authsvcMsg.twoStepVerification;
    document.getElementById("instructions").textContent = authsvcMsg.fido2ReadyInstructions;
    document.getElementById("loginButton").value = authsvcMsg.letsGo;

    document.querySelector("#error-section h1").textContent = authsvcMsg.errorLabel;

    document.getElementById("error_img").src = getJunctionName() + "/sps/static/design_images/u2f_error.svg";
    document.getElementById("welcome_img").src = getJunctionName() + "/sps/static/design_images/u2f_device.svg";
}

function optionsGet() {

    if (!info_assert_apiUrl.includes("apiauthsvc")) {
        info_assert_apiUrl = info_assert_apiUrl.replace("authsvc", "apiauthsvc");
    }

    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {

        if (request.readyState == 4) {
            if (request.responseText) {

                var json = null;
                try {
                    json = JSON.parse(request.responseText);
                } catch (e) {
                    // we got a 200, but not valid JSON - that's an error
                    showError(authsvcMsg.badOptionsRequest);
                }

                if (json != null) {

                    if (json.stateId != null) {
                        document.getElementById("assertionForm").StateId.value = json.stateId;
                    }

                    if (json.location != null) {
                        document.getElementById("cancelForm").action = json.location.replace("apiauthsvc", "authsvc") + "&operation=cancel";
                        document.getElementById("assertionForm").action = json.location.replace("apiauthsvc", "authsvc") + "&fidoInfoMap=assertionResult";
                        info_assert_apiUrl = json.location;
                    }

                    if (request.status == 200) {

                        info_assert_rpId = json.rpId;
                        info_assert_timeout = json.timeout;
                        info_assert_challenge = json.challenge;
                        info_assert_allowCredentials = json.allowCredentials;
                        info_assert_extensions = json.extensions;
                        info_assert_userVerification = json.userVerification;
                        info_assert_userId = json.userId;

                        buildOptions();

                        credentialsGet();

                    } else {
                        // Response wasn't a 200. Show error.
                        var errorMsg = authsvcMsg.badOptionsRequest;
                        if (json.error != null) {
                            errorMsg = json.error;
                        } else if (json.errorMessage != null) {
                            errorMsg = json.errorMessage;
                        } else if (json.exceptionMsg != null) {
                            errorMsg = json.exceptionMsg;
                        }
                        showError(errorMsg);
                    }

                } else {
                    // Response isn't json. Very weird. Show error.
                    showError(authsvcMsg.badOptionsRequest);
                }
            } else {
                // No response text. Very weird. Show error.
                showError(authsvcMsg.badOptionsRequest);
            }
        } else {
            // readyState is not 4, that's ok, just continue.
        }
    };

    request.open("POST", info_assert_apiUrl);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");
    request.send(JSON.stringify({
        "fidoInfoMap": "assertionOptions"
    }));

}

function buildOptions() {

    var extensions = {};
    if (info_assert_extensions != null && info_assert_extensions != "") {
        extensions = info_assert_extensions;
    }

    info_assert_publicKey = {
        "rpId": info_assert_rpId,
        "timeout": parseInt(info_assert_timeout),
        "challenge": base64URLDecode(info_assert_challenge),
        "extensions": extensions,
        "userId": info_assert_userId
    };

    if (info_assert_userVerification != null && info_assert_userVerification != "") {
        info_assert_publicKey.userVerification = info_assert_userVerification;
    }

    var allowCredentials = [];
    if (info_assert_allowCredentials != null) {
        var allowCredentialsJson = info_assert_allowCredentials;
        if (allowCredentialsJson.length > 0) {
            for (i in allowCredentialsJson) {
                allowCredentialsJson[i].id = base64URLDecode(allowCredentialsJson[i].id);
                allowCredentials.push(allowCredentialsJson[i]);
            }
        }

        info_assert_publicKey.allowCredentials = allowCredentials;
    }
}

function credentialsGet() {
    document.getElementById("loginButton").disabled = true;
    let publicKey = info_assert_publicKey;

    navigator.credentials.get({
        publicKey
    }).then(function(assertion) {

        var assertionForm = document.getElementById("assertionForm");
        assertionForm.id.value = assertion.id;
        assertionForm.rawId.value = base64URLEncode(assertion.rawId);
        assertionForm.clientDataJSON.value = base64URLEncode(assertion.response.clientDataJSON);
        assertionForm.authenticatorData.value = base64URLEncode(assertion.response.authenticatorData);
        assertionForm.signature.value = base64URLEncode(assertion.response.signature);
        assertionForm.userHandle.value = base64URLEncode(assertion.response.userHandle);
        assertionForm.type.value = assertion.type;
        assertionForm.getClientExtensionResults.value = JSON.stringify(assertion.getClientExtensionResults());
        assertionForm.authenticatorAttachment.value = assertion.authenticatorAttachment;
        assertionForm.submit();
        document.getElementById("loginButton").disabled = false;

    }).catch(function(err) {
        document.getElementById("loginButton").disabled = false;
        showError(err);
    });
}

function retry() {
    document.getElementById("error-section").classList.remove('bx--dialog-content--visible');
    document.getElementById("error-section").classList.add('bx--dialog-content--hidden');
    setTimeout(function() {
        document.getElementById("error-section").style.left = '100%';
    }, 300);
    document.getElementById("assertion-section").style.left = '';
    document.getElementById("assertion-section").classList.add('bx--dialog-content--visible');
    document.getElementById("assertion-section").classList.remove('bx--dialog-content--hidden');

    if (info_assert_browserCheck && !info_assert_isSafari) {
        optionsGet();
    }
}

function showError(errMsg) {
    document.getElementById("assertion-section").classList.remove('notransition');
    document.getElementById("assertion-section").classList.remove('bx--dialog-content--visible');
    document.getElementById("assertion-section").classList.add('bx--dialog-content--hidden');
    setTimeout(function() {
        document.getElementById("assertion-section").style.left = '-100%';
    }, 300);
    document.getElementById("error-section").style.left = '';
    document.getElementById("error-section").classList.add('bx--dialog-content--visible');
    document.getElementById("error-section").classList.remove('bx--dialog-content--hidden');
    document.getElementById("errorMessage").textContent = errMsg;
}

// Safari 3.0+ "[object HTMLElementConstructor]"
var info_assert_isSafari = /constructor/i.test(window.HTMLElement) || (function(p) {
    return p.toString() === "[object SafariRemoteNotification]";
})(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));


function startup() {
    populateStrings();

    buildOptions();

    if (info_assert_browserCheck && !info_assert_isSafari) {
        document.getElementById("loginButton").classList.add("hidden");
        optionsGet();
    }

    document.getElementById("loginButton").addEventListener("click", optionsGet);

    document.getElementById("cancelButton").addEventListener("click", cancel);
    document.getElementById("cancelButton").style = "background-image: url('/'" + getJunctionName() + "'/sps/static/design_images/back-light.svg');";

    document.getElementById("retryButton").addEventListener("click", retry);
    document.getElementById("retryButton").style = "background-image: url('/'" + getJunctionName() + "'/sps/static/design_images/back-light.svg');";

    var jsLinks = document.querySelectorAll('[href="#"]');

    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }
}
