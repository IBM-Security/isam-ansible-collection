var contentSectionHistory,
modalBackButton,
modalCloseButton,
backButtons,
sectionLinks,
formLabel,
footerNav,
standardDropdown,
sectionLinks,
modalOverlay,
modalWindow,
ibmsyModal,
openModal;

var animationDurationShort = 100;
var animationDurationStandard = 300;
var animationFunctionEaseOut = 'cubic-bezier(.1, .6, .15, 1)';
var animationFunctionEaseIn = 'cubic-bezier(.85, 0, .9, .4)';
var animationFunctionEaseInOut = 'cubic-bezier(.5, 0, .15, 1)';

var readyFunction = function () {
  backButtons = document.querySelectorAll('.ibmsy-nav-sectionlink-back');
  sectionLinks = document.querySelectorAll('.ibmsy-nav-sectionlink');
  modalBackButton = document.querySelector('.ibmsy-modal-back');
  formLabel = document.querySelector('.ibmsy-form label');
  footerNav = document.querySelector('.ibmsy-footer-nav');
  standardDropdown = document.getElementById('standardDropdown');
  modalCloseButton = document.querySelector('.ibmsy-modal-close');
  modalOverlay = document.querySelector('.ibmsy-overlay');
  modalWindow = document.querySelector('.ibmsy-modal-window');
  ibmsyModal = document.querySelector('#ibmsy-modal');
  openModal = document.querySelector('.ibmsy-open-modal');
  openModalRegistered = document.querySelector('.ibmsy-open-modal-registered');
  openModalTransactions = document.querySelector('.ibmsy-open-modal-transactions');
  openModalAuthenticators = document.querySelector('.ibmsy-open-modal-authenticators');
  openModalPassword = document.querySelector('.ibmsy-open-modal-password');

  contentSectionHistory = [];


  if (openModal) {
    openModal.addEventListener('click', function (event) {
	  showContentSection('section-welcome');
      event.preventDefault();
      modalOverlay.classList.remove('closeOverlay');
      modalWindow.classList.remove('closeWindow');
      ibmsyModal.style.display = 'block';
    });
  }
  
  if (openModalRegistered != null){
	  openModalRegistered.addEventListener('click', function (event) {
	    showContentSection('verify-screen');
	    event.preventDefault();
	    modalOverlay.classList.remove('closeOverlay');
	    modalWindow.classList.remove('closeWindow');
	    ibmsyModal.style.display = 'block';
	    modalBackButton.style.display = 'none';
	  });
	  }

  if (openModalTransactions != null){
  openModalTransactions.addEventListener('click', function (event) {
    showContentSection('section-welcome-transactions');
    event.preventDefault();
    modalOverlay.classList.remove('closeOverlay');
    modalWindow.classList.remove('closeWindow');
    ibmsyModal.style.display = 'block';
    modalBackButton.style.display = 'none';
  });
  }
  

  if (openModalAuthenticators != null){
  openModalAuthenticators.addEventListener('click', function (event) {
    showContentSection('section-welcome-authenticators');
    event.preventDefault();
    modalOverlay.classList.remove('closeOverlay');
    modalWindow.classList.remove('closeWindow');
    ibmsyModal.style.display = 'block';
    modalBackButton.style.display = 'none';
    if (typeof socket_interval != "undefined" && socket_interval != null){
      	clearInterval(socket_interval);			
    }
    if (typeof authsvc_interval != "undefined" && authsvc_interval != null){
        clearInterval(authsvc_interval);		
    }
  });
  }
  
  if (openModalPassword != null){
	  openModalPassword.addEventListener('click', function (event) {
	    showContentSection('section-welcome-logout');
	    event.preventDefault();
	    modalOverlay.classList.remove('closeOverlay');
	    modalWindow.classList.remove('closeWindow');
	    ibmsyModal.style.display = 'block';
	    modalBackButton.style.display = 'none';
	    if (typeof socket_interval != "undefined" && socket_interval != null){
	      	clearInterval(socket_interval);			
	    }
	    if (typeof authsvc_interval != "undefined" && authsvc_interval != null){
	        clearInterval(authsvc_interval);		
	    }
	  });
	  }

  modalCloseButton.addEventListener('click', function (event) {
    event.preventDefault();

    closeAndCleanup();
  });
  
  if (typeof modalOverlay != "undefined" && modalOverlay != null){
	  modalOverlay.addEventListener('click', function (event) {
		    event.preventDefault();
	
		    closeAndCleanup();
	  });
  }

  Array.prototype.forEach.call(sectionLinks, function (thisLink) {
    thisLink.addEventListener('click', function (event) {
      event.preventDefault();
      var targetSection = thisLink.getAttribute('data-target');
      showContentSection(targetSection);
    });
  });

  Array.prototype.forEach.call(backButtons, function (thisButton) {
    thisButton.addEventListener('click', function (event) {
      event.preventDefault();
      previousContentSection();
      if (typeof socket_interval != "undefined" && socket_interval != null){
      	clearInterval(socket_interval);			
      }
      if (typeof authsvc_interval != "undefined" && authsvc_interval != null){
	        clearInterval(authsvc_interval);		
	    }
    });
  });

  if (standardDropdown) {
    function dropdownCallback(selectedValue) {
      //console.log(selectedValue);
    }

    standardDropdown.Dropdown({
      callback: dropdownCallback,
    });
  }
}

function closeAndCleanup(){
	if (typeof updateHTML != "undefined"){
		ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, updateHTML);
	}
	if (typeof displayTransactionsTable != "undefined"){
		ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, displayTransactionsTable);
	}
	
	$("#transfer_mmfa").val("");	

	if (ws != null && ws != "undefined"){
			ws.close();
	}
	
	var resent_spinner = $('td[id^="transaction-delete-"] #cancel');
	if (resent_spinner != "undefined" && resent_spinner != null && resent_spinner != []){
		var img = $(resent_spinner).children("div");
		$(img).removeClass("hidden");
		var img = $(resent_spinner).children("img");
		$(img).addClass("hidden");
	}
	
	retry = false;
	if (modalOverlay != null){
		modalOverlay.classList.add('closeOverlay');
	}
	if (modalWindow != null){
    modalWindow.classList.add('closeWindow');
	}
	
    setTimeout(function() {
        ibmsyModal.style.display = 'none';
    }, 250);
    
    contentSectionHistory = [];
    var hiddenSections = document.querySelectorAll('.ibmsy-modal-content--hidden');
    var visibleSections = document.querySelectorAll('.ibmsy-modal-content--visible');
    var hiddenAnimations = document.querySelectorAll('.ibmsy-example-animation--hidden');
    var visibleAnimations = document.querySelectorAll('.ibmsy-example-animation--visible');
    
    
    Array.prototype.forEach.call(hiddenSections, function (hiddenSection) {
    	//console.log("hiddenSection");
    	hiddenSection.classList.remove('ibmsy-modal-content--hidden');
    });
    
    Array.prototype.forEach.call(visibleSections, function (visibleSection) {
    	//console.log("visibleSection");
    	visibleSection.classList.remove('ibmsy-modal-content--visible');
    });
    
    Array.prototype.forEach.call(hiddenAnimations, function (hiddenAnimation) {
    	//console.log("hiddenSection");
    	hiddenAnimation.classList.remove('ibmsy-example-animation--hidden');
    });
    
    Array.prototype.forEach.call(visibleAnimations, function (visibleAnimation) {
    	//console.log("visibleSection");
    	visibleAnimation.classList.remove('ibmsy-example-animation--visible');
    });

    if (typeof socket_interval != "undefined" && socket_interval != null){
    	clearInterval(socket_interval);			
    }
    if (typeof authsvc_interval != "undefined" && authsvc_interval != null){
        clearInterval(authsvc_interval);		
    }
}

function ready(fn) {
	if (document.readyState != 'loading') {
		fn();
	} else {
		document.addEventListener('DOMContentLoaded', fn);
	}
}

function showContentSection (contentSectionName) {
  var incomingSection = document.querySelector('[data-name="' + contentSectionName + '"]');
  var outgoingSection = document.querySelector('.ibmsy-modal-content--visible');
  if (incomingSection == outgoingSection && contentSectionHistory != ""){
	  //console.log("The same pane or empty - not transitioning");
  }else{
	  triggerTransition(incomingSection, outgoingSection, 'forward');
  }
};

function previousContentSection() {
  var welcomeSection = document.querySelector('[data-name="section-welcome"]');
  if (welcomeSection && welcomeSection.classList.contains('ibmsy-modal-content--more-info-visible')) {
	contentSectionHistory = [];
    welcomeSection.classList.remove('ibmsy-modal-content--more-info-visible');
    modalBackButton.style.display = 'none';
    modalCloseButton.classList.add('ibmsy-modal-close--dark');
    footerNav.style.display = 'block';
    return;
  }
  var welcomeSectionTransactions = document.querySelector('[data-name="section-welcome-transactions"]');
  if (welcomeSectionTransactions && welcomeSectionTransactions.classList.contains('ibmsy-modal-content--more-info-visible')) {
	contentSectionHistory = [];
	welcomeSectionTransactions.classList.remove('ibmsy-modal-content--more-info-visible');
    modalBackButton.style.display = 'none';
    modalCloseButton.classList.add('ibmsy-modal-close--dark');
    footerNav.style.display = 'block';
    return;
  }

  var previousSectionName = contentSectionHistory.pop();
  var outgoingSection = document.querySelector('.ibmsy-modal-content--visible');
  var incomingSection = document.querySelector('[data-name="' + previousSectionName + '"]');
  triggerTransition(incomingSection, outgoingSection, 'back');
}

function triggerTransition(incomingSection, outgoingSection, direction) {
  if (outgoingSection && incomingSection.querySelector('.ibmsy-layout-left') && outgoingSection.querySelector('.ibmsy-layout-left')) {
    performTwoPaneAnimation(incomingSection, outgoingSection, direction);
  } else {
    performSlideAnimation(incomingSection, outgoingSection, direction);
  }

  if (contentSectionHistory.length === 0 || incomingSection.getAttribute('data-name') === 'section-confirmation' || incomingSection.getAttribute('data-name') === 'section-confirmationfailed' || incomingSection.getAttribute('data-name') === 'section-welcome') {
    modalBackButton.style.display = 'none';
  } else {
    modalBackButton.style.display = 'block';
  }

  if (!incomingSection.querySelector('.ibmsy-layout-left')) {
    modalCloseButton.classList.add('ibmsy-modal-close--dark');
  } else {
    modalCloseButton.classList.remove('ibmsy-modal-close--dark');
  }

  if (incomingSection.getAttribute('data-name') === 'section-confirmation' || incomingSection.getAttribute('data-name') === 'section-confirmationfailed') {
    animateConfirmation(incomingSection);
  }

  if (incomingSection.getAttribute('data-name') === 'section-connectaccount' && window.innerWidth <= '768') {
    swapConnectMethod();
  }

  if (incomingSection.getAttribute('data-name') === 'section-complete' || incomingSection.getAttribute('data-name') === 'section-confirmation' || incomingSection.getAttribute('data-name') === 'section-confirmationfailed') {
    modalCloseButton.style.display = 'none';
    modalBackButton.style.display = 'none';
  }
  else {
    modalCloseButton.style.display = 'block';
  }

  if (incomingSection.getAttribute('data-name') === 'section-accesscode') {
    setTimeout(function () { incomingSection.querySelector('[tabindex="1"]').focus(); }, animationDurationStandard);
  }
}

function performTwoPaneAnimation(incomingSection, outgoingSection, direction) {
  var incomingSectionRightIllustration = incomingSection.querySelector('.ibmsy-example-animation');
  var incomingSectionRightPane = incomingSection.querySelector('.ibmsy-layout-right');
  var incomingSectionLeftPane = incomingSection.querySelector('.ibmsy-layout-left');
  var outgoingSectionRightIllustration = outgoingSection.querySelector('.ibmsy-example-animation');
  var outgoingSectionRightPane = outgoingSection.querySelector('.ibmsy-layout-right');
  var outgoingSectionLeftPane = outgoingSection.querySelector('.ibmsy-layout-left');

  if (direction === 'forward') {
    contentSectionHistory.push(outgoingSection.getAttribute('data-name'));

    // show the incoming section's left pane
    outgoingSectionLeftPane.classList.add('ibmsy-layout-left--hidden');
    outgoingSectionRightIllustration.classList.add('ibmsy-example-animation--hidden');
    incomingSection.style.left = '';
    incomingSection.classList.add('ibmsy-modal-content--visible');
    incomingSectionRightIllustration.classList.add('ibmsy-example-animation--hidden');

    // show the incoming section's illustration
    setTimeout(function () {
      incomingSectionRightIllustration.style.transition = 'all ' + animationDurationStandard + 'ms ' + animationFunctionEaseOut;
      incomingSectionRightIllustration.classList.remove('ibmsy-example-animation--hidden');
      incomingSectionRightIllustration.style.transition = '';
      outgoingSection.classList.remove('ibmsy-modal-content--visible');
    }, animationDurationStandard)

    // cleanup
    setTimeout(function () {
      outgoingSectionLeftPane.classList.remove('ibmsy-layout-left--hidden');
      outgoingSection.classList.add('ibmsy-modal-content--hidden');
      outgoingSection.style.left = '-100%'
    }, animationDurationStandard * 2);

  }
  else if (direction == 'back') {
    // hide the illustration in the outgoing screen
    incomingSection.style.left = '';
    outgoingSectionRightIllustration.style.transition = 'all ' + animationDurationStandard + 'ms ' + animationFunctionEaseIn;
    outgoingSectionRightIllustration.classList.add('ibmsy-example-animation--hidden');
    incomingSectionLeftPane.classList.remove('ibmsy-layout-left--hidden');
    incomingSectionRightPane.classList.add('ibmsy-layout-right--hidden');

    // slide in the incoming section's left pane
    setTimeout(function () {
      incomingSection.classList.remove('ibmsy-modal-content--hidden');
      incomingSection.classList.add('ibmsy-modal-content--visible');
    }, animationDurationStandard);

    // reveal the illustration
    setTimeout(function () {
      incomingSectionRightIllustration.style.transition = 'none'
      incomingSectionRightIllustration.classList.remove('ibmsy-example-animation--hidden');
      incomingSectionRightPane.style.transition = 'opacity ' + animationDurationShort + 'ms ' + animationFunctionEaseOut;
      incomingSectionRightPane.classList.remove('ibmsy-layout-right--hidden');
      // incomingSectionRightIllustration.style.transition = 'opacity ' + animationDurationShort + 'ms ' + animationFunctionEaseOut;
    }, animationDurationStandard * 2)

    // cleanup
    setTimeout(function () {
      incomingSectionRightPane.style.transition = '';

      outgoingSection.classList.remove('ibmsy-modal-content--visible');
      outgoingSection.style.transition = '';

      outgoingSectionRightPane.classList.remove('ibmsy-layout-right--hidden');
      outgoingSectionRightPane.style.transition = '';

      outgoingSectionRightIllustration.classList.remove('ibmsy-example-animation--hidden');
      outgoingSectionRightIllustration.style.transition = '';

      outgoingSectionLeftPane.classList.remove('ibmsy-layout-left--hidden');
      outgoingSectionLeftPane.style.transition = '';
    }, animationDurationStandard * 2 + animationDurationShort);
  } else {
    //console.log('Direction parameter only accepts \'forward\' or \'back.\'');
  }
}

function performSlideAnimation (incomingSection, outgoingSection, direction) {
  if (direction === 'forward') {
    if (outgoingSection) {
      outgoingSection.classList.remove('ibmsy-modal-content--visible');
      outgoingSection.classList.add('ibmsy-modal-content--hidden');
      contentSectionHistory.push(outgoingSection.getAttribute('data-name'));

      setTimeout(function () {
        outgoingSection.style.left = '-100%';
      }, animationDurationStandard);
    }

    incomingSection.style.left = '';
    incomingSection.classList.add('ibmsy-modal-content--visible');

  } else if (direction === 'back') {
    incomingSection.style.left = '';
    incomingSection.classList.remove('ibmsy-modal-content--hidden');
    incomingSection.classList.add('ibmsy-modal-content--visible');
    outgoingSection.classList.remove('ibmsy-modal-content--visible');
  } else {
    //console.log('Direction parameter only accepts \'forward\' or \'back.\'');
  }
}

ready(readyFunction);
