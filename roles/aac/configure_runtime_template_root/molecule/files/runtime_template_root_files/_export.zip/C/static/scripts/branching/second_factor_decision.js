window.addEventListener("load", startup);

var sfd_dataSetValues = document.currentScript.dataset

var sfd_mechanismsMacro = sfd_dataSetValues.mechanisms;
var sfd_mechanisms = [];

var sfd_errorMacro = sfd_dataSetValues.errorMessage;

var sfd_methodsMacro = sfd_dataSetValues.methods;
var sfd_methods = {};

if (sfd_methodsMacro && sfd_methodsMacro.length > 0) {
    sfd_methodsMacro = sfd_methodsMacro.replace(/&quot;/g, "\"");
    sfd_methods = JSON.parse(sfd_methodsMacro);
}

if (sfd_mechanismsMacro && sfd_mechanismsMacro.length > 0) {
    sfd_mechanismsMacro = sfd_mechanismsMacro.replace(/&quot;/g, "\"");
    sfd_mechanisms = JSON.parse(sfd_mechanismsMacro);
}

function createGrid() {

    var verify_method_div = document.getElementById("verify-method-container");
    var fido_method_div = document.getElementById("fido-method-container");
    var kq_method_div = document.getElementById("kq-method-container");


    for (i = 0; i < sfd_methods.length; i++) {
        var method = sfd_methods[i];
        var uri = method["mechanismURI"];

        if (i < 3) {

            // FIDO2
            if (uri == "urn:ibm:security:authentication:asf:mechanism:fido2") {
                setupFIDOMethod(method);
                fido_method_div.appendChild(document.createElement('hr'));
                fido_method_div.classList.remove("hidden");

                // MMFA
            } else if (uri == "urn:ibm:security:authentication:asf:mechanism:mmfa") {
                setupVerifyMethod(method);
                verify_method_div.appendChild(document.createElement('hr'));
                verify_method_div.classList.remove("hidden");

                // Knowledge questions / Q&A
            } else if (uri == "urn:ibm:security:authentication:asf:mechanism:knowledge_questions") {
                var link_div = document.querySelector("#kq-method-container .bx--method-link")

                link_div.onclick = function() {
                    document.querySelector(".bx--layout-left .bx--loader").classList.remove('hidden');
                    document.querySelector(".bx--layout-left .bx--welcome-illustrations .bx--launch-animation").classList.add('hidden');
                    document.getElementById("chooseMethodForm").type.value = "knowledge_questions";
                    document.getElementById("chooseMethodForm").submit();
                };

                link_div.addEventListener("keyup", function(event) {
                    event.preventDefault();
                    // Enter key is 13, space is 32
                    if (event.keyCode === 13 || event.keyCode == 32) {
                        this.click();
                    }
                });

                link_div.textContent = authsvcMsg.letsGo;

                kq_method_div.appendChild(document.createElement('hr'));
                kq_method_div.classList.remove("hidden");

                // TOTP
            } else {
                var policy = uri.substring(uri.lastIndexOf(":") + 1);
                var link_div = document.querySelector("#" + policy + "-method-container .bx--method-link")
                link_div.type = policy;

                link_div.onclick = function() {
                    document.querySelector(".bx--layout-left .bx--loader").classList.remove('hidden');
                    document.querySelector(".bx--layout-left .bx--welcome-illustrations .bx--launch-animation").classList.add('hidden');
                    document.getElementById("chooseMethodForm").type.value = this.type;
                    document.getElementById("chooseMethodForm").submit();
                };

                link_div.textContent = authsvcMsg.enterCode;

                link_div.addEventListener("keyup", function(event) {
                    event.preventDefault();
                    // Enter key is 13, space is 32
                    if (event.keyCode === 13 || event.keyCode == 32) {
                        this.click();
                    }
                });

                var method_div = document.getElementById(policy + "-method-container");
                method_div.appendChild(document.createElement('hr'));
                method_div.classList.remove("hidden");
            }

        } else {
            break;
        }
    }
}

function setupFIDOMethod(fido2_method) {
    var fido_method_div = document.getElementById("fido-method-container");

    var method_div = document.createElement('div');
    method_div.className = "bx--line-method";
    method_div.type = "fido2";

    method_div.onclick = function() {
        document.querySelector(".bx--layout-left .bx--loader").classList.remove('hidden');
        document.querySelector(".bx--layout-left .bx--welcome-illustrations .bx--launch-animation").classList.add('hidden');
        document.getElementById("chooseMethodForm").type.value = this.type;
        document.getElementById("chooseMethodForm").submit();
    };

    method_div.addEventListener("keyup", function(event) {
        event.preventDefault();
        // Enter key is 13, space is 32
        if (event.keyCode === 13 || event.keyCode == 32) {
            this.click();
        }
    });

    var type_and_icon_div = document.createElement('div');
    type_and_icon_div.style = "display: flex;";

    var type_div = document.createElement('div');
    type_div.className = "bx--method-type";
    fido_method_div.appendChild(method_div);

    var nickname = fido2_method["nickname"];
    var icon = "";
    var description = "";
    if (fido2_method["metadata"]) {
        icon = fido2_method["metadata"]["icon"];
        description = fido2_method["metadata"]["description"];
    }

    if (icon && icon.length > 0) {
        var img = document.createElement('img');
        img.style = "width:32px; padding:0px; margin-right:10px;";
        img.src = icon;
        type_and_icon_div.appendChild(img);
    }

    if (description && description.length > 0) {
        nickname = nickname + " - " + description;
    }

    type_div.textContent = nickname;
    type_and_icon_div.appendChild(type_div);
    method_div.appendChild(type_and_icon_div);

    var link_div = document.createElement('a');
    link_div.className = "bx--method-link";
    link_div.href = "#";
    link_div.textContent = ciMsg.authenticate;
    link_div.type = "fido2";

    link_div.addEventListener("click", function(event) {
        event.preventDefault(); // Prevent default action (a following a link)
    }, false);

    method_div.appendChild(link_div);
}

function setupVerifyMethod(verify_method) {
    var verify_method_div = document.getElementById("verify-method-container");

    var enabled = verify_method['enabled'];
    if (enabled) {

        var method_div = document.createElement('div');
        method_div.className = "bx--line-method";
        method_div.id = verify_method['authenticatorId'];
        method_div.type = "mmfa";

        method_div.onclick = function() {
            document.querySelector(".bx--layout-left .bx--loader").classList.remove('hidden');
            document.querySelector(".bx--layout-left .bx--welcome-illustrations .bx--launch-animation").classList.add('hidden');
            document.getElementById("chooseMethodForm").id.value = this.id;
            document.getElementById("chooseMethodForm").type.value = this.type;
            document.getElementById("chooseMethodForm").submit();
        };

        method_div.addEventListener("keyup", function(event) {
            event.preventDefault();
            // Enter key is 13, space is 32
            if (event.keyCode === 13 || event.keyCode == 32) {
                this.click();
            }
        });

        var type_div = document.createElement('div');
        type_div.className = "bx--method-type";
        var description = verify_method['deviceName'] + ' (' + verify_method['deviceType'] + " " + (verify_method['deviceType'].startsWith("i") ? ciMsg.ios + " " : ciMsg.android + " ") + verify_method['osVersion'] + ')';
        type_div.textContent = description
        method_div.appendChild(type_div);

        var link_div = document.createElement('a');
        link_div.className = "bx--method-link";
        link_div.href = "#";
        link_div.textContent = ciMsg.sendPush;

        link_div.addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);

        method_div.appendChild(link_div);

        verify_method_div.appendChild(method_div);
    }
}

function populateStrings() {
    document.title = ciMsg.authMethodSelection;
    document.querySelector('h3').textContent = ciMsg.twoStepVeri;
    document.querySelector('h1').textContent = ciMsg.chooseAMethod;
    document.getElementById('verify-question').textContent = ciMsg.howToVerify;
    document.querySelector('#fido-method-container b').textContent = ciMsg.fido2;
    document.querySelector('#verify-method-container b').textContent = ciMsg.ibmVerifyApp;
    document.querySelector('#sms-method-container b').textContent = ciMsg.textMessage;
    document.querySelector('#email-method-container b').textContent = ciMsg.email;
    document.querySelector('#totp-method-container b').textContent = ciMsg.totpApp;
    document.querySelector('#hotp-method-container b').textContent = ciMsg.hotpApp;
    document.querySelector('#kq-method-container b').textContent = authsvcMsg.knowledgeQuestions;
    document.getElementById('warning').textContent = authsvcMsg.fileUpdateMessage;
}

function startup() {
    populateStrings();
    createGrid();

    var jsLinks = document.querySelectorAll('[href="#"]');

    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }
}
