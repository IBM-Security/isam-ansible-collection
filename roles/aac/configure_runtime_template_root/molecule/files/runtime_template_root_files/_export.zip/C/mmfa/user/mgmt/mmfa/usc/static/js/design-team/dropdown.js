'use strict';

// Dropdown

(function () {
  function generateOptions(element, options) {
    var ELEMENT = element;
    ELEMENT.dropdownOptions = options || {};
  }

  function updateDropdownValue(dropdown, value) {
    var DROPDOWN = dropdown;

    DROPDOWN.selectedIndex = value;
    var IS_VALUE = value > -1;
    DROPDOWN.DROPDOWN_LABEL.innerHTML = IS_VALUE ? DROPDOWN.options[value].value : DROPDOWN.PLACEHOLDER;

    if (!IS_VALUE && DROPDOWN.selectedListItem) {
      DROPDOWN.selectedListItem.removeAttribute('data-state');
      DROPDOWN.selectedListItem = null;
    }
  }

  function createDropdown(dropdown, options) {
    var DROPDOWN = dropdown;
    var DROPDOWN_TYPE = DROPDOWN.getAttribute('data-dropdown');
    DROPDOWN.isDropdown = true;

    generateOptions(DROPDOWN, options);

    var CONTAINER = document.createElement('div');
    CONTAINER.setAttribute('class', 'dg-dropdown' + (DROPDOWN_TYPE ? '--' + DROPDOWN_TYPE : ''));

    DROPDOWN.parentNode.insertBefore(CONTAINER, DROPDOWN);

    CONTAINER.appendChild(DROPDOWN);

    var DROPDOWN_BUTTON = document.createElement('button');
    DROPDOWN.DROPDOWN_LABEL = document.createElement('span');
    var DROPDOWN_ARROW = document.createElement('span');

    var dropdownWidth = 0;
    var dropdownHeight = 0;
    var isDropdownOpen = false;

    DROPDOWN.selectedListItem = null;
    DROPDOWN.PLACEHOLDER = DROPDOWN.getAttribute('data-placeholder') ? DROPDOWN.getAttribute('data-placeholder') : DROPDOWN.options[0].innerHTML;

    var UL = document.createElement('ul');
    UL.setAttribute('class', 'dg-dropdown__list');
    CONTAINER.appendChild(UL);

    function setDropdownHeight() {
      UL.style.height = isDropdownOpen ? dropdownHeight + 'px' : 0;
    }

    function toggleDropdown(event) {
      event.stopPropagation();
      isDropdownOpen = !isDropdownOpen;
      var DROPDOWN_STATE = isDropdownOpen ? 'active' : false;

      var EVENT_LISTENER = isDropdownOpen ? 'add' : 'remove';
      document[EVENT_LISTENER + 'EventListener']('click', toggleDropdown);

      DROPDOWN_ARROW.setAttribute('data-state', DROPDOWN_STATE);
      UL.setAttribute('data-state', DROPDOWN_STATE);

      setDropdownHeight();
    }

    function createDropdownLabel() {
      DROPDOWN_BUTTON.setAttribute('class', 'dg-dropdown__button');
      DROPDOWN_BUTTON.setAttribute('type', 'button');
      DROPDOWN_BUTTON.addEventListener('click', toggleDropdown);

      DROPDOWN.DROPDOWN_LABEL.setAttribute('class', 'dg-dropdown__label');
      DROPDOWN_ARROW.setAttribute('class', 'dg-dropdown__arrow');

      DROPDOWN_BUTTON.appendChild(DROPDOWN.DROPDOWN_LABEL);
      DROPDOWN_BUTTON.appendChild(DROPDOWN_ARROW);
      CONTAINER.appendChild(DROPDOWN_BUTTON);
    }

    createDropdownLabel();

    function calculateDropdownDimensions(listItem) {
      var LI = listItem;

      LI.style.position = 'fixed';
      LI.setAttribute('data-state', 'active');
      dropdownWidth = LI.offsetWidth > dropdownWidth ? LI.offsetWidth : dropdownWidth;
      dropdownHeight += LI.offsetHeight;
      LI.removeAttribute('style');
      LI.removeAttribute('data-state');
    }

    function handleDropdownItemClick(event) {
      if (DROPDOWN.selectedListItem) {
        DROPDOWN.selectedListItem.setAttribute('data-state', false);
      }

      DROPDOWN.selectedListItem = this;

      DROPDOWN.DROPDOWN_LABEL.innerHTML = DROPDOWN.selectedListItem.innerHTML;
      DROPDOWN.value = DROPDOWN.selectedListItem.getAttribute('data-value');

      DROPDOWN.selectedListItem.setAttribute('data-state', 'active');

      for (var i = 0; i < DROPDOWN.options.length; i++) {
        if (DROPDOWN.value === DROPDOWN.options[i].value) {
          updateDropdownValue(DROPDOWN, i);
        }
      }

      if (DROPDOWN.dropdownOptions.callback) {
        DROPDOWN.dropdownOptions.callback(DROPDOWN.value);
      }

      toggleDropdown(event);
    }

    function createListItem(dropdownOption) {
      var LI = document.createElement('li');
      LI.setAttribute('class', 'dg-dropdown__list-item');
      LI.innerHTML = dropdownOption.innerHTML;
      LI.setAttribute('data-value', dropdownOption.value);
      LI.addEventListener('click', handleDropdownItemClick);

      DROPDOWN.DROPDOWN_LABEL.innerHTML = dropdownOption.innerHTML;

      UL.appendChild(LI);
      calculateDropdownDimensions(LI);
    }

    function setElementWidth(element) {
      var ELEMENT = element;
      ELEMENT.style.width = dropdownWidth + 'px';
    }

    DROPDOWN.reset = function reset() {
      updateDropdownValue(DROPDOWN);
    };

    for (var i = 0; i < DROPDOWN.options.length; i++) {
      createListItem(DROPDOWN.options[i]);
    }

    var ELEMENT_TO_MODIFY = DROPDOWN_TYPE ? UL : CONTAINER;

    setElementWidth(ELEMENT_TO_MODIFY);

    setDropdownHeight();
    updateDropdownValue(DROPDOWN);
  }

  function init() {
    Node.prototype.Dropdown = function Dropdown(options) {
      var ELEMENT = this;

      if (ELEMENT.hasAttribute('data-dropdown')) {
        if (!ELEMENT.isDropdown) {
          createDropdown(ELEMENT, options);
        } else {
          generateOptions(ELEMENT, options);
        }
      }
    };

    var DROPDOWNS = document.querySelectorAll('[data-dropdown]');

    for (var i = 0; i < DROPDOWNS.length; i++) {
      var DROPDOWN = DROPDOWNS[i];
      createDropdown(DROPDOWN);
    }
  }

  init();
})();