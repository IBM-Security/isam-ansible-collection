window.addEventListener("load", startup);

var attest_dataSetValues = document.currentScript.dataset;
var attestJSON = JSON.parse(document.getElementById('fido_attestation_tags').textContent);

var attest_optionsResultJson = {
    "rp": {
        "id": attest_dataSetValues.fidoRpId,
        "name": attest_dataSetValues.fidoRpName
    },
    "user": {
        "id": attest_dataSetValues.fidoUserId,
        "name": attest_dataSetValues.fidoUserName,
        "displayName": attest_dataSetValues.fidoDisplayName
    },
    "timeout": attest_dataSetValues.fidoTimeout,
    "challenge": attest_dataSetValues.fidoChallenge,
    "excludeCredentials": attestJSON["fidoAllowCredentials"],
    "extensions": attestJSON["fidoExtensions"],
    "authenticatorSelection": {
        "requireResidentKey": attest_dataSetValues.fidoRequireResidentKey,
        "residentKey": attest_dataSetValues.fidoResidentKey,
        "userVerification": attest_dataSetValues.fidoUserVerification,
        "authenticatorAttachment": attest_dataSetValues.fidoAuthenticatorAttachment
    },
    "attestation": attest_dataSetValues.fidoAttestation,
    "pubKeyCredParams": attestJSON["fidoPubkeyCredParams"],
    "status": attest_dataSetValues.fidoStatus,
    "errorMessage": attest_dataSetValues.fidoErrorMessage
}

var attest_errorMessage = attest_dataSetValues.fidoErrorMessage;
var attest_stateId = attest_dataSetValues.state;
var attest_action = attest_dataSetValues.action;

var attest_publicKey = null;
var attest_createResult = null;

function cancel() {
    document.getElementById("cancelForm").submit();
}

function base64URLEncodeJSON(json) {
    var str = JSON.stringify(json);
    var result = utf8tob64u(str);
    return result;
}

function base64URLEncode(bytes, encoding = 'utf-8') {
    if (bytes == null || bytes.length == 0) {
        return null;
    }
    var str = base64js.fromByteArray(new Uint8Array(bytes));
    str = str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    return str;
}

function base64URLDecode(str, encoding = 'utf-8') {
    if (str == null || str == "") {
        return null;
    }

    var str = str.replace(/-/g, '+').replace(/_/g, '\/');

    var pad = str.length % 4;
    if (pad) {
        str += new Array(5 - pad).join('=');
    }

    var bytes = base64js.toByteArray(str);
    return bytes.buffer;
}

function populateStrings() {
    document.title = authsvcMsg.fido2Registration;
    document.querySelector('#attestation-section h1').textContent = authsvcMsg.twoStepVerificationSetup;
    document.querySelector('#attestation-section p').textContent = authsvcMsg.letsRegisterFIDO;
    document.getElementById("registerButton").value = authsvcMsg.letsGo;

    document.querySelector('#nickname-section h1').textContent = authsvcMsg.twoStepVerificationSetup;
    document.querySelector('#nickname-section p').textContent = authsvcMsg.fido2Nickname;
    document.getElementById("saveButton").value = authsvcMsg.save;

    document.querySelector("#error-section h1").textContent = authsvcMsg.errorLabel;

    document.getElementById("error_img").src = getJunctionName() + "/sps/static/design_images/u2f_error.svg";
    document.getElementById("welcome_img").src = getJunctionName() + "/sps/static/design_images/u2f_device.svg";
    document.getElementById("nickname_img").src = getJunctionName() + "/sps/static/design_images/u2f_device.svg";
}

function optionsGet() {
    attest_createResult = null;

    var url = getJunctionName() + attest_action;
    if (!url.includes("apiauthsvc")) {
        url = url.replace("authsvc", "apiauthsvc");
    }

    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {

        if (request.readyState == 4) {
            if (request.responseText) {

                var json = null;
                try {
                    json = JSON.parse(request.responseText);
                } catch (e) {
                    // we got a 200, but not valid JSON - that's an error
                    showError(authsvcMsg.badOptionsRequest);
                }

                if (json != null) {

                    if (json.stateId != null) {
                        document.getElementById("attestationForm").StateId.value = json.stateId;
                        attest_stateId = json.stateId;
                    }

                    if (json.location != null) {
                        document.getElementById("cancelForm").action = json.location.replace("apiauthsvc", "authsvc") + "&operation=cancel";
                    }

                    if (request.status == 200) {
                        credentialsGet(json);

                    } else {
                        // Response wasn't a 200. Show error.
                        var errorMsg = authsvcMsg.badOptionsRequest;
                        if (json.error != null) {
                            errorMsg = json.error;
                        } else if (json.errorMessage != null) {
                            errorMsg = json.errorMessage;
                        } else if (json.exceptionMsg != null) {
                            errorMsg = json.exceptionMsg;
                        }
                        showError(errorMsg);
                    }

                } else {
                    // Response isn't json. Very weird. Show error.
                    showError(authsvcMsg.badOptionsRequest);
                }
            } else {
                // No response text. Very weird. Show error.
                showError(authsvcMsg.badOptionsRequest);
            }
        } else {
            // readyState is not 4, that's ok, just continue.
        }
    };

    request.open("POST", url);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");

    request.send(JSON.stringify({
        "StateId": attest_stateId
    }));
}

function credentialsGet(options) {
    document.getElementById("registerButton").disabled = true;
    attest_createResult = null;

    // Since our templates are not dynamic, there may be empty fields.
    // Filter them out to not cause errors.
    let publicKey = JSON.parse(JSON.stringify(options), (key, value) => {
        if (value == null || value == '' || value == [] || value == {}) {
            return undefined;
        }
        return value;
    });

    // remove the status and errorMessage keys
    if (("status" in publicKey) == true) {
        delete publicKey['status'];
    }
    if (("errorMessage" in publicKey) == true) {
        delete publicKey['errorMessage'];
    }
    if (("mechanism" in publicKey) == true) {
        delete publicKey['mechanism'];
    }
    if (("location" in publicKey) == true) {
        delete publicKey['location'];
    }
    if (("stateId" in publicKey) == true) {
        delete publicKey['stateId'];
    }

    publicKey.challenge = base64URLDecode(publicKey.challenge);
    publicKey.user.id = base64URLDecode(publicKey.user.id);

    if (publicKey.excludeCredentials != null && publicKey.excludeCredentials.length > 0) {
        for (i in publicKey.excludeCredentials) {
            publicKey.excludeCredentials[i].id = base64URLDecode(publicKey.excludeCredentials[i].id);
        }
    }

    navigator.credentials.create({
        publicKey
    }).then(function(attestation) {
        attest_createResult = attestation;

        document.getElementById("attestation-section").classList.remove('notransition');
        document.getElementById("attestation-section").classList.remove('bx--dialog-content--visible');
        document.getElementById("attestation-section").classList.add('bx--dialog-content--hidden');
        setTimeout(function() {
            document.getElementById("attestation-section").style.left = '-100%';
        }, 300);
        document.getElementById("nickname-section").style.left = '';
        document.getElementById("nickname-section").classList.add('bx--dialog-content--visible');
        document.getElementById("nickname-section").classList.remove('bx--dialog-content--hidden');

        document.getElementById("nickname").value = "";
        document.getElementById("nickname").focus();

    }).catch(function(err) {
        document.getElementById("registerButton").disabled = false;
        showError(err);
    });
}

function submitFIDONickname() {
    var fidoNickname = document.getElementById("nickname").value;
    var attestationForm = document.getElementById("attestationForm");
    attestationForm.id.value = attest_createResult.id;
    attestationForm.rawId.value = base64URLEncode(attest_createResult.rawId);
    attestationForm.clientDataJSON.value = base64URLEncode(attest_createResult.response.clientDataJSON);
    attestationForm.attestationObject.value = base64URLEncode(attest_createResult.response.attestationObject);
    attestationForm.type.value = attest_createResult.type;
    attestationForm.nickname.value = fidoNickname;
    attestationForm.getClientExtensionResults.value = base64URLEncodeJSON(attest_createResult.getClientExtensionResults());

    if (attest_createResult.response.getTransports !== undefined) {
        attestationForm.getTransports.value = base64URLEncodeJSON(attest_createResult.response.getTransports());
    }
    attestationForm.authenticatorAttachment.value = attest_createResult.authenticatorAttachment;

    attestationForm.submit();
    document.getElementById("saveButton").disabled = false;
}

function retry() {
    var divToHide = "error-section";
    if (document.getElementById("nickname-section").classList.contains('bx--dialog-content--visible')) {
        divToHide = "nickname-section";
    }

    document.getElementById(divToHide).classList.remove('bx--dialog-content--visible');
    document.getElementById(divToHide).classList.add('bx--dialog-content--hidden');
    setTimeout(function() {
        document.getElementById(divToHide).style.left = '100%';
    }, 300);
    document.getElementById("attestation-section").style.left = '';
    document.getElementById("attestation-section").classList.add('bx--dialog-content--visible');
    document.getElementById("attestation-section").classList.remove('bx--dialog-content--hidden');
    document.getElementById("registerButton").disabled = false;
}

function checkValid(input) {
    var valid = false;
    var value = input.value;
    if (value != null && value != "" && input.validity.valid) {
        valid = true;
    }
    if (valid) {
        if (input.classList.contains('input-invalid')) {
            input.classList.remove('input-invalid');
        }
    } else {
        input.classList.add('input-invalid');
    }
    document.getElementById("saveButton").disabled = !valid;

    return valid;
}

function showError(errMsg) {
    var divToHide = "attestation-section";
    if (document.getElementById("nickname-section").classList.contains('bx--dialog-content--visible')) {
        divToHide = "nickname-section";
    }

    document.getElementById(divToHide).classList.remove('notransition');
    document.getElementById(divToHide).classList.remove('bx--dialog-content--visible');
    document.getElementById(divToHide).classList.add('bx--dialog-content--hidden');
    setTimeout(function() {
        document.getElementById(divToHide).style.left = '-100%';
    }, 300);
    document.getElementById("error-section").style.left = '';
    document.getElementById("error-section").classList.add('bx--dialog-content--visible');
    document.getElementById("error-section").classList.remove('bx--dialog-content--hidden');
    document.getElementById("errorMessage").textContent = errMsg;
}

function startup() {
    populateStrings();

    document.getElementById("registerButton").addEventListener("click", optionsGet);
    document.getElementById("cancelButton").addEventListener("click", cancel);
    document.getElementById("saveButton").addEventListener("click", submitFIDONickname);
    document.getElementById("retryButton").addEventListener("click", retry);
    document.getElementById("errorRetryButton").addEventListener("click", retry);

    document.getElementById("nickname").addEventListener("input", function() {
        checkValid(document.getElementById("nickname"))
    });

    var styleChange = [];
    styleChange.push(document.getElementById("cancelButton"));
    styleChange.push(document.getElementById("retryButton"));
    styleChange.push(document.getElementById("errorRetryButton"));

    for (var x = 0; x < styleChange.length; x++) {
        styleChange[x].style = "background-image: url('/'" + getJunctionName() + "'/sps/static/design_images/back-light.svg');";
    }

    var jsLinks = document.querySelectorAll('[href="#"]');

    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }
}