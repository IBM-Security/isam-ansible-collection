var createResult = null;
var testId = null;

function registerFIDOAuthenticator() {
    createResult = null;
    document.getElementById("initiate").hidden = false;
    document.getElementById("pending").hidden = true;
    document.getElementById("nicknameForm").hidden = true;
    document.getElementById("done").hidden = true;
    document.getElementById("requireResidentKey").checked = false;
    clearFIDOError();
    document.getElementById("fido2RegistrationPopup").style.display = "block";
}

function submitRegOptions() {
    var requireResidentKey = document.getElementById("requireResidentKey").checked;

    var json = {
        "authenticatorSelection": {
            "requireResidentKey": requireResidentKey,
            "userVerification": "preferred"
        },
        "attestation": "direct"
    };
    if(requireResidentKey) {
        json['extensions'] = {"credentialProtectionPolicy": "userVerificationOptional"};
    }
    document.getElementById("initiate").hidden = true;
    document.getElementById("pending").hidden = false;

    var relyingPartyId = relyingParties[document.getElementById("relyingPartySelection").value];
    makeJsonAjaxRequest("POST", fidoBaseUrl + relyingPartyId + fidoAttestationOptionsUrl, processOptionsResponse, JSON.stringify(json));
}

function processOptionsResponse(request) {
    if(request.readyState == 4 && request.status == 200) {
        var publicKey = JSON.parse(request.responseText);
        if(("status" in publicKey) == true) {
            delete publicKey['status'];
        }
        if(("errorMessage" in publicKey) == true) {
            delete publicKey['errorMessage'];
        }

        publicKey.challenge = base64URLDecode(publicKey.challenge);
        publicKey.user.id = base64URLDecode(publicKey.user.id);

        if(publicKey.excludeCredentials != null && publicKey.excludeCredentials.length > 0) {
            for (i in publicKey.excludeCredentials) {
                publicKey.excludeCredentials[i].id = base64URLDecode(publicKey.excludeCredentials[i].id);
            }
        }

        navigator.credentials.create({ publicKey }).then(function (attestation) {
            createResult = attestation;
            document.getElementById("pending").hidden = true;
            document.getElementById("nicknameForm").hidden = false;
            document.getElementById("nickname").value = "";
            document.getElementById("nickname").focus();

        }).catch(function (err) {
            showFIDOError(err);
        });

    } else if(request.readyState == 4) {
        var errMsg = i18nMsg.error;
        var response = JSON.parse(request.responseText);

        if(response['errorMessage']) {
            errMsg = response['errorMessage'];
        } else if(response['message']) {
            errMsg = response['message'];
        } else if(response['error']) {
            errMsg = response['error'];
        }

        showFIDOError(errMsg);
    }
}

function submitFIDONickname() {

    var fidoNickname = document.getElementById("nickname").value;

    var json = {
        'id': createResult.id,
        'rawId': base64URLEncode(createResult.rawId),
        'response': {
            'clientDataJSON': base64URLEncode(createResult.response.clientDataJSON),
            'attestationObject': base64URLEncode(createResult.response.attestationObject)
        },
        'type': createResult.type,
        'nickname':fidoNickname,
        'getClientExtensionResults': createResult.getClientExtensionResults(),
        'authenticatorAttachment': createResult.authenticatorAttachment
    }
    // if transports are available, include them in the response
    if (createResult.response.getTransports !== undefined) {
        json["getTransports"] = createResult.response.getTransports();
    }

    var relyingPartyId = relyingParties[document.getElementById("relyingPartySelection").value];
    makeJsonAjaxRequest("POST", fidoBaseUrl + relyingPartyId + fidoAttestationResultUrl, processResultResponse, JSON.stringify(json));

}

function processResultResponse(request) {
    if(request.readyState == 4 && request.status == 200) {
        createResult = null;

        var response = JSON.parse(request.responseText);

        document.getElementById("nicknameForm").hidden = true;
        document.getElementById("done").hidden = false;

    } else if(request.readyState == 4) {
        createResult = null;
        var errMsg = i18nMsg.error;
        var response = JSON.parse(request.responseText);

        if(response['errorMessage']) {
            errMsg = response['errorMessage'];
        } else if(response['message']) {
            errMsg = response['message'];
        } else if(response['error']) {
            errMsg = response['error'];
        }

        showFIDOError(errMsg);
    }
}

function testFIDOAuthenticator(credentialId) {
    clearFIDOError();
    testId = credentialId;
    document.getElementById("test").hidden = false;
    document.getElementById("testSuccess").hidden = true;
    document.getElementById("fido2TestPopup").style.display = "block";

    var relyingPartyId = relyingParties[document.getElementById("relyingPartySelection").value];
    makeJsonAjaxRequest("POST", fidoBaseUrl + relyingPartyId + fidoAssertionOptionsUrl, processAssertOptionsResponse, "{}");
}

function processAssertOptionsResponse(request) {
    if(request.readyState == 4 && request.status == 200) {

        var publicKey = JSON.parse(request.responseText);
        if(("status" in publicKey) == true) {
            delete publicKey['status'];
        }
        if(("errorMessage" in publicKey) == true) {
            delete publicKey['errorMessage'];
        }
        publicKey.challenge = base64URLDecode(publicKey.challenge);

        var allowCredentials = [];
        if(publicKey.allowCredentials != null && publicKey.allowCredentials.length > 0) {
            for (i in publicKey.allowCredentials) {
                if(testId == publicKey.allowCredentials[i].id) {
                    publicKey.allowCredentials[i].id = base64URLDecode(publicKey.allowCredentials[i].id);
                    allowCredentials.push(publicKey.allowCredentials[i]);
                }
            }

            publicKey.allowCredentials = allowCredentials;
        }
        navigator.credentials.get({ publicKey }).then(function (assertion) {
            var json = {
                'id': assertion.id,
                'rawId': base64URLEncode(assertion.rawId),
                'response': {
                    'clientDataJSON': base64URLEncode(assertion.response.clientDataJSON),
                    'authenticatorData': base64URLEncode(assertion.response.authenticatorData),
                    'signature': base64URLEncode(assertion.response.signature),
                    'userHandle': base64URLEncode(assertion.response.userHandle)
                },
                'type': assertion.type,
                'getClientExtensionResults': assertion.getClientExtensionResults()
            }

            var relyingPartyId = relyingParties[document.getElementById("relyingPartySelection").value];
            makeJsonAjaxRequest("POST", fidoBaseUrl + relyingPartyId + fidoAssertionResultUrl, processAssertResultResponse, JSON.stringify(json));
        }).catch(function (err) {
            showFIDOError(err);
        });

    } else if(request.readyState == 4) {
        var errMsg = i18nMsg.error;
        var response = JSON.parse(request.responseText);

        if(response['errorMessage']) {
            errMsg = response['errorMessage'];
        } else if(response['message']) {
            errMsg = response['message'];
        } else if(response['error']) {
            errMsg = response['error'];
        }

        showFIDOError(errMsg);
    }
}

function processAssertResultResponse(request) {
    if(request.readyState == 4 && request.status == 200) {
        var response = JSON.parse(request.responseText);
        document.getElementById("test").hidden = true;
        document.getElementById("testSuccess").hidden = false;
    } else if(request.readyState == 4) {
        var errMsg = i18nMsg.error;
        var response = JSON.parse(request.responseText);

        if(response['errorMessage']) {
            errMsg = response['errorMessage'];
        } else if(response['message']) {
            errMsg = response['message'];
        } else if(response['error']) {
            errMsg = response['error'];
        }

        showFIDOError(errMsg);
    }
}

function cancelFIDORegistration() {
    document.getElementById("fido2RegistrationPopup").style.display = "none";
}

function validateFIDONickname() {
    if(document.getElementById("nickname").value &&
            document.getElementById("nickname").value.trim() != "") {
        document.getElementById("submitFIDOButton").disabled = false;
    } else {
        document.getElementById("submitFIDOButton").disabled = true;
    }
}

function clearFIDOStorage() {
    clearFIDOError();
    document.getElementById("fidoClearPopup").style.display = "block";
}

function submitFIDOClear() {
    clearFIDOError();

    let fidoStorage = window.localStorage;
    let fidoUsersObject = JSON.parse(fidoStorage.getItem('fidoUsersObject'));
    if (fidoUsersObject != null) {
        let fidoUsers = fidoUsersObject.fidoUsers;

        console.log("Attempting to remove registrations for user [@USERNAME@] from local storage.");
        removedRego = fidoUsers.filter(fidoUser => fidoUser.username === "@USERNAME@");
        fidoUsersObject.fidoUsers = fidoUsers.filter(fidoUser => fidoUser.username !== "@USERNAME@");

        if(removedRego.length > 0 && removedRego[0].username == fidoUsersObject.mostRecent) {
            delete fidoUsersObject.mostRecent;
        }

        fidoStorage.setItem('fidoUsersObject', JSON.stringify(fidoUsersObject));
    }
    document.getElementById("fidoClearPopup").style.display = "none";
}

function cancelFIDOClear() {
    document.getElementById("fidoClearPopup").style.display = "none";
}

function base64URLEncode(bytes, encoding = 'utf-8') {
    if(bytes == null || bytes.length == 0) {
        return null;
    }
    var str = base64js.fromByteArray(new Uint8Array(bytes));
    str = str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    return str;
}

function base64URLDecode(str, encoding = 'utf-8') {
    if(str == null || str == "") {
        return null;
    }

    var str = str.replace(/-/g, '+').replace(/_/g, '\/');

    var pad = str.length % 4;
    if(pad) {
      str += new Array(5-pad).join('=');
    }

    var bytes = base64js.toByteArray(str);
    return bytes.buffer;
}

function showFIDOError(errMsg) {
    document.getElementById("errId").innerHTML = errMsg;
    document.getElementById("error-box").setAttribute("class", "error-box active");
    document.getElementById("fido2RegistrationPopup").style.display = "none";
    document.getElementById("fido2TestPopup").style.display = "none";
}

function clearFIDOError() {
    document.getElementById("errId").innerHTML = "";
    document.getElementById("error-box").setAttribute("class", "error-box");
}

function showU2F() {
    document.getElementById("u2fSection").style.display = "block";
}
