var mmfa_locationHostPort = location.hostname + (location.port ? ':' + location.port : '');
var mmfa_baseURL = location.protocol + '//' + mmfa_locationHostPort;
var mmfa_formAction = "";
var mmfa_manualOperation = null; // will be null, unless the user presses one of the buttons
var mmfa_ajaxTimer = null; // points to the result of setTimeout, so that a pending poll can be canceled
var mmfa_ajaxActive = false; // is an ajax operation to the apiauthsvc currently active
var mmfa_pollTime = 2000;
var mmfa_usernameMacro = "";

function kickoffMMFA(action, username) {
    mmfa_usernameMacro = username;
    mmfa_formAction = action.replace(/&operation=[a-z]*/, ''); // remove operation from initial action because we manage that separately now

    // start polling, if we are not already
    if (mmfa_ajaxTimer == null && !mmfa_ajaxActive) {
        mmfa_ajaxTimer = window.setTimeout(poll, mmfa_pollTime);
    }

    document.getElementById("verify-button").addEventListener('click', function() {
        performMMFAOperation('verify');
    });
}

function populateDeviceSelection(json, fingerprintPreferred) {
    mmfa_formAction = json.location;

    var verify_method_div = document.getElementById("verify-method-container");
    verify_method_div.textContent = "";

    verify_method_div.appendChild(document.createElement('hr'));

    for (var i = 0; i < json.mmfaDevices.length; i++) {

        var signature_method = json.mmfaDevices[i];
        var fingerprintEnrolled = signature_method["mmfa.user.device.fingerprintEnrolled"] == "true";

        if((fingerprintPreferred && fingerprintEnrolled) || !fingerprintPreferred) {
            var id = signature_method['mmfa.user.device.id'];

            var type = signature_method["mmfa.user.device.type"];
            var deviceName = signature_method["mmfa.user.device.name"];
            var osVersion = signature_method["mmfa.user.device.os.version"];

            var method_div = document.createElement('div');
            method_div.className = "line-method";
            method_div.id = id;
            method_div.type = type;

            method_div.onclick = function() {

                var url = mmfa_baseURL + mmfa_formAction + "&operation=verify";
                if(!url.includes("apiauthsvc")) {
                    url = url.replace("authsvc", "apiauthsvc");
                }

                var selectJson = {};
                selectJson["mmfa.user.device.id"] = this.id;
                selectJson["Submit"] = "Submit";

                var request = new XMLHttpRequest();
                request.onreadystatechange = function() {

                    if (request.readyState == 4) {
                        var json = processJsonResponse(request);
                        if(json != null) {
                            mmfa_formAction = json.location;

                            showMMFA(json, "mmfa-select");
                        }
                    } else {
                        // readyState is not 4, that's ok, just continue.
                    }
                };

                request.open("PUT", url);
                request.setRequestHeader("Content-type", "application/json");
                request.setRequestHeader("Accept", "application/json");
                request.send(JSON.stringify(selectJson));
            };

            method_div.addEventListener("keyup", function(event) {
                event.preventDefault();
                // Enter key is 13, space is 32
                if (event.keyCode === 13 || event.keyCode == 32) {
                    this.click();
                }
            });

            var type_div = document.createElement('div');
            type_div.className = "method-type";

            var name = document.createElement('b');
            name.textContent = deviceName;
            type_div.appendChild(name);

            var os_div = document.createElement('div');
            os_div.textContent = type +' (' + (type.startsWith("i") ? ciMsg.ios + " " : ciMsg.android + " ") + osVersion + ')';
            type_div.appendChild(os_div);

            method_div.appendChild(type_div);

            var link_div = document.createElement('a');
            link_div.className = "method-link";
            link_div.href = "#";
            link_div.textContent = ciMsg.sendPush;
            link_div.id = id;
            link_div.type = type;

            link_div.addEventListener("click", function(event) {
                event.preventDefault(); // Prevent default action (a following a link)
            }, false);

            method_div.appendChild(link_div);

            verify_method_div.appendChild(method_div);
            verify_method_div.appendChild(document.createElement('hr'));
        }
    }
}

function displayError(errorTitle, errorStr) {
    var errorTile = document.getElementById('error-tile');
    if (errorStr != "") {
        document.getElementById("transaction-tile").classList.add("hidden");
        errorTile.classList.remove("hidden");
        document.getElementById('mmfa-error-heading').textContent = authsvcMsg.errorColonLabel;
        document.getElementById('mmfa-error-content').textContent = errorStr;
        if (errorTitle != "") {
            document.getElementById('mmfa-error-title').textContent = errorTitle;
        }
    } else {
        errorTile.classList.add("hidden");
    }
}

function hideStatus(status) {
    var statusDiv = document.getElementById('status-div');
    statusDiv.classList.add("hidden");
}

function hideOperations() {
    var operationsDiv = document.getElementById('operations-div');
    operationsDiv.classList.add("hidden");
    document.querySelector('.sectionTitle').classList.add("hidden");
}

function disableOperationButtons() {
    document.getElementById("verify-button").disabled = true;
}

function performMMFAOperation(op) {

    disableOperationButtons();
    mmfa_manualOperation = op;
    if (mmfa_ajaxTimer != null) {
        window.clearTimeout(mmfa_ajaxTimer);
    }

    // if we are not in an active ajax call, manually invoke it
    // if we are, then the callback handler will do this
    // after it get's it's latest response and updates formAction
    if (!mmfa_ajaxActive) {
        submitManualOperation();
    }
}

function submitManualOperation() {

    if (mmfa_manualOperation == "verify") {
        var operationJson = {};
        var operation = "Verify";
        operationJson[operation] = operation;

        var url = mmfa_baseURL + mmfa_formAction + "&operation=" + mmfa_manualOperation;

        var request = new XMLHttpRequest();
        request.onreadystatechange = function() {
            mmfa_manualOperation = null;
            processPoll(request);
        };

        request.open("PUT", url);
        request.setRequestHeader("Content-type", "application/json");
        request.setRequestHeader("Accept", "application/json");
        request.send(JSON.stringify(operationJson));

    } else if (mmfa_manualOperation == "returnToDecision") {

        if(document.getElementById('error-tile').classList.contains("hidden")) {

            var operationForm = document.createElement('form');
            operationForm.method = "POST";
            operationForm.action = mmfa_baseURL + mmfa_formAction.replace("apiauthsvc", "authsvc") + "&operation=" + mmfa_manualOperation;

            var operationInput = document.createElement('input');
            operationInput.type = 'hidden';
            operationInput.name = "operation";
            operationInput.value = "returnToDecision";

            var usernameInput = document.createElement('input');
            usernameInput.type = 'hidden';
            usernameInput.name = "username";
            usernameInput.value = mmfa_usernameMacro;

            operationForm.appendChild(operationInput);
            operationForm.appendChild(usernameInput);
            document.body.appendChild(operationForm);
            operationForm.submit();

        } else {
            window.location.href = mmfa_baseURL + getJunctionName() + "/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:ifa&username=" + usernameMacro;
        }
    }

}

function buildPollURL() {
    var result = mmfa_baseURL + mmfa_formAction + "&operation=verify&ajax=true";
    if (!result.includes("apiauthsvc")) {
        result = result.replace("authsvc", "apiauthsvc");
    }
    return result;
}

function poll() {
    mmfa_ajaxActive = true;
    var url = buildPollURL();
    console.log("polling: " + url);
    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {
        processPoll(request);
    };

    request.open("PUT", url);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");
    // send same parameters as the old FORM method of pressing the Verify button
    var putBody = {
        "Verify": "Verify"
    };
    request.send(JSON.stringify(putBody));
}

function processPoll(request) {
    let errorTitle = "";
    let errorMessage = "";
    if (request.readyState == 4) {
        console.log("The poll received readyState: " + request.readyState + " and status: " + request.status);
        console.log("The poll response text is: " + request["responseText"]);
        // request done, process it
        if (request.status == 200) {
            var json = null;
            var responseText = null;
            if (request.responseText) {
                var responseText = request.responseText;
                if (responseText.includes("}{")) {
                    responseText = responseText.substring(responseText.indexOf("}{") + 1);
                }
                var jObj = null;
                try {
                    jObj = JSON.parse(responseText);
                } catch (e) {
                    // we got a 200, but not valid JSON - that's an error
                }
                if (jObj != null) {
                    var status = "";
                    if (jObj.mmfa_transaction_status) {
                        status = jObj.mmfa_transaction_status;
                    } else {
                        status = jObj.status;
                    }

                    if (status == "pending") {
                        if (jObj.action != null) {
                            mmfa_formAction = jObj.action;
                        }
                        if (jObj.location != null) {
                            mmfa_formAction = jObj.location;
                            document.getElementById("ping-pong-form").action = jObj.location.replace("apiauthsvc","authsvc");
                            document.getElementById("cancel-form").action = jObj.location.replace("apiauthsvc","authsvc");
                        }
                        // restart the poll unless there is a manual operation about to happen
                        if (mmfa_manualOperation == null) {
                            mmfa_ajaxTimer = window.setTimeout(poll, mmfa_pollTime);
                        }
                    } else {
                        // make sure we don't try and do anything else
                        mmfa_manualOperation = null;
                        if (jObj.action != null) {
                            mmfa_formAction = jObj.action;
                        }
                        if (jObj.location != null) {
                            mmfa_formAction = jObj.location;
                            document.getElementById("ping-pong-form").action = jObj.location.replace("apiauthsvc","authsvc");
                            document.getElementById("cancel-form").action = jObj.location.replace("apiauthsvc","authsvc");
                        }
                        sendSuccess(jObj.location, usernameMacro);
                    }
                } else {
                    // 200, but not json response body - error

                    // make sure we don't try and do anything else
                    mmfa_manualOperation = null;

                    // set up catchall error/status messages
                    errorTitle = authsvcMsg.mmfaTransactionStatusError;

                    // display whatever we came up with, and hide further operations
                    hideOperations();
                    displayError(errorTitle, errorMessage);
                    hideStatus();
                }
            }
        } else {
            // not a good 200 response - is there error text to display?

            // make sure we don't try and do anything else
            mmfa_manualOperation = null;

            // set up catchall error/status messages
            errorTitle = authsvcMsg.mmfaTransactionStatusError;
            errorMessage = authsvcMsg.unexpectedResponse + request.status;
            if (request.responseText) {
                try {
                    var rspObj = JSON.parse(request.responseText);
                    if (rspObj != null && rspObj.error != null) {
                        errorStr = rspObj.error;
                    }
                } catch (e) {
                    // probably not JSON - just go with our generic error message
                }
            }

            // display whatever we came up with, and hide further operations
            hideOperations();
            displayError(errorTitle, errorMessage);
            hideStatus();
        }

        //
        // If a button was pressed while we were doing the last ajax operation,
        // act on it now
        //
        if (mmfa_manualOperation != null) {
            submitManualOperation();
        }

        // we are no longer in an active poll
        mmfa_ajaxActive = false;

    } else {
        // readyState is not 4, that's ok, just continue.
    }
}
