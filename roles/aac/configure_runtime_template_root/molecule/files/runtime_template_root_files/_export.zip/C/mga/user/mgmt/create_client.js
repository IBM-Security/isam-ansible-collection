window.addEventListener("load", startup);

function back() {
  window.location.href = baseUrl + "/html/device/device_selection.html";
}

function error(str) {
  document.getElementById("errorbox").textContent = str;
}

function reset_error() {
  error("");
}

function handle_register_response(request) {
  if (request.readyState == 4 && (request.status == 200 || request.status == 201)) {
    if (request.responseText == "Not found") {
    } else {
      try {
        var json = JSON.parse(request.responseText);
        if(json != null && 'error' in json) {
          var error_str = mgmtMsg.serverError + json['error'] + mgmtMsg.colonSpace + json['error_description'];
          error(error_str);
        } else {
          // new_log is the API page, use the USC
          // page for a non API call
          var new_loc = json['registration_client_uri'];
          var server_relative = new_loc.replace(/https:\/\/.*?(?=\/)/, "");
          window.location.href = junction + "/sps/mga/user/mgmt/html/client.html?uri=" + encodeURIComponent(server_relative);
        }
      } catch (e) {
        error("Error parsing response: " + e);
      }
    }
  }
}
function register() {
  reset_error();
  // Construct the JSON payload:
  var payload = null;
  try {
    var tmp = document.getElementById("params").value;
    if(tmp == null || "" == tmp.trim()) {
      payload = {};
    } else {
      payload = JSON.parse(tmp);
    }
  } catch(e) {
    error("Error: parsing additional parameters: " + e);
  }
  if(payload != null) {
    // Add to they payload the text fields

    var client_name = document.getElementById("client_name").value;
    payload["client_name"] = client_name;

    var redirect_uri = document.getElementById("redirect_uri").value;
    console.log(redirect_uri)
    if((redirect_uri == null || "" == redirect_uri.trim()) && payload['redirect_uris'] == null) {
      error("Error: Redirect URI is required")
    } else {
      if (payload['redirect_uris'] == null) {
        payload["redirect_uris"] = [];
      }
      payload["redirect_uris"].push(redirect_uri);

      // Use the definition to build the uri
      var definition = document.getElementById("definition").value;


      if(definition == null || "" == definition.trim()) {
        error("Error: Definition is required")
      } else {

        url = registerUrl + definition;

        makeJsonAjaxRequest("POST", url, handle_register_response, JSON.stringify(payload));
      }
    }
  }
}

function startup() {
  document.getElementById("back").addEventListener("click", back);
  document.getElementById("register").addEventListener("click", register);
}