window.addEventListener("load", startup);

var gd_branchesMacro = document.currentScript.dataset.branches;
var branches = {};
if (gd_branchesMacro && gd_branchesMacro.length > 0) {
    gd_branchesMacro = gd_branchesMacro.replace(/&quot;/g, "\"");
    branches = JSON.parse(gd_branchesMacro);
}

function createGrid() {

    var layoutRight = document.getElementById("bx--layout-right");

    for (i = 0; i < branches.length; i++) {
        var branch = branches[i];

        var branch_div = document.createElement('div');
        branch_div.className = "bx--line-method-container";
        branch_div.style = "margin-top: 32px;";

        var line_method_div = document.createElement('div');
        line_method_div.className = "bx--line-method";
        line_method_div.branch = branch;
        line_method_div.onclick = function() {
            document.querySelector(".bx--layout-left .bx--loader").classList.remove('hidden');
            document.querySelector(".bx--layout-left .bx--welcome-illustrations .bx--launch-animation").classList.add('hidden');
            document.getElementById("chooseBranchForm").branch.value = encodeURI(this.branch);
            document.getElementById("chooseBranchForm").submit();
        };

        line_method_div.addEventListener("keyup", function(event) {
            event.preventDefault();
            // Enter key is 13, space is 32
            if (event.keyCode === 13 || event.keyCode == 32) {
                this.click();
            }
        });

        var method_type_div = document.createElement('div');
        method_type_div.className = "bx--method-type";
        method_type_div.textContent = branch;

        var method_link_div = document.createElement('div');
        method_link_div.className = "bx--method-link";
        method_link_div.href = "#"
        method_link_div.type = "hotp"
        method_link_div.textContent = authsvcMsg.choose;

        method_link_div.addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);

        line_method_div.appendChild(method_type_div);
        line_method_div.appendChild(method_link_div);

        branch_div.appendChild(line_method_div);
        branch_div.appendChild(document.createElement('hr'));

        layoutRight.appendChild(branch_div);

    }
}

function populateStrings() {
    document.title = authsvcMsg.genericBranch;
    document.querySelector('h3').textContent = authsvcMsg.genericBranch;
    document.querySelector('h1').textContent = authsvcMsg.chooseBranch;
    document.getElementById('verify-question').textContent = authsvcMsg.genericInstructions;
    document.getElementById('warning').textContent = authsvcMsg.fileUpdateMessage;
}

function startup() {
    populateStrings();
    createGrid();
}
