window.addEventListener('load', (event) => {
    onLoadPage();
});

var pwd_cp_dataVals = document.currentScript.dataset;
var pwd_cp_errormsg = pwd_cp_dataVals.errorMessage;

function onLoadPage() {
    showError();
    setFocus();
}

function showError() {
    var elem = document.getElementById("errId");
    if (pwd_cp_errormsg == "") {
        elem.className = "";
    } else {
        elem.className = "errorMessage";
    }
}

function setFocus() {
    document.getElementById("oldpassword").focus();
}
