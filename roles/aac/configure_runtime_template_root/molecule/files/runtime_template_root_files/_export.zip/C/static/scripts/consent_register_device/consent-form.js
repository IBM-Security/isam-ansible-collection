window.addEventListener("load", function() {
    windowStart();
    document.getElementById("enableRegistration").addEventListener("click", enableDiv)
});

var errorStr = document.currentScript.dataset.errMessage;

function enableDiv() {
    if (document.forms[0].register.checked) {
        document.getElementById('devName').className = 'section';
        document.getElementById('deviceText').disabled = false;
    } else {
        document.getElementById('devName').className = 'section disabled';
        document.getElementById('deviceText').disabled = true;
    }
}

function windowStart() {
    displayError();
    enableDiv();
}

function displayError() {
    if (errorStr != "") {
        var errorMsg = document.getElementById("errorMessage");
        errorMsg.textContent = errorMsg.textContent + errorStr;

        var errorDiv = document.getElementById("errorDiv");
        errorDiv.className = "errorMessage visible";
    }
}