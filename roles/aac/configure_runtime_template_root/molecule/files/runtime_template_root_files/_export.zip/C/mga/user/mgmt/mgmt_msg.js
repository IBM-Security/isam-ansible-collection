var mgmtMsg = {

    "definition":"Definition",
    "clientId":"Client ID",
    "owner":"Owner",
    "serverError":"Server error, ",
    "removeString":"Remove",
    "mothersMdnName":"Mother's maiden name?",
    "birthTown":"Name of town where you were born?",
    "firstPet":"Name of first pet?",
    "provideAnswer":"You must provide a value for the following question: ",
    "invalidChars":"The following characters are not allowed: ",
    "illegalChars":"The answer to the following question contains illegal characters: ",
    "notEnoughQuestions":"You must provide at least one knowledge question and answer.",
    "colonSpace":": "
};
