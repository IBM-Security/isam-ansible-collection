var signOnText = 'Please wait, signing on...';
document.write(signOnText);
document.forms[0].submit();
