<%
        // The macro '@OAUTH_CLIENT_DATA_MACRO@' will be the dynamic data of the client.
        // This will include any statically configured client values such as 'company_name', 
        // as well as any dynamic values whether they be from a dynamically registered
        // client, or from a extended client portion, for example 'tos_uri'.
        //
        // These fields are sanitised by default, change the advanced configuration
        // 'oauth20.clientDataToInclude' to add or remove values as necessary. 
        // 
        // Take note this block is in a server side scripting tag, by default we send an empty object.
        // If this data is to be shared with the browser, remove the currently assigned value and use
        // the commented out snippet.
        var to_browser = "{}" //templateContext.macros["@OAUTH_CLIENT_DATA_MACRO@"]; 
      %>
      var dynamic_client_data = <%=to_browser + ";"%>