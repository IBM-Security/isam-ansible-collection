var registerRequest = {};
var registerResponse = {};

function registerToken() {
    if (u2f != null) {
        document.getElementById("registrationPopup").style.display = "block";
        u2f.register(registerRequest.appId,
            [{version: registerRequest.version,
            challenge: registerRequest.challenge}],
            u2fTokens,
            function(response) {
                if(response.errorCode) {
                    var errMsg = i18nMsg.error;
                    if(response.errorCode == 2 | response.errorCode == 4) {
                        errMsg = i18nMsg.errorAlreadyRego;
                    } else if(response.errorCode == 5) {
                        errMsg = i18nMsg.errorTimedOut;
                    }
                    showError(errMsg);
                }
                // sanity check of response data before prompting for friendly name
                else if(response["registrationData"] != null) {
                    document.getElementById("registrationPopup").style.display = "none";
                    registerResponse = response;
                    document.getElementById("namePopup").style.display = "block";
                    document.getElementById("friendlyName").focus();
                }
            },
            300
        );

    } else {
        showError(i18nMsg.error);
    }
}

function processRegisterResponse(request) {
    if(request.readyState == 4 &&
            (request.status == 204 | request.status == 200)) {
        location.reload();

    } else if(request.readyState == 4) {
        var errMsg = i18nMsg.error;
        var response = JSON.parse(request.responseText);

        if(response['message']) {
            errMsg = response['message'];
        } else if(response['error']) {
            errMsg = response['error'];
        }

        showError(errMsg);
    }
}

function processU2FEnableRequest(request) {
    if(request.readyState == 4 &&
            (request.status == 204 | request.status == 200)) {
        location.reload();
    }
}

function submit() {
    var name = document.getElementById("friendlyName").value;

    registerResponse.name = name;
    registerResponse.action = "register";
    document.getElementById("friendlyName").value = "";

    makeJsonAjaxRequest("PUT", registerRequest.location, processRegisterResponse, JSON.stringify(registerResponse));

    document.getElementById("namePopup").style.display = "none";
}

function cancel() {
    document.getElementById("namePopup").style.display = "none";
}

function validateName() {
    if(document.getElementById("friendlyName").value &&
            document.getElementById("friendlyName").value.trim() != "") {
        document.getElementById("submitButton").disabled = false;
    } else {
        document.getElementById("submitButton").disabled = true;
    }
}

function showError(errMsg) {
    document.getElementById("errId").innerHTML = errMsg;
    document.getElementById("error-box").className = "error-box active";
    document.getElementById("namePopup").style.display = "none";
    document.getElementById("registrationPopup").style.display = "none";
}

