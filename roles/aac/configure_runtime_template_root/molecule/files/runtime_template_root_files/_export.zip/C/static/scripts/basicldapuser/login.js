window.addEventListener('load', (event) => {
    onLoadPage();

});

var ldap_login_dataVals = document.currentScript.dataset;
var ldap_login_errormsg = ldap_login_dataVals.errorMessage;

function onLoadPage() {
    showError();
    setFocus();
}

function showError() {
    var elem = document.getElementById("errId");
    if (ldap_login_errormsg == "") {
        elem.className = "";
    } else {
        elem.className = "errorMessage";
    }
}

function setFocus() {
    document.getElementById("username").focus();
}
