var null_elements_receipt = [];
var loading_elements_receipt = [];
var content_elements_receipt = [];

var null_elements_banking = [];
var loading_elements_banking = [];
var content_elements_banking = [];

var null_elements_manage = [];
var loading_elements_manage = [];
var content_elements_manage = [];

var null_elements_authenticator_card = [];
var loading_elements_authenticator_card = [];
var content_elements_authenticator_card = [];
var extra_elements_authenticator_card = [];
var extra_classes_authenticator_card = [];

var null_elements_transaction_card = [];
var loading_elements_transaction_card = [];
var content_elements_transaction_card = [];
var extra_elements_transaction_card = [];
var extra_classes_transaction_card = [];

var null_elements_transaction_table = [];
var loading_elements_transaction_table = [];
var content_elements_transaction_table = [];

var null_elements_verification = [];
var loading_elements_verification = [];
var content_elements_verification = [];

var null_elements_verification_right = [];
var loading_elements_verification_right = [];
var content_elements_verification_right = [];

$( document ).ready(function() {

	loading_elements_manage = $.merge(loading_elements_manage, $(".ibmsy-wrapper-manage .loader").toArray());
	null_elements_manage = $.merge(null_elements_manage, $(".ibmsy-sc-device-container").toArray());
	null_elements_manage = $.merge(null_elements_manage, $(".no-devices-container").toArray());
	content_elements_manage = $.merge(content_elements_manage, $(".ibmsy-sc-device-container").toArray());
	content_elements_manage = $.merge(content_elements_manage, $(".no-devices-container").toArray());

	loading_elements_authenticator_card = $.merge(loading_elements_authenticator_card, $("#authenticatorsCard .loader").toArray());
	null_elements_authenticator_card = $.merge(null_elements_authenticator_card, $("#authenticatorsCard .null-space").toArray());
	null_elements_authenticator_card = $.merge(null_elements_authenticator_card, $("#authenticators-new-register").toArray());
	content_elements_authenticator_card = $.merge(content_elements_authenticator_card, $("#settingsAuthenticators").toArray());
	content_elements_authenticator_card = $.merge(content_elements_authenticator_card, $(".authenticators-summary").toArray());
	content_elements_authenticator_card = $.merge(content_elements_authenticator_card, $("#authenticators-already-register").toArray());
	content_elements_authenticator_card = $.merge(content_elements_authenticator_card, $("#authenticatorsDetailsRow").toArray());
	extra_elements_authenticator_card = $.merge(extra_elements_authenticator_card, $("#authenticatorsCard").toArray());
	extra_classes_authenticator_card.push("cards-active");	

	loading_elements_verification = $.merge(loading_elements_verification, $(".ibmsy-modal-content.ibmsy-modal-content .loader").toArray());
	loading_elements_verification = $.merge(loading_elements_verification, $(".ibmsy-pane-content.ibmsy-pane-content .ibmsy-layout-right .loader").toArray());
	content_elements_verification = $.merge(content_elements_verification, $(".ibmsy-modal-content.ibmsy-modal-content .ibmsy-layout-left").toArray());
	content_elements_verification = $.merge(content_elements_verification, $(".ibmsy-modal-content.ibmsy-modal-content .ibmsy-layout-right").toArray());
	content_elements_verification = $.merge(content_elements_verification, $(".ibmsy-pane-content.ibmsy-pane-content .ibmsy-layout-right .ibmsy-example-animation").toArray());
	content_elements_verification = $.merge(content_elements_verification, $(".ibmsy-modal-content.ibmsy-modal-content .ibmsy-layout-right .ibmsy-example-animation").toArray());

	loading_elements_verification_right = $.merge(loading_elements_verification_right, $(".ibmsy-modal-content.ibmsy-modal-content .ibmsy-layout-right .loader").toArray());
	content_elements_verification_right = $.merge(content_elements_verification_right, $(".ibmsy-modal-content.ibmsy-modal-content .ibmsy-layout-right .ibmsy-example-animation").toArray());
	
});


//Helper function/s for showing loading/null/full states for UI elements--------
function displayElements(mode, elementsLoader, elementsNullspace, elementsContent, extraContent, extraClasses) {
	//console.log("Changing Element state: " + mode);
	if (mode == "empty") {
		changeElementState(elementsContent, "hide");
		changeElementState(elementsLoader, "hide");
		changeElementState(elementsNullspace, "show");
		changeExtraClasses("hide", extraContent, extraClasses);
	} else if (mode == "full") {
		changeElementState(elementsNullspace, "hide");
		changeElementState(elementsLoader, "hide");
		changeElementState(elementsContent, "show");
		changeExtraClasses("show", extraContent, extraClasses);
	} else if (mode == "loading") {
		changeElementState(elementsContent, "hide");
		changeElementState(elementsNullspace, "hide");
		changeElementState(elementsLoader, "show");
		checkElementState(elementsLoader, elementsNullspace, elementsContent);
	}
}

function checkElementState(elementsLoader, elementsNullspace, elementsContent){
	setTimeout(function() {
	  Array.prototype.forEach.call(elementsLoader, function (element) {
		if (!element.classList.contains("hidden")){
			//console.log("checkElementState empty");
			displayElements("empty", elementsLoader, elementsNullspace, elementsContent);
		}
	  });
	}, 5000);
}

function changeElementState(elements, mode){
	if (elements != null){
		switch(mode){
			case "hide":			
				Array.prototype.forEach.call(elements, function (element) {
					if (!element.classList.contains("hidden")){
						element.classList.add('hidden');		
					}
				});
				break;
			case "show":	
				Array.prototype.forEach.call(elements, function (element) {
					if (element.classList.contains("hidden")){
						element.classList.remove('hidden');		
					}
				});
				break;
		}
	}
}

function changeExtraClasses(mode, elements, classes){
	if (elements != null && classes != null){
		switch(mode){
			case "show":			
				Array.prototype.forEach.call(elements, function (element) {
					Array.prototype.forEach.call(classes, function (extra_class) {
						if (!element.classList.contains(extra_class)){
							element.classList.add(extra_class);		
						}
					});
				});
				break;
			case "hide":	
				Array.prototype.forEach.call(elements, function (element) {
					Array.prototype.forEach.call(classes, function (extra_class) {
						if (element.classList.contains(extra_class)){
							element.classList.remove(extra_class);		
						}
					});
				});
				break;
		}	
	}	
}
