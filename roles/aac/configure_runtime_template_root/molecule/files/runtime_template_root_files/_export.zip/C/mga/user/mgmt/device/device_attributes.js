window.addEventListener("load", startup);

var getRequest = null;
var deviceId;

deviceId = getDeviceIdFromPath();
if (deviceId) {
	getAttributes(deviceId);
}

function getAttributes(deviceId) {
	getRequest = new XMLHttpRequest();
	getRequest.onreadystatechange = processGetRequest;
	getRequest.open("GET", deviceBaseUrl + "/" + deviceId, true);
	getRequest.send(null);
}

function processGetRequest() {
	if (getRequest.readyState == 4 && getRequest.status == 200) {
		if (getRequest.responseText == "Not found") {
		} else {
			var deviceInfo = JSON.parse(getRequest.responseText);
			deviceId = deviceInfo['id'];
			document.getElementById("deviceId").value = deviceId;

			var enabledBox = document.getElementById('deviceEnabled');
			enabledBox.id = deviceId;
			enabledBox.onclick = function() {
				enableDevice(this.id, this.checked);
			};
			if (deviceInfo['isEnabled'] == true) {
				enabledBox.checked = true;
			}

			createAttributesTable(deviceInfo['attributes']);
			var name = document.getElementById("deviceName");
			name.innerHTML = deviceInfo['name'];
		}
	}
}

function createAttributesTable(attributes) {
	var table = document.getElementById("attributesTable");
	for ( var i = 0; i < attributes.length; i++) {
		var attr = attributes[i];
		var tr = table.insertRow(-1);

		var nameTd = tr.insertCell(-1);
		var valueTd = tr.insertCell(-1);
		nameTd.innerHTML = attr['name'];
		valueTd.innerHTML = attr['value'];
	}
}

deleteRequest = null;

function deleteDevice() {
	deleteRequest = new XMLHttpRequest();
	deleteRequest.onreadystatechange = processDeleteRequest;
	deleteRequest.open("DELETE", deviceBaseUrl + "/" + deviceId, true);
	deleteRequest.send(null);
}

function processDeleteRequest() {
	if (deleteRequest.readyState == 4 && deleteRequest.status == 200) {
		if (deleteRequest.responseText == "Not found") {
		} else {
			window.location = junction
					+ "/sps/mga/user/mgmt/html/device/device_selection.html";
		}
	}
}

function renameDevice() {
	var form = document.getElementById("rename");
	deviceId = form.elements["deviceId"].value;
	var deviceName = form.elements["newNameText"].value;

	var json = {};
	if (deviceName != null && deviceName != "") {
		json['name'] = deviceName;
	}

	renameRequest = new XMLHttpRequest();
	renameRequest.onreadystatechange = processRenameRequest;
	renameRequest.open("PUT", deviceBaseUrl + "/" + deviceId, true);
	renameRequest.setRequestHeader("Content-type", "application/json");
	renameRequest.send(JSON.stringify(json));
}

function processRenameRequest() {
	if (renameRequest.readyState == 4 && renameRequest.status == 200) {
		if (renameRequest.responseText == "Not found") {
		} else {
			location.reload();
		}
	} else if (renameRequest.readyState == 4 && renameRequest.status == 400) {
		var response = JSON.parse(renameRequest.responseText);
		window.alert(response['result']);
	}
}

function getDeviceIdFromPath() {
	var queryString = window.location.search.substring(1);
	var params = queryString.split("&");
	for ( var i = 0; i < params.length; i++) {
		var keyValue = params[i].split("=");
		if (keyValue[0] == "id") {
			return keyValue[1];
		}
	}

	return null;
}

function enableDevice(deviceId, enabled) {
	var json = {};
	json['isEnabled'] = enabled;
	enableRequest = makeAjaxRequest("PUT", deviceBaseUrl + "/" + deviceId,
			processEnableRequest, JSON.stringify(json));
}

function processEnableRequest(enableRequest) {
	if (enableRequest.readyState == 4 && enableRequest.status == 200) {
		if (enableRequest.responseText == "Not found") {
		} else {
			var json = JSON.parse(enableRequest.responseText);
			window.alert(json['result']);
		}
	}
}

function startup() {
	document.getElementById("remove").addEventListener("click", deleteDevice);
	document.getElementById("renameButton").addEventListener("click", renameDevice);
}