window.addEventListener("load", startup);

getSecretKeyUrl('totp');
getSecretKeyUrl('hotp');

deleteRequest = null;

function resetOTP(otpType) {
    deleteRequest = makeAjaxRequest("DELETE",otpBaseUrl + "/" + otpType, processDeleteRequest, null);
}

function processDeleteRequest(deleteRequest) {
    if(deleteRequest.readyState == 4 && deleteRequest.status ==200) {
        if(deleteRequest.responseText == "Not found") {
        } else {
            location.reload();
        }
    }
}

getRequest = null;

function getSecretKeyUrl(otpType) {
    if(otpType == 'totp') {
        getRequest = makeAjaxRequest("GET",otpBaseUrl + "/" + otpType, processTotpGetRequest, null);
    } else if(otpType == 'hotp') {
        getRequest = makeAjaxRequest("GET",otpBaseUrl + "/" + otpType, processHotpGetRequest, null);
    }
}

function processTotpGetRequest(getRequest) {
    if(getRequest.readyState == 4 && getRequest.status == 200) {
        if(getRequest.responseText == "Not found") {
        } else {
            var response = JSON.parse(getRequest.responseText);
            var url = document.getElementById("totpSecretKeyUrl");
            url.textContent = response['secretKey'];
        }
    }
}

function processHotpGetRequest(getRequest) {
    if(getRequest.readyState == 4 && getRequest.status == 200) {
        if(getRequest.responseText == "Not found") {
        } else {
            var response = JSON.parse(getRequest.responseText);
            var url = document.getElementById("hotpSecretKeyUrl");
            url.textContent = response['secretKey'];
        }
    }
}

function startup() {
    document.getElementById("resetTotp").addEventListener("click", function(){resetOTP('totp')});
    document.getElementById("resetHotp").addEventListener("click", function(){resetOTP('hotp')});
}