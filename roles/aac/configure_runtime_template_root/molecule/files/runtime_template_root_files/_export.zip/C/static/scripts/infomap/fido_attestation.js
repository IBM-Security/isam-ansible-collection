window.addEventListener("load", startup);
 
var infoattestJSON = JSON.parse(document.getElementById('im_fido_attestation_tags').textContent);
var info_attest_dataTags = document.currentScript.dataset;

var info_attest_rpId = info_attest_dataTags.fidoRpId;
var info_attest_rpName = info_attest_dataTags.fidoRpName;
var info_attest_timeout = info_attest_dataTags.fidoTimeout;
var info_attest_challenge = info_attest_dataTags.fidoChallenge;
var info_attest_excludedCredentials = infoattestJSON["fidoExcludedCredentials"];
var info_attest_pubkeyCredParams = infoattestJSON["fidoPubkeyCredParams"];
var info_attest_authenticatorSelection = infoattestJSON["fidoAuthenticatorSelection"];
var info_attest_attestationConveyance = info_attest_dataTags.fidoAttestation;
var info_attest_extensions = infoattestJSON["fidoExtensions"];
var info_attest_userId = info_attest_dataTags.fidoUserId;
var info_attest_userName = info_attest_dataTags.fidoUserName;
var info_attest_userDisplayName = info_attest_dataTags.fidoUserDisplayName;
var info_attest_status = info_attest_dataTags.fidoStatus;
var info_attest_errorMessage = info_attest_dataTags.fidoErrorMessage;
var info_attest_apiUrl = getJunctionName() + info_attest_dataTags.action;

// Some browsers have a restriction where the navigator.credentials.get call cannot be
// initiated from an automatic action like onload but instead must be called from a
// user initiated action like a button.
// The following boolean can be used to control whether the button to trigger
// navigator.credentials.get is always shown (false), or whether the button should be
// only shown for browsers that have the user-initiation restriction (true).
var info_attest_browserCheck = false;

var info_attest_publicKey = null;

function cancel() {
    document.getElementById("cancelForm").submit();
}

function base64URLEncode(bytes, encoding = 'utf-8') {
    if (bytes == null || bytes.length == 0) {
        return null;
    }
    var str = base64js.fromByteArray(new Uint8Array(bytes));
    str = str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    return str;
}

function base64URLDecode(str, encoding = 'utf-8') {
    if (str == null || str == "") {
        return null;
    }

    var str = str.replace(/-/g, '+').replace(/_/g, '\/');

    var pad = str.length % 4;
    if (pad) {
        str += new Array(5 - pad).join('=');
    }

    var bytes = base64js.toByteArray(str);
    return bytes.buffer;
}

function populateStrings() {
    document.title = authsvcMsg.fido2Registration;
    document.querySelector('#attestation-section h3').textContent = authsvcMsg.fido2Registration;
    document.querySelector('#attestation-section h1').textContent = authsvcMsg.letsRegisterToken;
    document.getElementById("instructions").textContent = authsvcMsg.fido2Instructions;
    document.getElementById("registerButton").value = authsvcMsg.letsGo;

    document.querySelector("#error-section h1").textContent = authsvcMsg.errorLabel;

    document.getElementById("error_img").src = getJunctionName() + "/sps/static/design_images/u2f_error.svg";
    document.getElementById("welcome_img").src = getJunctionName() + "/sps/static/design_images/u2f_device.svg";
}

function optionsGet() {

    if (!info_attest_apiUrl.includes("apiauthsvc")) {
        info_attest_apiUrl = info_attest_apiUrl.replace("authsvc", "apiauthsvc");
    }

    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {

        if (request.readyState == 4) {
            if (request.responseText) {

                var json = null;
                try {
                    json = JSON.parse(request.responseText);
                } catch (e) {
                    // we got a 200, but not valid JSON - that's an error
                    showError(authsvcMsg.badOptionsRequest);
                }

                if (json != null) {

                    if (json.stateId != null) {
                        document.getElementById("attestationForm").StateId.value = json.stateId;
                    }

                    if (json.location != null) {
                        document.getElementById("cancelForm").action = json.location.replace("apiauthsvc", "authsvc") + "&operation=cancel";
                        document.getElementById("attestationForm").action = json.location.replace("apiauthsvc", "authsvc") + "&fidoInfoMap=attestationResult";
                        apiUrl = json.location;
                    }

                    if (request.status == 200) {

                        info_attest_rpId = json.rpId;
                        info_attest_rpName = json.rpName;
                        info_attest_timeout = json.timeout;
                        info_attest_challenge = json.challenge;
                        info_attest_excludedCredentials = json.excludedCredentials;
                        info_attest_pubkeyCredParams = json.pubkeyCredParams;
                        info_attest_authenticatorSelection = json.authenticatorSelection;
                        info_attest_attestationConveyance = json.attestationConveyance;
                        info_attest_extensions = json.extensions;
                        info_attest_userId = json.userId;
                        info_attest_userName = json.userName;
                        info_attest_userDisplayName = json.userDisplayName;

                        buildOptions();

                        credentialsCreate();

                    } else {
                        // Response wasn't a 200. Show error.
                        var errorMsg = authsvcMsg.badOptionsRequest;
                        if (json.error != null) {
                            errorMsg = json.error;
                        } else if (json.errorMessage != null) {
                            errorMsg = json.errorMessage;
                        } else if (json.exceptionMsg != null) {
                            errorMsg = json.exceptionMsg;
                        }
                        showError(errorMsg);
                    }

                } else {
                    // Response isn't json. Very weird. Show error.
                    showError(authsvcMsg.badOptionsRequest);
                }
            } else {
                // No response text. Very weird. Show error.
                showError(authsvcMsg.badOptionsRequest);
            }
        } else {
            // readyState is not 4, that's ok, just continue.
        }
    };

    request.open("POST", info_attest_apiUrl);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Accept", "application/json");
    request.send(JSON.stringify({
        "fidoInfoMap": "attestationOptions"
    }));

}

function buildOptions() {

    var extensions = {};
    if (info_attest_extensions != null && info_attest_extensions != "") {
        extensions = info_attest_extensions;
    }

    info_attest_publicKey = {
        "rp": {
            "id": info_attest_rpId,
            "name": info_attest_rpName,
        },
        "timeout": parseInt(info_attest_timeout),
        "challenge": base64URLDecode(info_attest_challenge),
        "extensions": extensions,
        "user": {
            "id": base64URLDecode(info_attest_userId),
            "name": info_attest_userName,
            "displayName": info_attest_userDisplayName,
        },
    };


    if (info_attest_attestationConveyance != null && info_attest_attestationConveyance != "") {
        info_attest_publicKey.attestation = info_attest_attestationConveyance;
    }


    var excludedCredentials = [];
    if (info_attest_excludedCredentials != null) {
        var excludedCredentialsJson = info_attest_excludedCredentials;
        if (excludedCredentialsJson.length > 0) {
            for (i in excludedCredentialsJson) {
                excludedCredentialsJson[i].id = base64URLDecode(excludedCredentialsJson[i].id);
                excludedCredentials.push(excludedCredentialsJson[i]);
            }
        }

        info_attest_publicKey.excludedCredentials = excludedCredentials;
    }

    var pubkeyCredParams = [];
    if (info_attest_pubkeyCredParams != null) {
        var pubkeyCredParamsJson = info_attest_pubkeyCredParams;
        if (pubkeyCredParamsJson.length > 0) {
            for (i in pubkeyCredParamsJson) {
                pubkeyCredParams.push(pubkeyCredParamsJson[i]);
            }
        }
        info_attest_publicKey.pubKeyCredParams = pubkeyCredParams;
    }

    if (info_attest_authenticatorSelection != null) {
        var authenticatorSelectionJson = info_attest_authenticatorSelection;
        if (authenticatorSelectionJson != null && authenticatorSelectionJson != undefined) {
            info_attest_publicKey.authenticatorSelection = authenticatorSelectionJson;
        }
    }
}

function credentialsCreate() {
    document.getElementById("registerButton").disabled = true;
    let publicKey = info_attest_publicKey;

    navigator.credentials.create({
        publicKey
    }).then(function(attestation) {
        var attestationForm = document.getElementById("attestationForm");
        attestationForm.id.value = attestation.id;
        attestationForm.rawId.value = base64URLEncode(attestation.rawId);
        attestationForm.clientDataJSON.value = base64URLEncode(attestation.response.clientDataJSON);
        attestationForm.attestationObject.value = base64URLEncode(attestation.response.attestationObject);
        attestationForm.type.value = attestation.type;
        attestationForm.getClientExtensionResults.value = JSON.stringify(attestation.getClientExtensionResults());
        // if transports are available, include them in the response
        if (attestation.response.getTransports !== undefined) {
            attestationForm.getTransports.value = JSON.stringify(attestation.response.getTransports());
        }
        attestationForm.authenticatorAttachment.value = attestation.authenticatorAttachment;

        attestationForm.submit();
        document.getElementById("registerButton").disabled = false;

    }).catch(function(err) {
        document.getElementById("registerButton").disabled = false;
        showError(err);
    });
}

function retry() {
    document.getElementById("error-section").classList.remove('bx--dialog-content--visible');
    document.getElementById("error-section").classList.add('bx--dialog-content--hidden');
    setTimeout(function() {
        document.getElementById("error-section").style.left = '100%';
    }, 300);
    document.getElementById("attestation-section").style.left = '';
    document.getElementById("attestation-section").classList.add('bx--dialog-content--visible');
    document.getElementById("attestation-section").classList.remove('bx--dialog-content--hidden');

    if (info_attest_browserCheck && !info_attest_isSafari) {
        optionsGet();
    }
}

function showError(errMsg) {
    document.getElementById("attestation-section").classList.remove('notransition');
    document.getElementById("attestation-section").classList.remove('bx--dialog-content--visible');
    document.getElementById("attestation-section").classList.add('bx--dialog-content--hidden');
    setTimeout(function() {
        document.getElementById("attestation-section").style.left = '-100%';
    }, 300);
    document.getElementById("error-section").style.left = '';
    document.getElementById("error-section").classList.add('bx--dialog-content--visible');
    document.getElementById("error-section").classList.remove('bx--dialog-content--hidden');
    document.getElementById("errorMessage").textContent = errMsg;
}

// Safari 3.0+ "[object HTMLElementConstructor]"
var info_attest_isSafari = /constructor/i.test(window.HTMLElement) || (function(p) {
    return p.toString() === "[object SafariRemoteNotification]";
})(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));


function startup() {
    populateStrings();

    buildOptions();

    if (info_attest_browserCheck && !info_attest_isSafari) {
        document.getElementById("registerButton").classList.add("hidden");
        optionsGet();
    }

    document.getElementById("registerButton").addEventListener("click", optionsGet);

    var cancelButton = document.getElementById("cancelButton");
    cancelButton.addEventListener("click", cancel);
    cancelButton.style = "background-image: url('/'" + getJunctionName() + "'/sps/static/design_images/back-light.svg');";

    var retryButton = document.getElementById("retryButton");
    retryButton.addEventListener("click", retry);
    retryButton.style = "background-image: url('/'" + getJunctionName() + "'/sps/static/design_images/back-light.svg');";

    var jsLinks = document.querySelectorAll('[href="#"]');

    for (let i = 0; i < jsLinks.length; i++) {
        jsLinks[i].addEventListener("click", function(event) {
            event.preventDefault(); // Prevent default action (a following a link)
        }, false);
    }
}