function getJunctionName() {
	var jct = window.getCookie("IV_JCT");
	if (jct != null && jct != "") {
		return jct;
	} else {
    return "@JUNCTION@";
	}
}
function updateTypeImage(scimRequest) {
	var response = JSON.parse(scimRequest.responseText);
	var transactions = response[scim_transaction_schema].transactionsPending;
	var attributes = response[scim_transaction_schema].attributesPending;
	//console.log(transactions);
	//console.log(attributes);
	$.each(transactions, function(i, transaction) {
		if (transaction.transactionId.split("-")[0] == $(".confirmation-code-actual").first().text()) {
			//console.log("Matching transactions");
			//console.log(transaction);
			authentication_image = $('.authentication-image');
			authentication_text = $('.verify-text');
			if (transaction.authnPolicyURI == "urn:ibm:security:authentication:asf:mmfa_response_fingerprint") {
				authentication_image.addClass('fingerprint-authentication');
				authentication_text.addClass('fingerprint-authentication');
			} else if (transaction.authnPolicyURI == "urn:ibm:security:authentication:asf:mmfa_response_user_presence") {
				authentication_image.removeClass('fingerprint-authentication');
				authentication_text.removeClass('fingerprint-authentication');
			} else {
				//console.log("None of the allowable policies");
				authentication_image.removeClass('fingerprint-authentication');
				authentication_text.removeClass('fingerprint-authentication');
			}
			$.each(attributes, function(k, attribute) {
				if (attribute.transactionId == transaction.transactionId && attribute.name == "mmfa.request.context.message") {
					$(".header-message").html(attribute.values);
					$(".header-message").wrapInTag({
						tag: 'b',
						words: ['sign-in', 'transaction', 'adding']
					});
				}
			});
		}
	});
}

function checkAuthenticatorsForDeviceAdd(action, device_id) {
	var response = {};
	var curr_authenticators = 0;
	if (authenticators != null){
		curr_authenticators = parseInt(authenticators.length);

		if (curr_authenticators != "" || curr_authenticators != "0" ||  curr_authenticators != 0) {
		
			if (curr_authenticators == 1) {
				$(".pick-another-device").addClass("hidden");
			} else {
				$(".pick-another-device").removeClass("hidden");
			}
	
			if (device_id == null && authenticators[0].id != null){
				device_id = authenticators[0].id;
			}
			
			var found = true;
			if (authMethods != null) {
				$.each(authMethods.fingerprint, function(i, authMethod) {
					if (authMethod.authenticator == device_id){
						found =  false;
					}		
				});
				response.allowed = found;
				response.reason = "no-touch";
			} else {
				response.allowed = true;
				response.reason = "no-touch";
			}
			
		}else{
			response.allowed = true;
			response.reason = "none";				
		}
	}else{
		response.allowed = true;
		response.reason = "none";		
	}
	return response;
}

function checkAuthenticatorsForTransfer(transferamount, device_id) {
	var response = {};
	
	if (transferamount < 500){
		response.allowed = true;
		return response;
	}
	
	if (authenticators != null){
		var curr_authenticators = parseInt(authenticators.length);	
		
		if (curr_authenticators > 0){
			
			var enabled = false;
			if (device_id == null && authenticators[0].enabled == true){
				device_id = authenticators[0].id;
				enabled = true;
			}else{
				$.each(authenticators, function(i, authenticator) {
					if (authenticator.id == device_id && authenticator.enabled == true){
						enabled =  true;
					}		
				});
			}
			
			if (enabled == true){			
				if (curr_authenticators == 1) {
					$(".pick-another-device").addClass("hidden");
				} else {
					$(".pick-another-device").removeClass("hidden");
				}
					
				if(parseInt(transferamount) >= 1000){
					var found = false;
					if (authMethods != null) {
						$.each(authMethods.fingerprint, function(i, authMethod) {
							if (authMethod.authenticator == device_id){
								found =  true;
							}		
						});
						response.allowed = found;
						response.reason = "no-touch";
					} else {
						response.allowed = false;
						response.reason = "other";
					}
					
				}else if(parseInt(transferamount) >= 500){
					if (authMethods != null) {
						var found = false;
						$.each(authMethods.userpresence, function(i, authMethod) {
							if (authMethod.authenticator == device_id){
								found = true;
							}					
						});
						response.allowed = found;
						response.reason = "no-user-presence";
					} else {
						response.allowed = false;
						response.reason = "other";
					}
					
				}else{
					//Less than 500 is no 2FA.
					response.allowed = true;
				}
			}else{
				response.allowed = false;
				response.reason = "disabled";				
			}
		}else{
			response.allowed = false;
			response.reason = "none";
		}
	}else{
		response.allowed = false;
		response.reason = "other";
	}
	return response;
}


function send_push(type) {
	CBAPolicySubmit("GET", "/protected/generic/" + type, "generic", null, null);
}


function isam_login(username, response) {
	//Change the text on the Verification modal
	$(".verified_type").text("Sign-in");
	//Construct the stanza and perform a GET request
	var verification_stanza = '{"operation":"verify","username":"' + username + '","g-recaptcha-response":"' + response + '"}';
	CBAPolicySubmit("GET", "/login", "sign-in", null, verification_stanza);
}

function cancelAndReTransfer(receipt) {
	var transactionId = $(".confirmation-code-full").text();
	var device_id = $(".ibmsy-dropdown select option:selected").val();
	retry = true;
	if (ws != null && ws != "undefined"){
			ws.close();
	}
	abortTransaction(transactionId);
	transfer_money(true, device_id,receipt);
}

function transfer_money(repeat, device_id, receipt) {
	if (ws != null && ws != "undefined"){
		ws.close();
	}
	var transferamount = $("#transfer_mmfa").val();
	if (isValidNumber(transferamount)) {
		
		var transfer_check = checkAuthenticatorsForTransfer(transferamount,device_id);
		
		if (transfer_check.allowed == true) {
			$("#transfer_mmfa").css("border", "2px solid green");
			$(".verified_type").text("Transaction");
			// Submit to the policy endpoint
			var type = "transaction";
			if (receipt != null && receipt == false) {
				type = "transaction-no-receipt";
			}
			CBAPolicySubmit("POST", "/protected/transfer", type, '{"transferamount":' + transferamount + '}', '{"receipt":'+receipt+', "repeat":' + repeat + ',"device_id":"' + device_id + '"}');
		} else if (transfer_check.allowed == false){
			$("#transfer_mmfa").css("border", "2px solid orange");
			displayPageAlert(transfer_check.reason);
			if (repeat == true){
				confirmation_fail(transfer_check.reason);
			}
		} else {
			$("#transfer_mmfa").css("border", "2px solid orange");
			if (repeat == true){
				confirmation_fail(transfer_check.reason);
			}
		}
	} else {
		
		$("#transfer_mmfa").css("border", "2px solid red");
		if (repeat == true){
			confirmation_fail();
		}
		
	}
}

function add_authenticator_device(popup) {
	$(".verified_type").text("Device Addition");
	CBAPolicySubmit("GET", "/protected/deviceadd", "add", null, popup);
}

function CBAPolicySubmit(method, url, type, payload, pass_through) {
	getRequest = makeAjaxRequestJSON(method, url, function(getRequest) {
		processCBAResponse(getRequest, type, pass_through);
	}, payload);
}

function processCBAResponse(getRequest, type, pass_through) {
	if (getRequest.readyState == 4) {
		if (getRequest.status == 200) {
			if (getRequest.responseText == "Not found") {} else {
				var response = JSON.parse(getRequest.responseText);
				if (response != null) {
					switch (type) {
						case "sign-in":
							trace("This is a password-less login scenario. This means the authentication policy needs more information. In this case, this is  a recaptcha");
							
							var stateid = response["state"];
							CBAPolicySubmit("PUT", getJunctionName() + "/sps/apiauthsvc?StateId=" + stateid, "sign-in-captcha", pass_through, null)
							
							break;
						case "sign-in-captcha":
							trace("This is a password-less login scenario. This is submitting the recaptcha data.");
							
							var choose_device = processDeviceSelection(response, "sign-in");	
							if (typeof choose_device != "undefined" && choose_device.allowed == false){
								displayPageAlert("none");
							}else{
							    showContentSection('section-welcome-transactions');
							    modalOverlay.classList.remove('closeOverlay');
							    modalWindow.classList.remove('closeWindow');
							    ibmsyModal.style.display = 'block';
							    modalBackButton.style.display = 'none';

								displayElements("loading", loading_elements_verification, null, content_elements_verification);						
							}	
							
							break;
						case "transaction":
						case "transaction-no-receipt":
							trace("This is a transaction scenario. This means the authentication policy is asking for the device.");

							var choose_device = processDeviceSelection(response, type, JSON.parse(pass_through)["device_id"]);

							if (typeof choose_device != "undefined" && choose_device.allowed == false){
								displayPageAlert("none");
							}else{
								if (JSON.parse(pass_through)["repeat"] == false) {
								    showContentSection('section-welcome-transactions');
								    modalOverlay.classList.remove('closeOverlay');
								    modalWindow.classList.remove('closeWindow');
								    ibmsyModal.style.display = 'block';
								    modalBackButton.style.display = 'none';

									displayElements("loading", loading_elements_verification, null, content_elements_verification);
								}else{
									retry = false;
								}						
							}	
							
							break;
						case "add":
							trace("This is device add scenario. This means we are trying to add a second device. ");
							
							if (pass_through == true) {
								$("#registerNewAuthenticator").click();
								$(".ibmsy-modal-content.ibmsy-modal-content--visible .ibmsy-layout-right").addClass("hidden");
								displayElements("loading", loading_elements_verification, null, content_elements_verification);
							} else {
								$("#registerNewAuthenticator").click();
								displayElements("loading", loading_elements_verification_right, null, content_elements_verification_right);
							}
							processDeviceSelection(response, "add");
							
							break;
						case "generic":
							trace("This is generic scenario. ");
							
							var choose_device = processDeviceSelection(response, "generic");
							if (typeof choose_device != "undefined" && choose_device.allowed == false){
								deleteDeviceCover = document.querySelector('.ibmsy-alert-cover');
								deleteDeviceCover.style.display = 'inherit';
								deleteDeviceDialog = document.querySelector('.ibmsy-alert-modal-box');
								deleteDeviceDialog.style.display = 'inherit';
							} else {
								showContentSection("section-push");
							}
							
							break;
						default:
							trace("Oops! Something went wrong. This is an invalid CBA type. (" + type + ")")
							break;
					}
				} else {
					trace("Oops! Something went wrong. Got a NULL response.");
				}
			}
		} else if (getRequest.status == 204) {
			trace("It looks like the transaction was actually successful. This means there was no policy there. Go straight to the reciept page.", "fine");
			if (type == "transfer") {
				loadReceipt(guid(), 0, 0);
			}else{
			    setTimeout(function(){
			    	closeAndCleanup();
			    	justInTimeNotify("Successful !","The transaction has been processed.")
		    	},500);
			}			
		}else if (getRequest.status == 302) {
			trace("Oops! Something went wrong. Got a 302 response - not expected.", "fine");
		} else if (getRequest.status == 403) {
			$("#transfer_mmfa").css("border", "2px solid red");
		}else{
			$("#transfer_mmfa").css("border", "2px solid red");			
		}
	}
	if (pass_through != null && JSON.parse(pass_through)["repeat"] == true) {
		previousContentSection();
	}
}

function processDeviceSelection(response, type, device_id) {
	if (response["mmfaDevices"] != null && response["mmfaDevices"].length > 0) {
		var selected_device = null;
		var stateid = response["stateId"];
		
		//If there are devices, remove existing ones from the dropdown.
		$(".ibmsy-dropdown select").children().remove();
		
		//If there only one device, don't show the link for picking another device.
		if(response["mmfaDevices"].length == 1) {
			$(".pick-another-device").addClass("hidden");
		} else {
			$(".pick-another-device").removeClass("hidden");
			//For each of the devices on the return, put them in the other devices dropdown.
			$.each(response["mmfaDevices"], function(i, authenticator) {
				$(".ibmsy-dropdown select").append($("<option>", {
					value: authenticator["mmfa.user.device.id"],
					text: decode_utf8(authenticator["mmfa.user.device.name"])
				}));
				if (authenticator["mmfa.user.device.id"] == device_id) {
					selected_device = authenticator;
				}
			});
		}		

		//If no device has been picked yet, or none was provided, choose the first one.
		if (typeof device_id == "undefined" || device_id == null || typeof selected_device == "undefined" || selected_device == null) {
			selected_device = response["mmfaDevices"][0];
		}
		
		//Display the Device Name on the Verification Modal
		$(".transaction_device_name").text(decode_utf8(selected_device["mmfa.user.device.name"]));
		
		//Construct the stanza for the device selection and PUT it to the authsvc
		var device_selection_stanza = '{"mmfa.user.device.id":"' + selected_device["mmfa.user.device.id"] + '"}';
		getRequest = makeAjaxRequestJSON("PUT", getJunctionName() +"/sps/apiauthsvc?StateId=" + stateid, 
			function(getRequest) {
				//Connect to the web socket on the return of the AuthSvc - This lags the interface due to the push synch issue.
				processDeviceSelectionReturn(getRequest, type)
			}, 
		device_selection_stanza);
	}else{
		var response = {}; response.allowed = false; response.reason="none";
		return response;
	}
}

function processDeviceSelectionReturn(getRequest, type) {
	if (getRequest.readyState == 4) {
		if (getRequest.responseText != "Not found") {
			switch(getRequest.status){
				case 200:
					trace("Looks like transaction is should be pending");
					
					var response = JSON.parse(getRequest.responseText);
					var transactionId = response["transactionId"];
					var stateId = response["stateId"];
					
					$(".confirmation-code-actual").text(transactionId.split("-")[0]);
					$(".confirmation-code-full").text(transactionId);
					
					var wss_location = get_wss_location();
					connectToISAMWebSocket(wss_location + transactionId, transactionId, stateId, type);
					
					if (typeof ISAM_SCIM_INFO != "undefined") {
						ISAM_SCIM_INFO("pendingTransactions", null, updateTypeImage);
						setTimeout(function(){displayElements("full", loading_elements_verification, null, content_elements_verification);},500);
					}

					break;		
				case 204:
					var text = "success";
				case 400:
					var text = (typeof text == "undefined" ? "failed" : "success");
					trace("Looks like transaction already passed with: " + text);

					clearAllIntervals();
					processTransactionResponseState(text, null, null, type, false, null);

					break;		
				default:
					trace("Oops! Something went wrong. Could not connect to the web socket. Didn't get a 200, 204 or 400 as expected.");
				
					break;					
			}
			if (typeof displayTransactionsTable != "undefined" && type != "sign-in"){
				ISAM_SCIM_INFO("all", waitFunctionSCIM, completeFunctionSCIM, displayTransactionsTable);
			}
		}
	}
}

function connectToISAMWebSocket(socketAddr, transactionId, stateId, type, row) {
	if ("WebSocket" in window) {
		// Let us open a web socket
		ws = new WebSocket(socketAddr);
		ws.onopen = function(e) {
			lastwsevent = e;
			// if we're open, inform the server what txnid we want notification of change on
			if (e != null && e.type == 'open') {
				var msg = "subscribe";
				e.target.send(msg);
			}
		};
		ws.onerror = function(e) {
			lastwserror = e;
		};
		ws.onmessage = function(e) {
			lastwsevent = e;
			var msg = JSON.parse(e.data);
			if (msg != null && msg.txnid == transactionId) {
				if (msg.status == "pending") {
					// this was the ack from the server that proves our websocket is active
					var msg = "subscribe";
					e.target.send(msg);
				} else {
					trace("Connection has changed status...");
					clearAllIntervals();
					processTransactionResponseState(msg.status, transactionId, stateId, type, true, e, row);
				}
			} else {
				trace("Oops! Something went wrong. This doesn't look like a valid transaction.");
			}
		}
		ws.onclose = function(e) {
			trace("Connection is closed...Trying to connect again");
			if (retry == false) {
				//connectToISAMWebSocket(socketAddr, transactionId, stateId, type);
			}
		};
	} else {
		// The browser doesn't support WebSockets - no alerts
		trace("WebSocket NOT supported by your Browser! Alerts won't be present");
	}
}

function processTransactionResponseState(status, transactionId, stateId, type, socket, e, row) {
	switch (status) {
		case "pending":
			trace("MFA Transaction is still pending !");
			break;
		case "success":
			trace("MFA Transaction got Success state !");
			if (typeof pending_transactions_table != "undefined" && typeof row != "undefined"){
				removeTableRow(pending_transactions_table != null ? pending_transactions_table : null, row != null ? row : null);
			}

			// close the socket, we're done
			if (socket == true) {
				e.target.close();
			}
			
			switch (type) {
				case "sign-in":
				case "transaction":
				case "transaction-no-receipt":
					// Transition the Modal
					confirmation_succeed();

					if (type == "transaction" && socket == true) {
						
						loadReceipt(transactionId, 0, 500);
						
					}else if(type == "transaction" && socket == false){
						
						clearTimeout(confirmationTimeout);
						clearTimeout(confirmationTimeoutSecondary);
						showContentSection('section-welcome-transaction-quick');
						modalOverlay.classList.remove('closeOverlay');
						modalWindow.classList.remove('closeWindow');
						ibmsyModal.style.display = 'block';
						modalBackButton.style.display = 'none';
						$("#transition-quick-text").text("successful");
						$("#transition-quick-img").attr("src", "/content/static/img/successtick.png");
						
					}else if(type == "transaction-no-receipt" && socket == true){
						
					    setTimeout(function(){
					    	closeAndCleanup();
					    	justInTimeNotify("Successful !","The transaction has been processed.")
				    	},2000);
					    
					}else if(type == "transaction-no-receipt" && socket == false){
						
						clearTimeout(confirmationTimeout);
						clearTimeout(confirmationTimeoutSecondary);
					    setTimeout(function(){
					    	closeAndCleanup();
					    	justInTimeNotify("Successful !","The transaction has been processed.")
				    	},2000);
					    
					}else{
						
						var formAction = "@JUNCTION@/sps/apiauthsvc?StateId=" + stateId;
						setTimeout(function() {
							getRequest = makeAjaxRequestJSON("PUT", formAction, function(getRequest) {
								processCookie(getRequest)
							}, null);
						}, 1000);
						
					}
					
					
//					if (type == "transfer" && socket == true) {
//						loadReceipt(transactionId, 0, 0);
//					} else if (socket == false) {
//						clearTimeout(confirmationTimeout);
//						clearTimeout(confirmationTimeoutSecondary);
//						if (type == "transfer-no-receipt"){
//						    setTimeout(function(){
//						    	closeAndCleanup();
//						    	justInTimeNotify("Successful !","The transaction has been processed.")
//						    	},2000);
//						}else{		
//							showContentSection('section-welcome-transaction-quick');
//							modalOverlay.classList.remove('closeOverlay');
//							modalWindow.classList.remove('closeWindow');
//							ibmsyModal.style.display = 'block';
//							modalBackButton.style.display = 'none';
//							$("#transition-quick-text").text("successful");
//							$("#transition-quick-img").attr("src", "/content/static/img/successtick.png");
//						}
//					}else if(type == "transfer-no-receipt" && socket == true){
//					    setTimeout(function(){
//					    	closeAndCleanup();
//					    	justInTimeNotify("Successful !","The transaction has been processed.")
//					    	},2000);
//					} else {
//					}
					break;
				case "add":
					if (document.querySelector('[data-name="section-connectaccount"]')) {
						showContentSection('section-connectaccount');
						modalBackButton.style.display = 'none';
					}
					if (popup_global != false) {
						registerAuthenticator("normal");
						register_device_socket_simulate("normal");
					} else {
						registerAuthenticator("deviceadd");
						register_device_socket_simulate("deviceadd");
					}
					break;
				case "generic":
					if (document.querySelector('[data-name="section-complete-otp"]')) {
						showContentSection("section-complete-otp");
						modalBackButton.style.display = 'none';
					}
					break;
				default:
					//console.log("Oops! Something went wrong. This is an invalid CBA type (success flow)");
					break;
			}
			break;
		default:
			trace("MFA Transaction got Failed state !");
			if (typeof pending_transactions_table != "undefined" && typeof row != "undefined"){
				removeTableRow(pending_transactions_table != null ? pending_transactions_table : null, row != null ? row : null);
			}

			// close the socket, we're done
			if (socket == true) {
				e.target.close();
			}
			
			switch (type) {
				case "sign-in":
				case "transaction":
				case "transaction-no-receipt":
					if (retry == false) {
						// Transition the Modal
						confirmation_fail();
						

						if (socket == true && type == "transaction") {
							loadReceipt(transactionId, 0, 500);				
							
						} else if (socket == false && type == "transaction") {
							
							clearTimeout(confirmationTimeout);
							clearTimeout(confirmationTimeoutSecondary);
							showContentSection('section-welcome-transaction-quick');
							modalOverlay.classList.remove('closeOverlay');
							modalWindow.classList.remove('closeWindow');
							ibmsyModal.style.display = 'block';
							modalBackButton.style.display = 'none';
							$("#transition-quick-text").text("NOT successful");
							$("#transition-quick-img").attr("src", "/content/static/img/Exclamation.svg.png");
							
						} else if (socket == true && type == "transaction-no-receipt") {
							
							 setTimeout(function(){
						    	closeAndCleanup();
						    	justInTimeNotify("Not successful !","The transaction failed.")
					    	},2000);							
							 
						} else if (socket == false && type == "transaction-no-receipt") {
							
							clearTimeout(confirmationTimeout);
							clearTimeout(confirmationTimeoutSecondary);
						    setTimeout(function(){
						    	closeAndCleanup();
						    	justInTimeNotify("Not successful !","The transaction failed.")
					    	},2000);
						    
						}
						
//						if (socket == true && type != "transfer-no-receipt") {
//							setTimeout(function() {
//								location.reload();
//							}, 1000);
//						}else if(socket == true && type == "transfer-no-receipt"){
//						    setTimeout(function(){
//						    	closeAndCleanup();
//						    	justInTimeNotify("Not successful !","The transaction failed.")
//						    	},2000);
//						} else {
//							clearTimeout(confirmationTimeout);
//							clearTimeout(confirmationTimeoutSecondary);
//							if (type == "transfer-no-receipt"){
//							    setTimeout(function(){
//							    	closeAndCleanup();
//							    	justInTimeNotify("Not successful !","The transaction failed.")
//							    	},2000);
//							}else{
//								showContentSection('section-welcome-transaction-quick');
//								modalOverlay.classList.remove('closeOverlay');
//								modalWindow.classList.remove('closeWindow');
//								ibmsyModal.style.display = 'block';
//								modalBackButton.style.display = 'none';
//								$("#transition-quick-text").text("NOT successful");
//								$("#transition-quick-img").attr("src", "/content/static/img/Exclamation.svg.png");
//							}
//						}
					}
					break;
				case "add":
					if (popup_global != false) {
						showContentSection('section-confirmationfailed');
					} else {
						previousContentSection();
					}
					break;
				case "generic":
					if (document.querySelector('[data-name="section-complete-otp-fail"]')) {
						showContentSection("section-complete-otp-fail");
						modalBackButton.style.display = 'none';
					}
					break;
				default:
					//console.log("Oops! Something went wrong. This is an invalid CBA type (failure flow)");
					break;
			}
			break;
	}
	retry = false;
}


