window.addEventListener('load', onLoadPage);

var im_login_dataVals = document.currentScript.dataset;
var im_login_errormsg = im_login_dataVals.errorMessage;

function showError() {
    var elem = document.getElementById("errId");
    if (im_login_errormsg == "") {
        elem.className = "";
    } else {
        elem.className = "errorMessage";
    }
}

function setFocus() {
    document.getElementById("username").focus();
}

function onLoadPage() {
    showError();
    setFocus();
}