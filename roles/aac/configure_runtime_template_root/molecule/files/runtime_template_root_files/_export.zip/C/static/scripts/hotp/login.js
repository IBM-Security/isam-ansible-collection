window.addEventListener("load", startup);

var hotpl_dataSetValues = document.currentScript.dataset;
var hotpl_errorMessage = hotpl_dataSetValues.errorMessage;

function displayError() {
    if (hotpl_errorMessage != "") {
        var errorMsg = document.getElementById("errorMessage");
        errorMsg.textContent = errorMsg.textContent + hotpl_errorMessage;

        var errorDiv = document.getElementById("errorDiv");
        errorDiv.className = "errorMessage visible";
    }
}

function startup() {
    displayError();
}