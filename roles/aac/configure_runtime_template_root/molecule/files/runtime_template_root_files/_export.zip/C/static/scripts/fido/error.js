window.addEventListener('load', populateStrings);

function populateStrings() {
    document.title = authsvcMsg.errorLabel;
    document.querySelector("h1").textContent = authsvcMsg.errorLabel;
}
