window.addEventListener("load", startup);

var err_errorMessage = document.currentScript.dataset.errorTag;

function back() {
    document.querySelector(".loader").classList.remove('hidden');
    document.getElementById("verification_img").classList.add('hidden');
    document.getElementById("backForm").submit();
}

function populateStrings() {
    document.title = authsvcMsg.errorLabel;
    document.querySelector("h1").textContent = authsvcMsg.errorLabel;
    if (err_errorMessage != "") {
        document.getElementById("error-message").textContent = authsvcMsg[err_errorMessage];
    }
}

function startup() {
    populateStrings();
    document.getElementById("backButton").addEventListener("click", back);
}