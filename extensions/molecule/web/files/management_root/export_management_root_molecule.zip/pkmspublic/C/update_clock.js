/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022, 2025
 */

/*
 * This script contains the updateClock() function which is used to update the
 * clock which appears in the footer of the login.html management page.
 */

function updateClock() {
    if(document.getElementById("clock")) {
        var e = new Date, t = e.getHours(), a = e.getMinutes(), n = e.getSeconds();

        a = (10>a?"0":"")+a, n = (10>n?"0":"")+n;

        var o=12>t?"AM":"PM";

        t=t>12?t-12:t,t=0==t?12:t;

        var c=t+":"+a+" "+o;document.getElementById("clock").firstChild.nodeValue=c
    }
}

updateClock(),setInterval(updateClock, 1e3)


