/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022
 */

/*
 * This script contains some common functions which are used by the 
 * login_success.html management page.
 */

function onLoadPage(token, auth_url) {
    // Verify Identity Access has a rememeber-me capability which will permit a
    // long lived session.  If you don't want to store the supplied
    // token in a cookie you could store the token in the browser
    // Web storage.  The following code is used to store the session
    // token header from the response.  The fields used in this code 
    // must match the corresponding fields in the login.html, 
    // logout.html and WebSEAL configuration files.
    if (token != null && token != "" && token != "Unknown") {
        localStorage.setItem("verify-access-token", token);
    }

    // If we have a pre-authentication URL we redirect the user to this
    // resource now.
    if (auth_url != null && auth_url != "" && auth_url != "%NONE%") {
        window.location.href = auth_url;
    }
    showMessage();
}

function showMessage() {
    var elem = document.getElementById("message-box");
    elem.setAttribute("class", "message-box active");
}

window.addEventListener('load', (event) => {
    onLoadPage(
        document.scripts.namedItem("login_success").getAttribute('token'),
        document.scripts.namedItem("login_success").getAttribute('auth_url'));
});

