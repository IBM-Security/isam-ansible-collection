/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022
 */

/*
 * This script contains some common functions which are used by the login.html
 * management page.
 */

function onLoadPage(error_message, url, isFormLogin, focus) {
    if (error_message != null) {
        showError(error_message);
    }

    if (focus != null) {
        setFocus(focus);
    }

    // We check to see if the verify-access-username cookie has been
    // set and adjust the remember-username checkbox accordingly. 
    // The name of the cookie which is actually set by WebSEAL is
    // defined by the [remember-me] remember-username-cookie-name 
    // configuration entry.  The configured cookie name should match
    // the cookie name specified in this JavaScript.
    //
    // document.getElementById("remember-username").checked = 
    //   document.cookie.indexOf("verify-access-username") == -1 ? false : true;

    // Verify Identity Access has a remember-me capability which will permit
    // a long lived session.  If you don't want to store the supplied
    // token in a cookie you could store the token in the browser
    // Web storage.  The following code will check to see if the
    // token is available in local storage and if so will send the
    // token to the WebSEAL server in exchange for a session.  The
    // fields used in this code must match the corresponding fields
    // in the logout.html, login_success.html and WebSEAL configuration
    // files.  The login-response-type form field must be set to
    // 'success_page' in order to return the login_success response
    // after authentication has succeeded.
    var token = localStorage.getItem("verify-access-token");

    if (token && isFormLogin === "true") {
        fetch('/pkmslogin.form',
            {
                headers: {
                    'verify-access-persistent-session': token
                }
            })
            .then(response => {
                response.text().then(text => {
                    if (text.indexOf("/pkmslogin.form") == -1) {
                        window.location.href = url;
                    } else {
                        localStorage.removeItem("verify-access-token");
                    }
                });
        });
    }
}

function showError(error_message) {
    var elem = document.getElementById("error-box");
    if (error_message == null || error_message == "") {	
        elem.setAttribute("class", "error-box");
    } else {
        elem.setAttribute("class", "error-box active");
    }
}

function setFocus(name) {
    var element = null;

    if (name == "") {
        element = document.getElementById("username");

    } else {
        element = document.getElementById(name);
    }

    if (element != null) {
        element.focus();
    }
}	

window.addEventListener('load', (event) => {
    onLoadPage(
        document.scripts.namedItem("login").getAttribute('error_message'),
        document.scripts.namedItem("login").getAttribute('url'),
        document.scripts.namedItem("login").getAttribute('isFormLogin'),
        document.scripts.namedItem("login").getAttribute('focus'));
});

