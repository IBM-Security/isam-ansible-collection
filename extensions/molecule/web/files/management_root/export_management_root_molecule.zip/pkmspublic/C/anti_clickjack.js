/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022
 */

/*
 * ClickJack projection from: 
 *       https://www.owasp.org/index.php/Clickjacking_Defense_Cheat_Sheet
 */

if (self === top) {
    var antiClickjack = document.getElementById("antiClickjack");
    antiClickjack.parentNode.removeChild(antiClickjack);
} else {
    top.location = self.location;
}

