/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022
 */

 /*
  * The following block of code provides users with a warning message
  * if they do not have cookies configured on their browsers.  
  * If this environment does not use cookies to maintain login sessions, 
  * simply remove or comment out the block below.
 */

var warningString = "%MSG{0x38983738}%";

document.cookie = 'acceptsCookies=yes; sameSite=lax';

if(document.cookie == ''){
    document.write(warningString);
} else {
    document.cookie = 'acceptsCookies=yes; sameSite=lax; expires=Fri, 13-Apr-1970 00:00:00 GMT';
    // Uncomment the following line for JavaScript redirection
    // document.cookie = 'GWOriginalURL=' + encodeURIComponent(window.location) + "; Path=/;";
}

