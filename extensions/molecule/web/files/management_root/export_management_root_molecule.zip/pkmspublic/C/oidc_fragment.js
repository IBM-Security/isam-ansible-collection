/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022, 2025
 */

/*
 * This script contains some common functions which are used by the 
 * oidc_fragment.html management page.
 */

function onLoadPage() {
    showMessage();
}

function showMessage() {
    var elem = document.getElementById("message-box");
    elem.setAttribute("class", "message-box active");
}

window.addEventListener('load', (event) => {
    onLoadPage();
});

// First, parse the query string
var params = {}, postBody = location.hash.substring(1);
const urlSearchParams = new URLSearchParams(postBody);
     
for (const [key,value] of urlSearchParams.entries()){
    params[decodeURIComponent(key)] = decodeURIComponent(value);
}


// And send the token over to the server
// using POST so query isn't logged
var req_url = 'https://' + window.location.host + '/pkmsoidc';
var xmlhttp = new XMLHttpRequest();

xmlhttp.onreadystatechange=function()
{
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
        const parser = new DOMParser();
        const newDoc = parser.parseFromString(xmlhttp.responseText, "text/html");

        // Replace the current document's body
        document.replaceChild(
            document.importNode(newDoc.documentElement, true), 
            document.documentElement
        );
    }
}

xmlhttp.open('POST', req_url, true);
xmlhttp.setRequestHeader('Content-Type', 
                            'application/x-www-form-urlencoded');
xmlhttp.send(postBody);

