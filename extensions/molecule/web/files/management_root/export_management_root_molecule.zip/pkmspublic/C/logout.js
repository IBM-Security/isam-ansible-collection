/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022
 */

/*
 * This script contains some common functions which are used by the 
 * logout.html management page.
 */

function onLoadPage(token) {
    // Verify Identity Access has a remember-me capability which will permit
    // a long lived session.  If you don't want to store the supplied
    // token in a cookie you could store the token in the browser
    // Web storage.  The following code will check to see if the
    // token has been cleared in the HTTP response and if so will also
    // clear the token from the browser Web storage.
    if (token != null && token === "") {
        localStorage.removeItem("verify-access-token");
    }
 
    showMessage();
}

function showMessage() {
    var elem = document.getElementById("message-box");
    elem.setAttribute("class", "message-box active");
}

window.addEventListener('load', (event) => {
    onLoadPage(document.scripts.namedItem("logout").getAttribute('token'));
});

