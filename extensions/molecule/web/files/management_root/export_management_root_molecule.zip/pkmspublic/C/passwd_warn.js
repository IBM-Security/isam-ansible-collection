/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022, 2025
 */

/*
 * This script contains some common functions which are used by the 
 * passwd_warn.html management page.
 */

var seconds = document.currentScript.getAttribute('expire_secs');
var date    = new Date();

date.setTime(date.getTime() + (seconds * 1000));

document.getElementById("exp_date").textContent = date.toLocaleString();