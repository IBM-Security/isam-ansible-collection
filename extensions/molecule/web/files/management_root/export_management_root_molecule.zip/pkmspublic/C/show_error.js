/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022
 */

/*
 * This script contains some common functions which are used by the various
 * management pages to display errors.
 */

function onLoadPage(error_message) {
    if (error_message != null) {
        showError(error_message);
    }
}

function showError(error_message) {
    var elem = document.getElementById("error-box");
    if (error_message == "") {	
        elem.setAttribute("class", "error-box");
    } else {
        elem.setAttribute("class", "error-box active");
    }
}

window.addEventListener('load', (event) => {
    onLoadPage(document.scripts.namedItem("show_error").getAttribute('error'))
});

