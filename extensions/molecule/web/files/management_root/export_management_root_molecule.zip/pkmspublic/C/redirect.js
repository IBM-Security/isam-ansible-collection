/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022
 */

/*
 * This script contains some common functions which are used by the 
 * redirect.html management page.
 */

var redirect    = "GWOriginalURL=";
var mgmt        = "/pkmscertpromptstagen";
var cookies     = document.cookie.split(';');
var redirectURL = document.currentScript.getAttribute('location');

if (redirectURL.indexOf(mgmt) == -1) {
    for(var i=0; i<cookies.length; i++) {
        var cookie = cookies[i];
        // Trim any leading space characters
        while (cookie.charAt(0)==' ') {
            cookie = cookie.substring(1, cookie.length);
        }
        if (cookie.indexOf(redirect) == 0) {
            redirectURL = decodeURIComponent(cookie.substring(redirect.length, cookie.length));
            document.cookie = 'GWOriginalURL=; expires=Thu, 01-Jan-70 00:00:01 GMT; Path=/;';
            break;
        }
    }
}

if (redirectURL != "") {
    window.location.href = redirectURL;
}

