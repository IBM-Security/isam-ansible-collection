/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022
 */

/*
 * This script contains some common functions which are used by the various
 * management pages to display errors.
 */

function onLoadPage() {
    showMessage();
}

function showMessage() {
    var elem = document.getElementById("message-box");
    elem.setAttribute("class", "message-box active");
}

window.addEventListener('load', (event) => {
    onLoadPage();
});

